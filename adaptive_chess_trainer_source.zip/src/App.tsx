const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
import { Chess } from "/node_modules/.vite/deps/chess__js.js?v=490e7631";
import { ChessBoard } from "/src/components/ChessBoard.tsx";
import { EvalBar } from "/src/components/EvalBar.tsx";
import { EloHeader } from "/src/components/EloHeader.tsx";
import { MoveHistory } from "/src/components/MoveHistory.tsx";
import { GameControls } from "/src/components/GameControls.tsx";
import { GameOverModal } from "/src/components/GameOverModal.tsx";
import { SettingsModal } from "/src/components/SettingsModal.tsx";
import { evaluateBoard } from "/src/engine/evaluator.ts";
import { chooseBotMove, classifyMove, generateHint } from "/src/engine/botEngine.ts";
import { soundEffects } from "/src/utils/audio.ts";
import { downloadProjectZip } from "/src/utils/exportSourceZip.ts";
import { Sparkles, Download } from "/node_modules/.vite/deps/lucide-react.js?v=c3d5a9dc";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
const STORAGE_KEY = "adaptive_chess_player_stats_v1";
const DEFAULT_STATS = {
	userElo: 250,
	matchesPlayed: 0,
	wins: 0,
	losses: 0,
	draws: 0,
	streak: 0,
	ratingHistory: []
};
export default function App() {
	// Game state
	const [game, setGame] = useState(() => new Chess());
	const [playerColor, setPlayerColor] = useState("w");
	const [isBotThinking, setIsBotThinking] = useState(false);
	const [lastMove, setLastMove] = useState(null);
	const [moves, setMoves] = useState([]);
	const [currentEval, setCurrentEval] = useState(0);
	const [hint, setHint] = useState(null);
	const [lastCoachComment, setLastCoachComment] = useState("Welcome! As you play, the bot will dynamically adapt to stay 100 Elo above your rating.");
	// Player stats & Elo
	const [stats, setStats] = useState(() => {
		try {
			const saved = localStorage.getItem(STORAGE_KEY);
			if (saved) return JSON.parse(saved);
		} catch {}
		return DEFAULT_STATS;
	});
	// Bot Elo: strictly stays 100 Elo above user's rating
	const botElo = stats.userElo + 100;
	// Modals & UI toggles
	const [isSoundMuted, setIsSoundMuted] = useState(false);
	const [showBlunderAlerts, setShowBlunderAlerts] = useState(true);
	const [isSettingsOpen, setIsSettingsOpen] = useState(false);
	const [isExporting, setIsExporting] = useState(false);
	const [gameOverState, setGameOverState] = useState({
		isOpen: false,
		result: "draw",
		reason: "",
		eloChange: 0,
		newPlayerElo: stats.userElo,
		newBotElo: stats.userElo + 100
	});
	// Keep sound effects muted state in sync
	useEffect(() => {
		soundEffects.muted = isSoundMuted;
	}, [isSoundMuted]);
	// Persist stats
	useEffect(() => {
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
		} catch {}
	}, [stats]);
	// Track captured pieces
	const [capturedByWhite, setCapturedByWhite] = useState([]);
	const [capturedByBlack, setCapturedByBlack] = useState([]);
	const updateCapturedPieces = useCallback((currentGame) => {
		const initialCounts = {
			w: {
				p: 8,
				n: 2,
				b: 2,
				r: 2,
				q: 1,
				k: 1
			},
			b: {
				p: 8,
				n: 2,
				b: 2,
				r: 2,
				q: 1,
				k: 1
			}
		};
		const board = currentGame.board();
		for (let r = 0; r < 8; r++) {
			for (let c = 0; c < 8; c++) {
				const piece = board[r][c];
				if (piece) {
					initialCounts[piece.color][piece.type]--;
				}
			}
		}
		const whiteCaptures = [];
		const blackCaptures = [];
		[
			"q",
			"r",
			"b",
			"n",
			"p"
		].forEach((t) => {
			// Missing black pieces were captured by white
			for (let i = 0; i < initialCounts.b[t]; i++) whiteCaptures.push(t);
			// Missing white pieces were captured by black
			for (let i = 0; i < initialCounts.w[t]; i++) blackCaptures.push(t);
		});
		setCapturedByWhite(whiteCaptures);
		setCapturedByBlack(blackCaptures);
	}, []);
	// Check Game Over conditions
	const handleGameOverCheck = useCallback((currentGame) => {
		if (!currentGame.isGameOver()) return false;
		let result = "draw";
		let reason = "Game finished";
		let eloDelta = 0;
		if (currentGame.isCheckmate()) {
			const winner = currentGame.turn() === "w" ? "b" : "w";
			if (winner === playerColor) {
				result = "win";
				reason = "Checkmate! You won!";
				eloDelta = 32;
				soundEffects.playVictory();
			} else {
				result = "loss";
				reason = "Checkmate. Bot won.";
				eloDelta = -12;
				soundEffects.playDefeat();
			}
		} else if (currentGame.isDraw()) {
			result = "draw";
			if (currentGame.isStalemate()) reason = "Draw by Stalemate";
			else if (currentGame.isThreefoldRepetition()) reason = "Draw by Threefold Repetition";
			else if (currentGame.isInsufficientMaterial()) reason = "Draw by Insufficient Material";
			else reason = "Draw agreed (50-move rule)";
			eloDelta = 8;
		}
		const updatedUserElo = Math.max(100, stats.userElo + eloDelta);
		const updatedBotElo = updatedUserElo + 100;
		// Update statistics
		setStats((prev) => ({
			...prev,
			userElo: updatedUserElo,
			matchesPlayed: prev.matchesPlayed + 1,
			wins: result === "win" ? prev.wins + 1 : prev.wins,
			losses: result === "loss" ? prev.losses + 1 : prev.losses,
			draws: result === "draw" ? prev.draws + 1 : prev.draws,
			streak: result === "win" ? prev.streak + 1 : 0,
			ratingHistory: [...prev.ratingHistory, {
				match: prev.matchesPlayed + 1,
				elo: updatedUserElo,
				date: new Date().toLocaleDateString(),
				opponentElo: botElo,
				result
			}]
		}));
		setGameOverState({
			isOpen: true,
			result,
			reason,
			eloChange: eloDelta,
			newPlayerElo: updatedUserElo,
			newBotElo: updatedBotElo
		});
		return true;
	}, [
		playerColor,
		stats.userElo,
		botElo
	]);
	// Trigger bot turn
	const triggerBotTurn = useCallback((currentGame) => {
		if (currentGame.isGameOver()) return;
		setIsBotThinking(true);
		// Realistic think time 400ms - 750ms
		const delay = Math.floor(Math.random() * 350) + 400;
		setTimeout(() => {
			try {
				const move = chooseBotMove(currentGame, botElo);
				if (move) {
					const evalBefore = evaluateBoard(currentGame);
					const applied = currentGame.move(move);
					if (applied) {
						const evalAfter = evaluateBoard(currentGame);
						setLastMove({
							from: applied.from,
							to: applied.to
						});
						// Audio
						if (currentGame.inCheck()) {
							soundEffects.playCheck();
						} else if (applied.captured) {
							soundEffects.playCapture();
						} else {
							soundEffects.playMove();
						}
						const newEval = evaluateBoard(currentGame);
						setCurrentEval(newEval);
						setMoves((prev) => [...prev, {
							san: applied.san,
							from: applied.from,
							to: applied.to,
							piece: applied.piece,
							color: applied.color,
							captured: applied.captured,
							evalBefore,
							evalAfter,
							classification: "good"
						}]);
						updateCapturedPieces(currentGame);
						handleGameOverCheck(currentGame);
					}
				}
			} finally {
				setIsBotThinking(false);
				setGame(new Chess(currentGame.fen()));
			}
		}, delay);
	}, [
		botElo,
		updateCapturedPieces,
		handleGameOverCheck
	]);
	// Handle human move
	const handlePlayerMove = (from, to, promotion) => {
		if (isBotThinking || game.isGameOver()) return false;
		// Clear active hint on move
		setHint(null);
		const clone = new Chess(game.fen());
		try {
			const moveResult = clone.move({
				from,
				to,
				promotion: promotion || "q"
			});
			if (!moveResult) return false;
			// Classify player move against optimal engine choice
			const classification = classifyMove(game, moveResult.san, 2);
			// Play audio feedback
			if (clone.inCheck()) {
				soundEffects.playCheck();
			} else if (moveResult.captured) {
				soundEffects.playCapture();
			} else {
				soundEffects.playMove();
			}
			if (classification.classification === "blunder" && showBlunderAlerts) {
				soundEffects.playBlunder();
			}
			// Update state
			setLastMove({
				from: moveResult.from,
				to: moveResult.to
			});
			setLastCoachComment(classification.explanation || null);
			const newEval = evaluateBoard(clone);
			setCurrentEval(newEval);
			setMoves((prev) => [...prev, {
				san: moveResult.san,
				from: moveResult.from,
				to: moveResult.to,
				piece: moveResult.piece,
				color: moveResult.color,
				captured: moveResult.captured,
				evalBefore: classification.evalBefore,
				evalAfter: classification.evalAfter,
				classification: classification.classification,
				comment: classification.explanation,
				bestMoveSan: classification.bestMoveSan
			}]);
			updateCapturedPieces(clone);
			setGame(clone);
			const isOver = handleGameOverCheck(clone);
			if (!isOver) {
				triggerBotTurn(clone);
			}
			return true;
		} catch {
			return false;
		}
	};
	// User Actions
	const handleHint = () => {
		if (game.turn() !== playerColor || isBotThinking || game.isGameOver()) return;
		const suggestion = generateHint(game);
		if (suggestion) {
			setHint(suggestion);
			setLastCoachComment(suggestion.explanation);
		}
	};
	const handleUndo = () => {
		if (moves.length === 0 || isBotThinking) return;
		const clone = new Chess(game.fen());
		// Undo bot move and player move
		if (clone.turn() === playerColor) {
			clone.undo();
			clone.undo();
			setMoves((prev) => prev.slice(0, Math.max(0, prev.length - 2)));
		} else {
			clone.undo();
			setMoves((prev) => prev.slice(0, Math.max(0, prev.length - 1)));
		}
		setGame(clone);
		setHint(null);
		setLastMove(null);
		setCurrentEval(evaluateBoard(clone));
		updateCapturedPieces(clone);
		setLastCoachComment("Move retracted. Try an alternative continuation.");
	};
	const handleResign = () => {
		if (game.isGameOver()) return;
		const eloDelta = -14;
		const updatedUserElo = Math.max(100, stats.userElo + eloDelta);
		const updatedBotElo = updatedUserElo + 100;
		setStats((prev) => ({
			...prev,
			userElo: updatedUserElo,
			matchesPlayed: prev.matchesPlayed + 1,
			losses: prev.losses + 1,
			streak: 0,
			ratingHistory: [...prev.ratingHistory, {
				match: prev.matchesPlayed + 1,
				elo: updatedUserElo,
				date: new Date().toLocaleDateString(),
				opponentElo: botElo,
				result: "loss"
			}]
		}));
		setGameOverState({
			isOpen: true,
			result: "loss",
			reason: "Player Resigned",
			eloChange: eloDelta,
			newPlayerElo: updatedUserElo,
			newBotElo: updatedBotElo
		});
		soundEffects.playDefeat();
	};
	const startNewGame = (color = "w") => {
		const newG = new Chess();
		setGame(newG);
		setMoves([]);
		setLastMove(null);
		setHint(null);
		setCurrentEval(0);
		setCapturedByWhite([]);
		setCapturedByBlack([]);
		setPlayerColor(color);
		setGameOverState((prev) => ({
			...prev,
			isOpen: false
		}));
		setLastCoachComment(`New match underway vs ${stats.userElo + 100} Elo bot.`);
		if (color === "b") {
			triggerBotTurn(newG);
		}
	};
	const handleFlipBoard = () => {
		setPlayerColor((prev) => prev === "w" ? "b" : "w");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-[#111315] text-stone-200 flex flex-col",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex items-center justify-between gap-8 px-4 sm:px-8 py-3.5 border-b border-white/10 bg-[#16181B] sticky top-0 z-40",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 whitespace-nowrap shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-display font-bold text-lg sm:text-xl text-stone-100 tracking-tight",
							children: "Adaptive Chess"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 415,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md hidden sm:inline-block",
							children: "+100 Dynamic Sparring"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 418,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 414,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "hidden md:flex items-center gap-6 text-xs text-stone-400 font-medium",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-stone-300",
								children: ["Player Rating: ", stats.userElo]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 425,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								"aria-hidden": "true",
								children: "·"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 426,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-emerald-400",
								children: ["Bot Target: ", botElo]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 427,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								"aria-hidden": "true",
								children: "·"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 428,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: ["Wins: ", stats.wins] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 429,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 424,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 sm:gap-3 shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: async () => {
								setIsExporting(true);
								try {
									await downloadProjectZip();
								} finally {
									setIsExporting(false);
								}
							},
							disabled: isExporting,
							className: "flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-stone-100 bg-stone-800 hover:bg-stone-700 active:scale-95 border border-white/15 rounded-lg transition-colors whitespace-nowrap shadow-sm disabled:opacity-50",
							title: "Download full project source code as .zip",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 447,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExporting ? "Packing Zip..." : "Download Code (.zip)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 448,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 434,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => startNewGame(playerColor),
							className: "px-3.5 py-1.5 text-xs font-semibold text-stone-900 bg-[#F4F2BA] hover:bg-yellow-200 active:scale-95 rounded-lg transition-colors whitespace-nowrap shadow-sm",
							children: "New Game"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 451,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 433,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 412,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 lg:p-8 flex flex-col gap-6",
				children: [/* @__PURE__ */ _jsxDEV(EloHeader, {
					stats,
					botElo,
					playerColor,
					turn: game.turn(),
					isBotThinking,
					capturedByWhite,
					capturedByBlack
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 464,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 lg:grid-cols-12 gap-6 items-start",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-7 xl:col-span-8 flex flex-col items-center",
						children: [
							hint && /* @__PURE__ */ _jsxDEV("div", {
								className: "w-full max-w-[540px] mb-3 p-3 bg-cyan-950/40 border border-cyan-500/30 rounded-xl text-xs flex items-center justify-between gap-3 animate-in fade-in duration-150",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-cyan-300",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-4 h-4 shrink-0 text-cyan-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 484,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
										/* @__PURE__ */ _jsxDEV("strong", {
											className: "font-semibold",
											children: [hint.san, ":"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 486,
											columnNumber: 21
										}, this),
										" ",
										hint.explanation
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 485,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 483,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setHint(null),
									className: "text-stone-400 hover:text-stone-200 text-[11px] underline shrink-0",
									children: "Dismiss"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 489,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 482,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-center gap-2 sm:gap-4 w-full",
								children: [/* @__PURE__ */ _jsxDEV(EvalBar, {
									evalCp: currentEval,
									playerColor
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 501,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(ChessBoard, {
									game,
									onMove: handlePlayerMove,
									playerColor,
									isBotThinking,
									lastMove,
									hint,
									disabled: game.isGameOver()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 504,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 499,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-full max-w-[540px] mt-3 flex items-center justify-between text-[11px] text-stone-400 px-1 font-mono-nums",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-sm bg-[#F4F2BA]" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 519,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Light Tile" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 520,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 518,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-sm bg-[#779556]" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 523,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Green Tile" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 524,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 522,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 517,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Click or drag pieces to move" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 527,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 516,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 478,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-5 xl:col-span-4 flex flex-col gap-4",
						children: [
							/* @__PURE__ */ _jsxDEV(GameControls, {
								onHint: handleHint,
								onUndo: handleUndo,
								onResign: handleResign,
								onNewGame: () => startNewGame(playerColor),
								onFlipBoard: handleFlipBoard,
								onToggleSound: () => setIsSoundMuted((prev) => !prev),
								onOpenSettings: () => setIsSettingsOpen(true),
								isSoundMuted,
								canUndo: moves.length > 0,
								isGameOver: game.isGameOver(),
								isBotThinking
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 535,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(MoveHistory, {
								moves,
								lastExplanation: lastCoachComment
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 550,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-[#1A1D20] border border-white/10 rounded-2xl p-4 shadow-xl",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs uppercase tracking-wider text-stone-400 font-semibold",
										children: "Dynamic Elo Growth"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 555,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-amber-400 font-mono-nums font-bold",
										children: [
											"Target: ",
											botElo,
											" Bot"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 558,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 554,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-stone-400 leading-relaxed",
									children: "As your skill develops, match wins will boost your rating and the bot will immediately scale its search depth and tactical vigilance to stay 100 Elo above you."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 562,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 553,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 532,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 475,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 461,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(GameOverModal, {
				isOpen: gameOverState.isOpen,
				result: gameOverState.result,
				reason: gameOverState.reason,
				eloChange: gameOverState.eloChange,
				newPlayerElo: gameOverState.newPlayerElo,
				newBotElo: gameOverState.newBotElo,
				moves,
				onPlayAgain: () => startNewGame(playerColor),
				onClose: () => setGameOverState((prev) => ({
					...prev,
					isOpen: false
				}))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 573,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SettingsModal, {
				isOpen: isSettingsOpen,
				onClose: () => setIsSettingsOpen(false),
				stats,
				onUpdatePlayerElo: (newElo) => {
					setStats((prev) => ({
						...prev,
						userElo: newElo
					}));
					setLastCoachComment(`Rating adjusted to ${newElo} Elo. Bot updated to ${newElo + 100} Elo.`);
				},
				onResetStats: () => {
					setStats(DEFAULT_STATS);
					startNewGame("w");
				},
				isSoundMuted,
				onToggleSound: () => setIsSoundMuted((prev) => !prev),
				showBlunderAlerts,
				onToggleBlunderAlerts: () => setShowBlunderAlerts((prev) => !prev),
				onDownloadSource: async () => {
					try {
						const res = await fetch("/SOURCE_CODE.md");
						let content = "";
						if (res.ok) {
							content = await res.text();
						}
						if (!content) {
							content = "# Adaptive Chess Source Code\nCheck repository files.";
						}
						const blob = new Blob([content], { type: "text/markdown;charset=utf-8" });
						const url = URL.createObjectURL(blob);
						const link = document.createElement("a");
						link.href = url;
						link.download = "adaptive_chess_source_code.md";
						document.body.appendChild(link);
						link.click();
						document.body.removeChild(link);
						URL.revokeObjectURL(url);
					} catch (e) {
						console.error("Download error", e);
					}
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 586,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 410,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxtQkFBMkI7QUFDaEUsU0FBUyxhQUFxQjtBQUM5QixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxlQUFlLGNBQWMsb0JBQW9CO0FBQzFELFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsMEJBQTBCO0FBRW5DLFNBQTZCLFVBQVUsZ0JBQWdCOzs7QUFFdkQsTUFBTSxjQUFjO0FBRXBCLE1BQU0sZ0JBQTZCO0NBQ2pDLFNBQVM7Q0FDVCxlQUFlO0NBQ2YsTUFBTTtDQUNOLFFBQVE7Q0FDUixPQUFPO0NBQ1AsUUFBUTtDQUNSLGVBQWUsQ0FBQztBQUNsQjtBQUVBLGVBQWUsU0FBUyxNQUFNOztDQUU1QixNQUFNLENBQUMsTUFBTSxXQUFXLGVBQXNCLElBQUksTUFBTSxDQUFDO0NBQ3pELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFxQixHQUFHO0NBQzlELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FDeEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUE4QyxJQUFJO0NBQ2xGLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBMEIsQ0FBQyxDQUFDO0NBQ3RELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFpQixDQUFDO0NBQ3hELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBZ0MsSUFBSTtDQUM1RCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUM5Qyx5RkFDRjs7Q0FHQSxNQUFNLENBQUMsT0FBTyxZQUFZLGVBQTRCO0VBQ3BELElBQUk7R0FDRixNQUFNLFFBQVEsYUFBYSxRQUFRLFdBQVc7R0FDOUMsSUFBSSxPQUFPLE9BQU8sS0FBSyxNQUFNLEtBQUs7RUFDcEMsUUFBUSxDQUFDO0VBQ1QsT0FBTztDQUNULENBQUM7O0NBR0QsTUFBTSxTQUFTLE1BQU0sVUFBVTs7Q0FHL0IsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLElBQUk7Q0FDL0QsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxLQUFLO0NBQzFELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBT3ZDO0VBQ0QsUUFBUTtFQUNSLFFBQVE7RUFDUixRQUFRO0VBQ1IsV0FBVztFQUNYLGNBQWMsTUFBTTtFQUNwQixXQUFXLE1BQU0sVUFBVTtDQUM3QixDQUFDOztDQUdELGdCQUFnQjtFQUNkLGFBQWEsUUFBUTtDQUN2QixHQUFHLENBQUMsWUFBWSxDQUFDOztDQUdqQixnQkFBZ0I7RUFDZCxJQUFJO0dBQ0YsYUFBYSxRQUFRLGFBQWEsS0FBSyxVQUFVLEtBQUssQ0FBQztFQUN6RCxRQUFRLENBQUM7Q0FDWCxHQUFHLENBQUMsS0FBSyxDQUFDOztDQUdWLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQXNCLENBQUMsQ0FBQztDQUN0RSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFzQixDQUFDLENBQUM7Q0FFdEUsTUFBTSx1QkFBdUIsYUFBYSxnQkFBdUI7RUFDL0QsTUFBTSxnQkFBK0Q7R0FDbkUsR0FBRztJQUFFLEdBQUc7SUFBRyxHQUFHO0lBQUcsR0FBRztJQUFHLEdBQUc7SUFBRyxHQUFHO0lBQUcsR0FBRztHQUFFO0dBQ3hDLEdBQUc7SUFBRSxHQUFHO0lBQUcsR0FBRztJQUFHLEdBQUc7SUFBRyxHQUFHO0lBQUcsR0FBRztJQUFHLEdBQUc7R0FBRTtFQUMxQztFQUVBLE1BQU0sUUFBUSxZQUFZLE1BQU07RUFDaEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztHQUMxQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0lBQzFCLE1BQU0sUUFBUSxNQUFNLEVBQUUsQ0FBQztJQUN2QixJQUFJLE9BQU87S0FDVCxjQUFjLE1BQU0sTUFBTSxDQUFDLE1BQU0sS0FBSztJQUN4QztHQUNGO0VBQ0Y7RUFFQSxNQUFNLGdCQUE2QixDQUFDO0VBQ3BDLE1BQU0sZ0JBQTZCLENBQUM7RUFFcEMsQUFBQztHQUFDO0dBQUs7R0FBSztHQUFLO0dBQUs7RUFBRyxDQUFDLENBQVcsU0FBUyxNQUFNOztHQUVsRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksY0FBYyxFQUFFLElBQUksS0FBSyxjQUFjLEtBQUssQ0FBQzs7R0FFakUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsRUFBRSxJQUFJLEtBQUssY0FBYyxLQUFLLENBQUM7RUFDbkUsQ0FBQztFQUVELG1CQUFtQixhQUFhO0VBQ2hDLG1CQUFtQixhQUFhO0NBQ2xDLEdBQUcsQ0FBQyxDQUFDOztDQUdMLE1BQU0sc0JBQXNCLGFBQ3pCLGdCQUF1QjtFQUN0QixJQUFJLENBQUMsWUFBWSxXQUFXLEdBQUcsT0FBTztFQUV0QyxJQUFJLFNBQWtDO0VBQ3RDLElBQUksU0FBUztFQUNiLElBQUksV0FBVztFQUVmLElBQUksWUFBWSxZQUFZLEdBQUc7R0FDN0IsTUFBTSxTQUFTLFlBQVksS0FBSyxNQUFNLE1BQU0sTUFBTTtHQUNsRCxJQUFJLFdBQVcsYUFBYTtJQUMxQixTQUFTO0lBQ1QsU0FBUztJQUNULFdBQVc7SUFDWCxhQUFhLFlBQVk7R0FDM0IsT0FBTztJQUNMLFNBQVM7SUFDVCxTQUFTO0lBQ1QsV0FBVyxDQUFDO0lBQ1osYUFBYSxXQUFXO0dBQzFCO0VBQ0YsT0FBTyxJQUFJLFlBQVksT0FBTyxHQUFHO0dBQy9CLFNBQVM7R0FDVCxJQUFJLFlBQVksWUFBWSxHQUFHLFNBQVM7UUFDbkMsSUFBSSxZQUFZLHNCQUFzQixHQUFHLFNBQVM7UUFDbEQsSUFBSSxZQUFZLHVCQUF1QixHQUFHLFNBQVM7UUFDbkQsU0FBUztHQUNkLFdBQVc7RUFDYjtFQUVBLE1BQU0saUJBQWlCLEtBQUssSUFBSSxLQUFLLE1BQU0sVUFBVSxRQUFRO0VBQzdELE1BQU0sZ0JBQWdCLGlCQUFpQjs7RUFHdkMsVUFBVSxVQUFVO0dBQ2xCLEdBQUc7R0FDSCxTQUFTO0dBQ1QsZUFBZSxLQUFLLGdCQUFnQjtHQUNwQyxNQUFNLFdBQVcsUUFBUSxLQUFLLE9BQU8sSUFBSSxLQUFLO0dBQzlDLFFBQVEsV0FBVyxTQUFTLEtBQUssU0FBUyxJQUFJLEtBQUs7R0FDbkQsT0FBTyxXQUFXLFNBQVMsS0FBSyxRQUFRLElBQUksS0FBSztHQUNqRCxRQUFRLFdBQVcsUUFBUSxLQUFLLFNBQVMsSUFBSTtHQUM3QyxlQUFlLENBQ2IsR0FBRyxLQUFLLGVBQ1I7SUFDRSxPQUFPLEtBQUssZ0JBQWdCO0lBQzVCLEtBQUs7SUFDTCxNQUFNLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CO0lBQ3BDLGFBQWE7SUFDYjtHQUNGLENBQ0Y7RUFDRixFQUFFO0VBRUYsaUJBQWlCO0dBQ2YsUUFBUTtHQUNSO0dBQ0E7R0FDQSxXQUFXO0dBQ1gsY0FBYztHQUNkLFdBQVc7RUFDYixDQUFDO0VBRUQsT0FBTztDQUNULEdBQ0E7RUFBQztFQUFhLE1BQU07RUFBUztDQUFNLENBQ3JDOztDQUdBLE1BQU0saUJBQWlCLGFBQ3BCLGdCQUF1QjtFQUN0QixJQUFJLFlBQVksV0FBVyxHQUFHO0VBRTlCLGlCQUFpQixJQUFJOztFQUVyQixNQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUcsSUFBSTtFQUVoRCxpQkFBaUI7R0FDZixJQUFJO0lBQ0YsTUFBTSxPQUFPLGNBQWMsYUFBYSxNQUFNO0lBQzlDLElBQUksTUFBTTtLQUNSLE1BQU0sYUFBYSxjQUFjLFdBQVc7S0FDNUMsTUFBTSxVQUFVLFlBQVksS0FBSyxJQUFJO0tBQ3JDLElBQUksU0FBUztNQUNYLE1BQU0sWUFBWSxjQUFjLFdBQVc7TUFDM0MsWUFBWTtPQUFFLE1BQU0sUUFBUTtPQUFNLElBQUksUUFBUTtNQUFHLENBQUM7O01BR2xELElBQUksWUFBWSxRQUFRLEdBQUc7T0FDekIsYUFBYSxVQUFVO01BQ3pCLE9BQU8sSUFBSSxRQUFRLFVBQVU7T0FDM0IsYUFBYSxZQUFZO01BQzNCLE9BQU87T0FDTCxhQUFhLFNBQVM7TUFDeEI7TUFFQSxNQUFNLFVBQVUsY0FBYyxXQUFXO01BQ3pDLGVBQWUsT0FBTztNQUV0QixVQUFVLFNBQVMsQ0FDakIsR0FBRyxNQUNIO09BQ0UsS0FBSyxRQUFRO09BQ2IsTUFBTSxRQUFRO09BQ2QsSUFBSSxRQUFRO09BQ1osT0FBTyxRQUFRO09BQ2YsT0FBTyxRQUFRO09BQ2YsVUFBVSxRQUFRO09BQ2xCO09BQ0E7T0FDQSxnQkFBZ0I7TUFDbEIsQ0FDRixDQUFDO01BRUQscUJBQXFCLFdBQVc7TUFDaEMsb0JBQW9CLFdBQVc7S0FDakM7SUFDRjtHQUNGLFVBQVU7SUFDUixpQkFBaUIsS0FBSztJQUN0QixRQUFRLElBQUksTUFBTSxZQUFZLElBQUksQ0FBQyxDQUFDO0dBQ3RDO0VBQ0YsR0FBRyxLQUFLO0NBQ1YsR0FDQTtFQUFDO0VBQVE7RUFBc0I7Q0FBbUIsQ0FDcEQ7O0NBR0EsTUFBTSxvQkFBb0IsTUFBYyxJQUFZLGNBQWdDO0VBQ2xGLElBQUksaUJBQWlCLEtBQUssV0FBVyxHQUFHLE9BQU87O0VBRy9DLFFBQVEsSUFBSTtFQUVaLE1BQU0sUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUM7RUFDbEMsSUFBSTtHQUNGLE1BQU0sYUFBYSxNQUFNLEtBQUs7SUFDdEI7SUFDRjtJQUNKLFdBQVcsYUFBYTtHQUMxQixDQUFDO0dBRUQsSUFBSSxDQUFDLFlBQVksT0FBTzs7R0FHeEIsTUFBTSxpQkFBaUIsYUFBYSxNQUFNLFdBQVcsS0FBSyxDQUFDOztHQUczRCxJQUFJLE1BQU0sUUFBUSxHQUFHO0lBQ25CLGFBQWEsVUFBVTtHQUN6QixPQUFPLElBQUksV0FBVyxVQUFVO0lBQzlCLGFBQWEsWUFBWTtHQUMzQixPQUFPO0lBQ0wsYUFBYSxTQUFTO0dBQ3hCO0dBRUEsSUFBSSxlQUFlLG1CQUFtQixhQUFhLG1CQUFtQjtJQUNwRSxhQUFhLFlBQVk7R0FDM0I7O0dBR0EsWUFBWTtJQUFFLE1BQU0sV0FBVztJQUFNLElBQUksV0FBVztHQUFHLENBQUM7R0FDeEQsb0JBQW9CLGVBQWUsZUFBZSxJQUFJO0dBRXRELE1BQU0sVUFBVSxjQUFjLEtBQUs7R0FDbkMsZUFBZSxPQUFPO0dBRXRCLFVBQVUsU0FBUyxDQUNqQixHQUFHLE1BQ0g7SUFDRSxLQUFLLFdBQVc7SUFDaEIsTUFBTSxXQUFXO0lBQ2pCLElBQUksV0FBVztJQUNmLE9BQU8sV0FBVztJQUNsQixPQUFPLFdBQVc7SUFDbEIsVUFBVSxXQUFXO0lBQ3JCLFlBQVksZUFBZTtJQUMzQixXQUFXLGVBQWU7SUFDMUIsZ0JBQWdCLGVBQWU7SUFDL0IsU0FBUyxlQUFlO0lBQ3hCLGFBQWEsZUFBZTtHQUM5QixDQUNGLENBQUM7R0FFRCxxQkFBcUIsS0FBSztHQUMxQixRQUFRLEtBQUs7R0FFYixNQUFNLFNBQVMsb0JBQW9CLEtBQUs7R0FDeEMsSUFBSSxDQUFDLFFBQVE7SUFDWCxlQUFlLEtBQUs7R0FDdEI7R0FFQSxPQUFPO0VBQ1QsUUFBUTtHQUNOLE9BQU87RUFDVDtDQUNGOztDQUdBLE1BQU0sbUJBQW1CO0VBQ3ZCLElBQUksS0FBSyxLQUFLLE1BQU0sZUFBZSxpQkFBaUIsS0FBSyxXQUFXLEdBQUc7RUFDdkUsTUFBTSxhQUFhLGFBQWEsSUFBSTtFQUNwQyxJQUFJLFlBQVk7R0FDZCxRQUFRLFVBQVU7R0FDbEIsb0JBQW9CLFdBQVcsV0FBVztFQUM1QztDQUNGO0NBRUEsTUFBTSxtQkFBbUI7RUFDdkIsSUFBSSxNQUFNLFdBQVcsS0FBSyxlQUFlO0VBQ3pDLE1BQU0sUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUM7O0VBR2xDLElBQUksTUFBTSxLQUFLLE1BQU0sYUFBYTtHQUNoQyxNQUFNLEtBQUs7R0FDWCxNQUFNLEtBQUs7R0FDWCxVQUFVLFNBQVMsS0FBSyxNQUFNLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0VBQ2hFLE9BQU87R0FDTCxNQUFNLEtBQUs7R0FDWCxVQUFVLFNBQVMsS0FBSyxNQUFNLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0VBQ2hFO0VBRUEsUUFBUSxLQUFLO0VBQ2IsUUFBUSxJQUFJO0VBQ1osWUFBWSxJQUFJO0VBQ2hCLGVBQWUsY0FBYyxLQUFLLENBQUM7RUFDbkMscUJBQXFCLEtBQUs7RUFDMUIsb0JBQW9CLGtEQUFrRDtDQUN4RTtDQUVBLE1BQU0scUJBQXFCO0VBQ3pCLElBQUksS0FBSyxXQUFXLEdBQUc7RUFDdkIsTUFBTSxXQUFXLENBQUM7RUFDbEIsTUFBTSxpQkFBaUIsS0FBSyxJQUFJLEtBQUssTUFBTSxVQUFVLFFBQVE7RUFDN0QsTUFBTSxnQkFBZ0IsaUJBQWlCO0VBRXZDLFVBQVUsVUFBVTtHQUNsQixHQUFHO0dBQ0gsU0FBUztHQUNULGVBQWUsS0FBSyxnQkFBZ0I7R0FDcEMsUUFBUSxLQUFLLFNBQVM7R0FDdEIsUUFBUTtHQUNSLGVBQWUsQ0FDYixHQUFHLEtBQUssZUFDUjtJQUNFLE9BQU8sS0FBSyxnQkFBZ0I7SUFDNUIsS0FBSztJQUNMLE1BQU0sSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUI7SUFDcEMsYUFBYTtJQUNiLFFBQVE7R0FDVixDQUNGO0VBQ0YsRUFBRTtFQUVGLGlCQUFpQjtHQUNmLFFBQVE7R0FDUixRQUFRO0dBQ1IsUUFBUTtHQUNSLFdBQVc7R0FDWCxjQUFjO0dBQ2QsV0FBVztFQUNiLENBQUM7RUFDRCxhQUFhLFdBQVc7Q0FDMUI7Q0FFQSxNQUFNLGdCQUFnQixRQUFvQixRQUFRO0VBQ2hELE1BQU0sT0FBTyxJQUFJLE1BQU07RUFDdkIsUUFBUSxJQUFJO0VBQ1osU0FBUyxDQUFDLENBQUM7RUFDWCxZQUFZLElBQUk7RUFDaEIsUUFBUSxJQUFJO0VBQ1osZUFBZSxDQUFDO0VBQ2hCLG1CQUFtQixDQUFDLENBQUM7RUFDckIsbUJBQW1CLENBQUMsQ0FBQztFQUNyQixlQUFlLEtBQUs7RUFDcEIsa0JBQWtCLFVBQVU7R0FBRSxHQUFHO0dBQU0sUUFBUTtFQUFNLEVBQUU7RUFDdkQsb0JBQW9CLHlCQUF5QixNQUFNLFVBQVUsSUFBSSxVQUFVO0VBRTNFLElBQUksVUFBVSxLQUFLO0dBQ2pCLGVBQWUsSUFBSTtFQUNyQjtDQUNGO0NBRUEsTUFBTSx3QkFBd0I7RUFDNUIsZ0JBQWdCLFNBQVUsU0FBUyxNQUFNLE1BQU0sR0FBSTtDQUNyRDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMEU7TUFFcEY7Ozs7Z0JBQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW9JO01BRTlJOzs7O2NBQ0g7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQWlDLG1CQUFnQixNQUFNLE9BQWM7Ozs7OztPQUNyRSx3QkFBQyxRQUFEO1FBQU0sZUFBWTtrQkFBTztPQUFPOzs7OztPQUNoQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FBbUMsZ0JBQWEsTUFBYTs7Ozs7O09BQzdELHdCQUFDLFFBQUQ7UUFBTSxlQUFZO2tCQUFPO09BQU87Ozs7O09BQ2hDLHdCQUFDLFFBQUQsYUFBTSxVQUFPLE1BQU0sSUFBVzs7Ozs7TUFDM0I7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLFNBQVMsWUFBWTtRQUNuQixlQUFlLElBQUk7UUFDbkIsSUFBSTtTQUNGLE1BQU0sbUJBQW1CO1FBQzNCLFVBQVU7U0FDUixlQUFlLEtBQUs7UUFDdEI7T0FDRjtPQUNBLFVBQVU7T0FDVixXQUFVO09BQ1YsT0FBTTtpQkFYUixDQWFFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDZCQUE4Qjs7OztpQkFDbEQsd0JBQUMsUUFBRCxZQUFPLGNBQWMsbUJBQW1CLHVCQUE2Qjs7OztlQUMvRDs7Ozs7Z0JBRVIsd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxXQUFXO09BQ3ZDLFdBQVU7aUJBQ1g7TUFFTzs7OztjQUNMOzs7Ozs7SUFDQzs7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEIsQ0FHRSx3QkFBQyxXQUFEO0tBQ1M7S0FDQztLQUNLO0tBQ2IsTUFBTSxLQUFLLEtBQUs7S0FDRDtLQUNFO0tBQ0E7SUFDbEI7Ozs7Y0FHRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBR0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FHRyxRQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxpQ0FBa0M7Ozs7bUJBQ3RELHdCQUFDLFFBQUQ7VUFDRSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtxQkFBbEIsQ0FBbUMsS0FBSyxLQUFJLEdBQVM7Ozs7OztVQUFDO1VBQUUsS0FBSztTQUN6RDs7OztpQkFDSDs7Ozs7a0JBQ0wsd0JBQUMsVUFBRDtTQUNFLGVBQWUsUUFBUSxJQUFJO1NBQzNCLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7O09BSVAsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FFRSx3QkFBQyxTQUFEO1NBQVMsUUFBUTtTQUEwQjtRQUFjOzs7O2tCQUd6RCx3QkFBQyxZQUFEO1NBQ1E7U0FDTixRQUFRO1NBQ0s7U0FDRTtTQUNMO1NBQ0o7U0FDTixVQUFVLEtBQUssV0FBVztRQUMzQjs7OztnQkFDRTs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHNDQUF1Qzs7OztvQkFDdkQsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2tCQUNsQjs7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsc0NBQXVDOzs7O29CQUN2RCx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7a0JBQ2xCOzs7OztpQkFDSDs7Ozs7a0JBQ0wsd0JBQUMsUUFBRCxZQUFNLCtCQUFrQzs7OztnQkFDckM7Ozs7OztNQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BR0Usd0JBQUMsY0FBRDtRQUNFLFFBQVE7UUFDUixRQUFRO1FBQ1IsVUFBVTtRQUNWLGlCQUFpQixhQUFhLFdBQVc7UUFDekMsYUFBYTtRQUNiLHFCQUFxQixpQkFBaUIsU0FBUyxDQUFDLElBQUk7UUFDcEQsc0JBQXNCLGtCQUFrQixJQUFJO1FBQzlCO1FBQ2QsU0FBUyxNQUFNLFNBQVM7UUFDeEIsWUFBWSxLQUFLLFdBQVc7UUFDYjtPQUNoQjs7Ozs7T0FHRCx3QkFBQyxhQUFEO1FBQW9CO1FBQU8saUJBQWlCO09BQW1COzs7OztPQUcvRCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWdFO1NBRTFFOzs7O21CQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUFrRTtXQUN2RDtXQUFPO1VBQ1o7Ozs7O2lCQUNIOzs7OztrQkFDTCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBeUM7UUFFbkQ7Ozs7Z0JBQ0E7Ozs7OztNQUVGOzs7OzthQUVGOzs7OztZQUNEOzs7Ozs7R0FHTix3QkFBQyxlQUFEO0lBQ0UsUUFBUSxjQUFjO0lBQ3RCLFFBQVEsY0FBYztJQUN0QixRQUFRLGNBQWM7SUFDdEIsV0FBVyxjQUFjO0lBQ3pCLGNBQWMsY0FBYztJQUM1QixXQUFXLGNBQWM7SUFDbEI7SUFDUCxtQkFBbUIsYUFBYSxXQUFXO0lBQzNDLGVBQWUsa0JBQWtCLFVBQVU7S0FBRSxHQUFHO0tBQU0sUUFBUTtJQUFNLEVBQUU7R0FDdkU7Ozs7O0dBR0Qsd0JBQUMsZUFBRDtJQUNFLFFBQVE7SUFDUixlQUFlLGtCQUFrQixLQUFLO0lBQy9CO0lBQ1Asb0JBQW9CLFdBQVc7S0FDN0IsVUFBVSxVQUFVO01BQUUsR0FBRztNQUFNLFNBQVM7S0FBTyxFQUFFO0tBQ2pELG9CQUFvQixzQkFBc0IsT0FBTyx1QkFBdUIsU0FBUyxJQUFJLE1BQU07SUFDN0Y7SUFDQSxvQkFBb0I7S0FDbEIsU0FBUyxhQUFhO0tBQ3RCLGFBQWEsR0FBRztJQUNsQjtJQUNjO0lBQ2QscUJBQXFCLGlCQUFpQixTQUFTLENBQUMsSUFBSTtJQUNqQztJQUNuQiw2QkFBNkIsc0JBQXNCLFNBQVMsQ0FBQyxJQUFJO0lBQ2pFLGtCQUFrQixZQUFZO0tBQzVCLElBQUk7TUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLGlCQUFpQjtNQUN6QyxJQUFJLFVBQVU7TUFDZCxJQUFJLElBQUksSUFBSTtPQUNWLFVBQVUsTUFBTSxJQUFJLEtBQUs7TUFDM0I7TUFDQSxJQUFJLENBQUMsU0FBUztPQUNaLFVBQVU7TUFDWjtNQUNBLE1BQU0sT0FBTyxJQUFJLEtBQUssQ0FBQyxPQUFPLEdBQUcsRUFBRSxNQUFNLDhCQUE4QixDQUFDO01BQ3hFLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO01BQ3BDLE1BQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztNQUN2QyxLQUFLLE9BQU87TUFDWixLQUFLLFdBQVc7TUFDaEIsU0FBUyxLQUFLLFlBQVksSUFBSTtNQUM5QixLQUFLLE1BQU07TUFDWCxTQUFTLEtBQUssWUFBWSxJQUFJO01BQzlCLElBQUksZ0JBQWdCLEdBQUc7S0FDekIsU0FBUyxHQUFHO01BQ1YsUUFBUSxNQUFNLGtCQUFrQixDQUFDO0tBQ25DO0lBQ0Y7R0FDRDs7Ozs7RUFDRTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2ssIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IENoZXNzLCBTcXVhcmUgfSBmcm9tICdjaGVzcy5qcyc7XG5pbXBvcnQgeyBDaGVzc0JvYXJkIH0gZnJvbSAnLi9jb21wb25lbnRzL0NoZXNzQm9hcmQnO1xuaW1wb3J0IHsgRXZhbEJhciB9IGZyb20gJy4vY29tcG9uZW50cy9FdmFsQmFyJztcbmltcG9ydCB7IEVsb0hlYWRlciB9IGZyb20gJy4vY29tcG9uZW50cy9FbG9IZWFkZXInO1xuaW1wb3J0IHsgTW92ZUhpc3RvcnkgfSBmcm9tICcuL2NvbXBvbmVudHMvTW92ZUhpc3RvcnknO1xuaW1wb3J0IHsgR2FtZUNvbnRyb2xzIH0gZnJvbSAnLi9jb21wb25lbnRzL0dhbWVDb250cm9scyc7XG5pbXBvcnQgeyBHYW1lT3Zlck1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL0dhbWVPdmVyTW9kYWwnO1xuaW1wb3J0IHsgU2V0dGluZ3NNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9TZXR0aW5nc01vZGFsJztcbmltcG9ydCB7IGV2YWx1YXRlQm9hcmQgfSBmcm9tICcuL2VuZ2luZS9ldmFsdWF0b3InO1xuaW1wb3J0IHsgY2hvb3NlQm90TW92ZSwgY2xhc3NpZnlNb3ZlLCBnZW5lcmF0ZUhpbnQgfSBmcm9tICcuL2VuZ2luZS9ib3RFbmdpbmUnO1xuaW1wb3J0IHsgc291bmRFZmZlY3RzIH0gZnJvbSAnLi91dGlscy9hdWRpbyc7XG5pbXBvcnQgeyBkb3dubG9hZFByb2plY3RaaXAgfSBmcm9tICcuL3V0aWxzL2V4cG9ydFNvdXJjZVppcCc7XG5pbXBvcnQgeyBFdmFsdWF0ZWRNb3ZlLCBIaW50U3VnZ2VzdGlvbiwgUGllY2VDb2xvciwgUGllY2VUeXBlLCBQbGF5ZXJTdGF0cyB9IGZyb20gJy4vdHlwZXMvY2hlc3MnO1xuaW1wb3J0IHsgVHJvcGh5LCBIZWxwQ2lyY2xlLCBTcGFya2xlcywgRG93bmxvYWQgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5jb25zdCBTVE9SQUdFX0tFWSA9ICdhZGFwdGl2ZV9jaGVzc19wbGF5ZXJfc3RhdHNfdjEnO1xuXG5jb25zdCBERUZBVUxUX1NUQVRTOiBQbGF5ZXJTdGF0cyA9IHtcbiAgdXNlckVsbzogMjUwLFxuICBtYXRjaGVzUGxheWVkOiAwLFxuICB3aW5zOiAwLFxuICBsb3NzZXM6IDAsXG4gIGRyYXdzOiAwLFxuICBzdHJlYWs6IDAsXG4gIHJhdGluZ0hpc3Rvcnk6IFtdLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICAvLyBHYW1lIHN0YXRlXG4gIGNvbnN0IFtnYW1lLCBzZXRHYW1lXSA9IHVzZVN0YXRlPENoZXNzPigoKSA9PiBuZXcgQ2hlc3MoKSk7XG4gIGNvbnN0IFtwbGF5ZXJDb2xvciwgc2V0UGxheWVyQ29sb3JdID0gdXNlU3RhdGU8UGllY2VDb2xvcj4oJ3cnKTtcbiAgY29uc3QgW2lzQm90VGhpbmtpbmcsIHNldElzQm90VGhpbmtpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbGFzdE1vdmUsIHNldExhc3RNb3ZlXSA9IHVzZVN0YXRlPHsgZnJvbTogc3RyaW5nOyB0bzogc3RyaW5nIH0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW21vdmVzLCBzZXRNb3Zlc10gPSB1c2VTdGF0ZTxFdmFsdWF0ZWRNb3ZlW10+KFtdKTtcbiAgY29uc3QgW2N1cnJlbnRFdmFsLCBzZXRDdXJyZW50RXZhbF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbaGludCwgc2V0SGludF0gPSB1c2VTdGF0ZTxIaW50U3VnZ2VzdGlvbiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbbGFzdENvYWNoQ29tbWVudCwgc2V0TGFzdENvYWNoQ29tbWVudF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihcbiAgICAnV2VsY29tZSEgQXMgeW91IHBsYXksIHRoZSBib3Qgd2lsbCBkeW5hbWljYWxseSBhZGFwdCB0byBzdGF5IDEwMCBFbG8gYWJvdmUgeW91ciByYXRpbmcuJ1xuICApO1xuXG4gIC8vIFBsYXllciBzdGF0cyAmIEVsb1xuICBjb25zdCBbc3RhdHMsIHNldFN0YXRzXSA9IHVzZVN0YXRlPFBsYXllclN0YXRzPigoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oU1RPUkFHRV9LRVkpO1xuICAgICAgaWYgKHNhdmVkKSByZXR1cm4gSlNPTi5wYXJzZShzYXZlZCk7XG4gICAgfSBjYXRjaCB7fVxuICAgIHJldHVybiBERUZBVUxUX1NUQVRTO1xuICB9KTtcblxuICAvLyBCb3QgRWxvOiBzdHJpY3RseSBzdGF5cyAxMDAgRWxvIGFib3ZlIHVzZXIncyByYXRpbmdcbiAgY29uc3QgYm90RWxvID0gc3RhdHMudXNlckVsbyArIDEwMDtcblxuICAvLyBNb2RhbHMgJiBVSSB0b2dnbGVzXG4gIGNvbnN0IFtpc1NvdW5kTXV0ZWQsIHNldElzU291bmRNdXRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzaG93Qmx1bmRlckFsZXJ0cywgc2V0U2hvd0JsdW5kZXJBbGVydHNdID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtpc1NldHRpbmdzT3Blbiwgc2V0SXNTZXR0aW5nc09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNFeHBvcnRpbmcsIHNldElzRXhwb3J0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2dhbWVPdmVyU3RhdGUsIHNldEdhbWVPdmVyU3RhdGVdID0gdXNlU3RhdGU8e1xuICAgIGlzT3BlbjogYm9vbGVhbjtcbiAgICByZXN1bHQ6ICd3aW4nIHwgJ2xvc3MnIHwgJ2RyYXcnO1xuICAgIHJlYXNvbjogc3RyaW5nO1xuICAgIGVsb0NoYW5nZTogbnVtYmVyO1xuICAgIG5ld1BsYXllckVsbzogbnVtYmVyO1xuICAgIG5ld0JvdEVsbzogbnVtYmVyO1xuICB9Pih7XG4gICAgaXNPcGVuOiBmYWxzZSxcbiAgICByZXN1bHQ6ICdkcmF3JyxcbiAgICByZWFzb246ICcnLFxuICAgIGVsb0NoYW5nZTogMCxcbiAgICBuZXdQbGF5ZXJFbG86IHN0YXRzLnVzZXJFbG8sXG4gICAgbmV3Qm90RWxvOiBzdGF0cy51c2VyRWxvICsgMTAwLFxuICB9KTtcblxuICAvLyBLZWVwIHNvdW5kIGVmZmVjdHMgbXV0ZWQgc3RhdGUgaW4gc3luY1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNvdW5kRWZmZWN0cy5tdXRlZCA9IGlzU291bmRNdXRlZDtcbiAgfSwgW2lzU291bmRNdXRlZF0pO1xuXG4gIC8vIFBlcnNpc3Qgc3RhdHNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB0cnkge1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KHN0YXRzKSk7XG4gICAgfSBjYXRjaCB7fVxuICB9LCBbc3RhdHNdKTtcblxuICAvLyBUcmFjayBjYXB0dXJlZCBwaWVjZXNcbiAgY29uc3QgW2NhcHR1cmVkQnlXaGl0ZSwgc2V0Q2FwdHVyZWRCeVdoaXRlXSA9IHVzZVN0YXRlPFBpZWNlVHlwZVtdPihbXSk7XG4gIGNvbnN0IFtjYXB0dXJlZEJ5QmxhY2ssIHNldENhcHR1cmVkQnlCbGFja10gPSB1c2VTdGF0ZTxQaWVjZVR5cGVbXT4oW10pO1xuXG4gIGNvbnN0IHVwZGF0ZUNhcHR1cmVkUGllY2VzID0gdXNlQ2FsbGJhY2soKGN1cnJlbnRHYW1lOiBDaGVzcykgPT4ge1xuICAgIGNvbnN0IGluaXRpYWxDb3VudHM6IFJlY29yZDxQaWVjZUNvbG9yLCBSZWNvcmQ8UGllY2VUeXBlLCBudW1iZXI+PiA9IHtcbiAgICAgIHc6IHsgcDogOCwgbjogMiwgYjogMiwgcjogMiwgcTogMSwgazogMSB9LFxuICAgICAgYjogeyBwOiA4LCBuOiAyLCBiOiAyLCByOiAyLCBxOiAxLCBrOiAxIH0sXG4gICAgfTtcblxuICAgIGNvbnN0IGJvYXJkID0gY3VycmVudEdhbWUuYm9hcmQoKTtcbiAgICBmb3IgKGxldCByID0gMDsgciA8IDg7IHIrKykge1xuICAgICAgZm9yIChsZXQgYyA9IDA7IGMgPCA4OyBjKyspIHtcbiAgICAgICAgY29uc3QgcGllY2UgPSBib2FyZFtyXVtjXTtcbiAgICAgICAgaWYgKHBpZWNlKSB7XG4gICAgICAgICAgaW5pdGlhbENvdW50c1twaWVjZS5jb2xvcl1bcGllY2UudHlwZV0tLTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHdoaXRlQ2FwdHVyZXM6IFBpZWNlVHlwZVtdID0gW107XG4gICAgY29uc3QgYmxhY2tDYXB0dXJlczogUGllY2VUeXBlW10gPSBbXTtcblxuICAgIChbJ3EnLCAncicsICdiJywgJ24nLCAncCddIGFzIGNvbnN0KS5mb3JFYWNoKCh0KSA9PiB7XG4gICAgICAvLyBNaXNzaW5nIGJsYWNrIHBpZWNlcyB3ZXJlIGNhcHR1cmVkIGJ5IHdoaXRlXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluaXRpYWxDb3VudHMuYlt0XTsgaSsrKSB3aGl0ZUNhcHR1cmVzLnB1c2godCk7XG4gICAgICAvLyBNaXNzaW5nIHdoaXRlIHBpZWNlcyB3ZXJlIGNhcHR1cmVkIGJ5IGJsYWNrXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluaXRpYWxDb3VudHMud1t0XTsgaSsrKSBibGFja0NhcHR1cmVzLnB1c2godCk7XG4gICAgfSk7XG5cbiAgICBzZXRDYXB0dXJlZEJ5V2hpdGUod2hpdGVDYXB0dXJlcyk7XG4gICAgc2V0Q2FwdHVyZWRCeUJsYWNrKGJsYWNrQ2FwdHVyZXMpO1xuICB9LCBbXSk7XG5cbiAgLy8gQ2hlY2sgR2FtZSBPdmVyIGNvbmRpdGlvbnNcbiAgY29uc3QgaGFuZGxlR2FtZU92ZXJDaGVjayA9IHVzZUNhbGxiYWNrKFxuICAgIChjdXJyZW50R2FtZTogQ2hlc3MpID0+IHtcbiAgICAgIGlmICghY3VycmVudEdhbWUuaXNHYW1lT3ZlcigpKSByZXR1cm4gZmFsc2U7XG5cbiAgICAgIGxldCByZXN1bHQ6ICd3aW4nIHwgJ2xvc3MnIHwgJ2RyYXcnID0gJ2RyYXcnO1xuICAgICAgbGV0IHJlYXNvbiA9ICdHYW1lIGZpbmlzaGVkJztcbiAgICAgIGxldCBlbG9EZWx0YSA9IDA7XG5cbiAgICAgIGlmIChjdXJyZW50R2FtZS5pc0NoZWNrbWF0ZSgpKSB7XG4gICAgICAgIGNvbnN0IHdpbm5lciA9IGN1cnJlbnRHYW1lLnR1cm4oKSA9PT0gJ3cnID8gJ2InIDogJ3cnO1xuICAgICAgICBpZiAod2lubmVyID09PSBwbGF5ZXJDb2xvcikge1xuICAgICAgICAgIHJlc3VsdCA9ICd3aW4nO1xuICAgICAgICAgIHJlYXNvbiA9ICdDaGVja21hdGUhIFlvdSB3b24hJztcbiAgICAgICAgICBlbG9EZWx0YSA9IDMyOyAvLyBTb2xpZCBib29zdCBmb3IgYmVhdGluZyArMTAwIEVsbyBib3RcbiAgICAgICAgICBzb3VuZEVmZmVjdHMucGxheVZpY3RvcnkoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXN1bHQgPSAnbG9zcyc7XG4gICAgICAgICAgcmVhc29uID0gJ0NoZWNrbWF0ZS4gQm90IHdvbi4nO1xuICAgICAgICAgIGVsb0RlbHRhID0gLTEyOyAvLyBNb2Rlc3QgcGVuYWx0eVxuICAgICAgICAgIHNvdW5kRWZmZWN0cy5wbGF5RGVmZWF0KCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoY3VycmVudEdhbWUuaXNEcmF3KCkpIHtcbiAgICAgICAgcmVzdWx0ID0gJ2RyYXcnO1xuICAgICAgICBpZiAoY3VycmVudEdhbWUuaXNTdGFsZW1hdGUoKSkgcmVhc29uID0gJ0RyYXcgYnkgU3RhbGVtYXRlJztcbiAgICAgICAgZWxzZSBpZiAoY3VycmVudEdhbWUuaXNUaHJlZWZvbGRSZXBldGl0aW9uKCkpIHJlYXNvbiA9ICdEcmF3IGJ5IFRocmVlZm9sZCBSZXBldGl0aW9uJztcbiAgICAgICAgZWxzZSBpZiAoY3VycmVudEdhbWUuaXNJbnN1ZmZpY2llbnRNYXRlcmlhbCgpKSByZWFzb24gPSAnRHJhdyBieSBJbnN1ZmZpY2llbnQgTWF0ZXJpYWwnO1xuICAgICAgICBlbHNlIHJlYXNvbiA9ICdEcmF3IGFncmVlZCAoNTAtbW92ZSBydWxlKSc7XG4gICAgICAgIGVsb0RlbHRhID0gODsgLy8gU21hbGwgcmF0aW5nIGdhaW4gZm9yIGRyYXdpbmcgYWdhaW5zdCBoaWdoZXIgcmF0ZWQgYm90XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHVwZGF0ZWRVc2VyRWxvID0gTWF0aC5tYXgoMTAwLCBzdGF0cy51c2VyRWxvICsgZWxvRGVsdGEpO1xuICAgICAgY29uc3QgdXBkYXRlZEJvdEVsbyA9IHVwZGF0ZWRVc2VyRWxvICsgMTAwO1xuXG4gICAgICAvLyBVcGRhdGUgc3RhdGlzdGljc1xuICAgICAgc2V0U3RhdHMoKHByZXYpID0+ICh7XG4gICAgICAgIC4uLnByZXYsXG4gICAgICAgIHVzZXJFbG86IHVwZGF0ZWRVc2VyRWxvLFxuICAgICAgICBtYXRjaGVzUGxheWVkOiBwcmV2Lm1hdGNoZXNQbGF5ZWQgKyAxLFxuICAgICAgICB3aW5zOiByZXN1bHQgPT09ICd3aW4nID8gcHJldi53aW5zICsgMSA6IHByZXYud2lucyxcbiAgICAgICAgbG9zc2VzOiByZXN1bHQgPT09ICdsb3NzJyA/IHByZXYubG9zc2VzICsgMSA6IHByZXYubG9zc2VzLFxuICAgICAgICBkcmF3czogcmVzdWx0ID09PSAnZHJhdycgPyBwcmV2LmRyYXdzICsgMSA6IHByZXYuZHJhd3MsXG4gICAgICAgIHN0cmVhazogcmVzdWx0ID09PSAnd2luJyA/IHByZXYuc3RyZWFrICsgMSA6IDAsXG4gICAgICAgIHJhdGluZ0hpc3Rvcnk6IFtcbiAgICAgICAgICAuLi5wcmV2LnJhdGluZ0hpc3RvcnksXG4gICAgICAgICAge1xuICAgICAgICAgICAgbWF0Y2g6IHByZXYubWF0Y2hlc1BsYXllZCArIDEsXG4gICAgICAgICAgICBlbG86IHVwZGF0ZWRVc2VyRWxvLFxuICAgICAgICAgICAgZGF0ZTogbmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoKSxcbiAgICAgICAgICAgIG9wcG9uZW50RWxvOiBib3RFbG8sXG4gICAgICAgICAgICByZXN1bHQsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pKTtcblxuICAgICAgc2V0R2FtZU92ZXJTdGF0ZSh7XG4gICAgICAgIGlzT3BlbjogdHJ1ZSxcbiAgICAgICAgcmVzdWx0LFxuICAgICAgICByZWFzb24sXG4gICAgICAgIGVsb0NoYW5nZTogZWxvRGVsdGEsXG4gICAgICAgIG5ld1BsYXllckVsbzogdXBkYXRlZFVzZXJFbG8sXG4gICAgICAgIG5ld0JvdEVsbzogdXBkYXRlZEJvdEVsbyxcbiAgICAgIH0pO1xuXG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuICAgIFtwbGF5ZXJDb2xvciwgc3RhdHMudXNlckVsbywgYm90RWxvXVxuICApO1xuXG4gIC8vIFRyaWdnZXIgYm90IHR1cm5cbiAgY29uc3QgdHJpZ2dlckJvdFR1cm4gPSB1c2VDYWxsYmFjayhcbiAgICAoY3VycmVudEdhbWU6IENoZXNzKSA9PiB7XG4gICAgICBpZiAoY3VycmVudEdhbWUuaXNHYW1lT3ZlcigpKSByZXR1cm47XG5cbiAgICAgIHNldElzQm90VGhpbmtpbmcodHJ1ZSk7XG4gICAgICAvLyBSZWFsaXN0aWMgdGhpbmsgdGltZSA0MDBtcyAtIDc1MG1zXG4gICAgICBjb25zdCBkZWxheSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDM1MCkgKyA0MDA7XG5cbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG1vdmUgPSBjaG9vc2VCb3RNb3ZlKGN1cnJlbnRHYW1lLCBib3RFbG8pO1xuICAgICAgICAgIGlmIChtb3ZlKSB7XG4gICAgICAgICAgICBjb25zdCBldmFsQmVmb3JlID0gZXZhbHVhdGVCb2FyZChjdXJyZW50R2FtZSk7XG4gICAgICAgICAgICBjb25zdCBhcHBsaWVkID0gY3VycmVudEdhbWUubW92ZShtb3ZlKTtcbiAgICAgICAgICAgIGlmIChhcHBsaWVkKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGV2YWxBZnRlciA9IGV2YWx1YXRlQm9hcmQoY3VycmVudEdhbWUpO1xuICAgICAgICAgICAgICBzZXRMYXN0TW92ZSh7IGZyb206IGFwcGxpZWQuZnJvbSwgdG86IGFwcGxpZWQudG8gfSk7XG5cbiAgICAgICAgICAgICAgLy8gQXVkaW9cbiAgICAgICAgICAgICAgaWYgKGN1cnJlbnRHYW1lLmluQ2hlY2soKSkge1xuICAgICAgICAgICAgICAgIHNvdW5kRWZmZWN0cy5wbGF5Q2hlY2soKTtcbiAgICAgICAgICAgICAgfSBlbHNlIGlmIChhcHBsaWVkLmNhcHR1cmVkKSB7XG4gICAgICAgICAgICAgICAgc291bmRFZmZlY3RzLnBsYXlDYXB0dXJlKCk7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc291bmRFZmZlY3RzLnBsYXlNb3ZlKCk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBjb25zdCBuZXdFdmFsID0gZXZhbHVhdGVCb2FyZChjdXJyZW50R2FtZSk7XG4gICAgICAgICAgICAgIHNldEN1cnJlbnRFdmFsKG5ld0V2YWwpO1xuXG4gICAgICAgICAgICAgIHNldE1vdmVzKChwcmV2KSA9PiBbXG4gICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBzYW46IGFwcGxpZWQuc2FuLFxuICAgICAgICAgICAgICAgICAgZnJvbTogYXBwbGllZC5mcm9tLFxuICAgICAgICAgICAgICAgICAgdG86IGFwcGxpZWQudG8sXG4gICAgICAgICAgICAgICAgICBwaWVjZTogYXBwbGllZC5waWVjZSxcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBhcHBsaWVkLmNvbG9yLFxuICAgICAgICAgICAgICAgICAgY2FwdHVyZWQ6IGFwcGxpZWQuY2FwdHVyZWQsXG4gICAgICAgICAgICAgICAgICBldmFsQmVmb3JlLFxuICAgICAgICAgICAgICAgICAgZXZhbEFmdGVyLFxuICAgICAgICAgICAgICAgICAgY2xhc3NpZmljYXRpb246ICdnb29kJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgICB1cGRhdGVDYXB0dXJlZFBpZWNlcyhjdXJyZW50R2FtZSk7XG4gICAgICAgICAgICAgIGhhbmRsZUdhbWVPdmVyQ2hlY2soY3VycmVudEdhbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBzZXRJc0JvdFRoaW5raW5nKGZhbHNlKTtcbiAgICAgICAgICBzZXRHYW1lKG5ldyBDaGVzcyhjdXJyZW50R2FtZS5mZW4oKSkpO1xuICAgICAgICB9XG4gICAgICB9LCBkZWxheSk7XG4gICAgfSxcbiAgICBbYm90RWxvLCB1cGRhdGVDYXB0dXJlZFBpZWNlcywgaGFuZGxlR2FtZU92ZXJDaGVja11cbiAgKTtcblxuICAvLyBIYW5kbGUgaHVtYW4gbW92ZVxuICBjb25zdCBoYW5kbGVQbGF5ZXJNb3ZlID0gKGZyb206IHN0cmluZywgdG86IHN0cmluZywgcHJvbW90aW9uPzogc3RyaW5nKTogYm9vbGVhbiA9PiB7XG4gICAgaWYgKGlzQm90VGhpbmtpbmcgfHwgZ2FtZS5pc0dhbWVPdmVyKCkpIHJldHVybiBmYWxzZTtcblxuICAgIC8vIENsZWFyIGFjdGl2ZSBoaW50IG9uIG1vdmVcbiAgICBzZXRIaW50KG51bGwpO1xuXG4gICAgY29uc3QgY2xvbmUgPSBuZXcgQ2hlc3MoZ2FtZS5mZW4oKSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG1vdmVSZXN1bHQgPSBjbG9uZS5tb3ZlKHtcbiAgICAgICAgZnJvbTogZnJvbSBhcyBTcXVhcmUsXG4gICAgICAgIHRvOiB0byBhcyBTcXVhcmUsXG4gICAgICAgIHByb21vdGlvbjogcHJvbW90aW9uIHx8ICdxJyxcbiAgICAgIH0pO1xuXG4gICAgICBpZiAoIW1vdmVSZXN1bHQpIHJldHVybiBmYWxzZTtcblxuICAgICAgLy8gQ2xhc3NpZnkgcGxheWVyIG1vdmUgYWdhaW5zdCBvcHRpbWFsIGVuZ2luZSBjaG9pY2VcbiAgICAgIGNvbnN0IGNsYXNzaWZpY2F0aW9uID0gY2xhc3NpZnlNb3ZlKGdhbWUsIG1vdmVSZXN1bHQuc2FuLCAyKTtcblxuICAgICAgLy8gUGxheSBhdWRpbyBmZWVkYmFja1xuICAgICAgaWYgKGNsb25lLmluQ2hlY2soKSkge1xuICAgICAgICBzb3VuZEVmZmVjdHMucGxheUNoZWNrKCk7XG4gICAgICB9IGVsc2UgaWYgKG1vdmVSZXN1bHQuY2FwdHVyZWQpIHtcbiAgICAgICAgc291bmRFZmZlY3RzLnBsYXlDYXB0dXJlKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzb3VuZEVmZmVjdHMucGxheU1vdmUoKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNsYXNzaWZpY2F0aW9uLmNsYXNzaWZpY2F0aW9uID09PSAnYmx1bmRlcicgJiYgc2hvd0JsdW5kZXJBbGVydHMpIHtcbiAgICAgICAgc291bmRFZmZlY3RzLnBsYXlCbHVuZGVyKCk7XG4gICAgICB9XG5cbiAgICAgIC8vIFVwZGF0ZSBzdGF0ZVxuICAgICAgc2V0TGFzdE1vdmUoeyBmcm9tOiBtb3ZlUmVzdWx0LmZyb20sIHRvOiBtb3ZlUmVzdWx0LnRvIH0pO1xuICAgICAgc2V0TGFzdENvYWNoQ29tbWVudChjbGFzc2lmaWNhdGlvbi5leHBsYW5hdGlvbiB8fCBudWxsKTtcblxuICAgICAgY29uc3QgbmV3RXZhbCA9IGV2YWx1YXRlQm9hcmQoY2xvbmUpO1xuICAgICAgc2V0Q3VycmVudEV2YWwobmV3RXZhbCk7XG5cbiAgICAgIHNldE1vdmVzKChwcmV2KSA9PiBbXG4gICAgICAgIC4uLnByZXYsXG4gICAgICAgIHtcbiAgICAgICAgICBzYW46IG1vdmVSZXN1bHQuc2FuLFxuICAgICAgICAgIGZyb206IG1vdmVSZXN1bHQuZnJvbSxcbiAgICAgICAgICB0bzogbW92ZVJlc3VsdC50byxcbiAgICAgICAgICBwaWVjZTogbW92ZVJlc3VsdC5waWVjZSxcbiAgICAgICAgICBjb2xvcjogbW92ZVJlc3VsdC5jb2xvcixcbiAgICAgICAgICBjYXB0dXJlZDogbW92ZVJlc3VsdC5jYXB0dXJlZCxcbiAgICAgICAgICBldmFsQmVmb3JlOiBjbGFzc2lmaWNhdGlvbi5ldmFsQmVmb3JlLFxuICAgICAgICAgIGV2YWxBZnRlcjogY2xhc3NpZmljYXRpb24uZXZhbEFmdGVyLFxuICAgICAgICAgIGNsYXNzaWZpY2F0aW9uOiBjbGFzc2lmaWNhdGlvbi5jbGFzc2lmaWNhdGlvbixcbiAgICAgICAgICBjb21tZW50OiBjbGFzc2lmaWNhdGlvbi5leHBsYW5hdGlvbixcbiAgICAgICAgICBiZXN0TW92ZVNhbjogY2xhc3NpZmljYXRpb24uYmVzdE1vdmVTYW4sXG4gICAgICAgIH0sXG4gICAgICBdKTtcblxuICAgICAgdXBkYXRlQ2FwdHVyZWRQaWVjZXMoY2xvbmUpO1xuICAgICAgc2V0R2FtZShjbG9uZSk7XG5cbiAgICAgIGNvbnN0IGlzT3ZlciA9IGhhbmRsZUdhbWVPdmVyQ2hlY2soY2xvbmUpO1xuICAgICAgaWYgKCFpc092ZXIpIHtcbiAgICAgICAgdHJpZ2dlckJvdFR1cm4oY2xvbmUpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH07XG5cbiAgLy8gVXNlciBBY3Rpb25zXG4gIGNvbnN0IGhhbmRsZUhpbnQgPSAoKSA9PiB7XG4gICAgaWYgKGdhbWUudHVybigpICE9PSBwbGF5ZXJDb2xvciB8fCBpc0JvdFRoaW5raW5nIHx8IGdhbWUuaXNHYW1lT3ZlcigpKSByZXR1cm47XG4gICAgY29uc3Qgc3VnZ2VzdGlvbiA9IGdlbmVyYXRlSGludChnYW1lKTtcbiAgICBpZiAoc3VnZ2VzdGlvbikge1xuICAgICAgc2V0SGludChzdWdnZXN0aW9uKTtcbiAgICAgIHNldExhc3RDb2FjaENvbW1lbnQoc3VnZ2VzdGlvbi5leHBsYW5hdGlvbik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVuZG8gPSAoKSA9PiB7XG4gICAgaWYgKG1vdmVzLmxlbmd0aCA9PT0gMCB8fCBpc0JvdFRoaW5raW5nKSByZXR1cm47XG4gICAgY29uc3QgY2xvbmUgPSBuZXcgQ2hlc3MoZ2FtZS5mZW4oKSk7XG5cbiAgICAvLyBVbmRvIGJvdCBtb3ZlIGFuZCBwbGF5ZXIgbW92ZVxuICAgIGlmIChjbG9uZS50dXJuKCkgPT09IHBsYXllckNvbG9yKSB7XG4gICAgICBjbG9uZS51bmRvKCk7IC8vIFVuZG8gYm90XG4gICAgICBjbG9uZS51bmRvKCk7IC8vIFVuZG8gcGxheWVyXG4gICAgICBzZXRNb3ZlcygocHJldikgPT4gcHJldi5zbGljZSgwLCBNYXRoLm1heCgwLCBwcmV2Lmxlbmd0aCAtIDIpKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNsb25lLnVuZG8oKTtcbiAgICAgIHNldE1vdmVzKChwcmV2KSA9PiBwcmV2LnNsaWNlKDAsIE1hdGgubWF4KDAsIHByZXYubGVuZ3RoIC0gMSkpKTtcbiAgICB9XG5cbiAgICBzZXRHYW1lKGNsb25lKTtcbiAgICBzZXRIaW50KG51bGwpO1xuICAgIHNldExhc3RNb3ZlKG51bGwpO1xuICAgIHNldEN1cnJlbnRFdmFsKGV2YWx1YXRlQm9hcmQoY2xvbmUpKTtcbiAgICB1cGRhdGVDYXB0dXJlZFBpZWNlcyhjbG9uZSk7XG4gICAgc2V0TGFzdENvYWNoQ29tbWVudCgnTW92ZSByZXRyYWN0ZWQuIFRyeSBhbiBhbHRlcm5hdGl2ZSBjb250aW51YXRpb24uJyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVzaWduID0gKCkgPT4ge1xuICAgIGlmIChnYW1lLmlzR2FtZU92ZXIoKSkgcmV0dXJuO1xuICAgIGNvbnN0IGVsb0RlbHRhID0gLTE0O1xuICAgIGNvbnN0IHVwZGF0ZWRVc2VyRWxvID0gTWF0aC5tYXgoMTAwLCBzdGF0cy51c2VyRWxvICsgZWxvRGVsdGEpO1xuICAgIGNvbnN0IHVwZGF0ZWRCb3RFbG8gPSB1cGRhdGVkVXNlckVsbyArIDEwMDtcblxuICAgIHNldFN0YXRzKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIHVzZXJFbG86IHVwZGF0ZWRVc2VyRWxvLFxuICAgICAgbWF0Y2hlc1BsYXllZDogcHJldi5tYXRjaGVzUGxheWVkICsgMSxcbiAgICAgIGxvc3NlczogcHJldi5sb3NzZXMgKyAxLFxuICAgICAgc3RyZWFrOiAwLFxuICAgICAgcmF0aW5nSGlzdG9yeTogW1xuICAgICAgICAuLi5wcmV2LnJhdGluZ0hpc3RvcnksXG4gICAgICAgIHtcbiAgICAgICAgICBtYXRjaDogcHJldi5tYXRjaGVzUGxheWVkICsgMSxcbiAgICAgICAgICBlbG86IHVwZGF0ZWRVc2VyRWxvLFxuICAgICAgICAgIGRhdGU6IG5ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKCksXG4gICAgICAgICAgb3Bwb25lbnRFbG86IGJvdEVsbyxcbiAgICAgICAgICByZXN1bHQ6ICdsb3NzJyxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfSkpO1xuXG4gICAgc2V0R2FtZU92ZXJTdGF0ZSh7XG4gICAgICBpc09wZW46IHRydWUsXG4gICAgICByZXN1bHQ6ICdsb3NzJyxcbiAgICAgIHJlYXNvbjogJ1BsYXllciBSZXNpZ25lZCcsXG4gICAgICBlbG9DaGFuZ2U6IGVsb0RlbHRhLFxuICAgICAgbmV3UGxheWVyRWxvOiB1cGRhdGVkVXNlckVsbyxcbiAgICAgIG5ld0JvdEVsbzogdXBkYXRlZEJvdEVsbyxcbiAgICB9KTtcbiAgICBzb3VuZEVmZmVjdHMucGxheURlZmVhdCgpO1xuICB9O1xuXG4gIGNvbnN0IHN0YXJ0TmV3R2FtZSA9IChjb2xvcjogUGllY2VDb2xvciA9ICd3JykgPT4ge1xuICAgIGNvbnN0IG5ld0cgPSBuZXcgQ2hlc3MoKTtcbiAgICBzZXRHYW1lKG5ld0cpO1xuICAgIHNldE1vdmVzKFtdKTtcbiAgICBzZXRMYXN0TW92ZShudWxsKTtcbiAgICBzZXRIaW50KG51bGwpO1xuICAgIHNldEN1cnJlbnRFdmFsKDApO1xuICAgIHNldENhcHR1cmVkQnlXaGl0ZShbXSk7XG4gICAgc2V0Q2FwdHVyZWRCeUJsYWNrKFtdKTtcbiAgICBzZXRQbGF5ZXJDb2xvcihjb2xvcik7XG4gICAgc2V0R2FtZU92ZXJTdGF0ZSgocHJldikgPT4gKHsgLi4ucHJldiwgaXNPcGVuOiBmYWxzZSB9KSk7XG4gICAgc2V0TGFzdENvYWNoQ29tbWVudChgTmV3IG1hdGNoIHVuZGVyd2F5IHZzICR7c3RhdHMudXNlckVsbyArIDEwMH0gRWxvIGJvdC5gKTtcblxuICAgIGlmIChjb2xvciA9PT0gJ2InKSB7XG4gICAgICB0cmlnZ2VyQm90VHVybihuZXdHKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRmxpcEJvYXJkID0gKCkgPT4ge1xuICAgIHNldFBsYXllckNvbG9yKChwcmV2KSA9PiAocHJldiA9PT0gJ3cnID8gJ2InIDogJ3cnKSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1bIzExMTMxNV0gdGV4dC1zdG9uZS0yMDAgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgey8qIFRvcCBCYXIgQ29udHJhY3Q6IDMgWm9uZXMgKi99XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtOCBweC00IHNtOnB4LTggcHktMy41IGJvcmRlci1iIGJvcmRlci13aGl0ZS8xMCBiZy1bIzE2MTgxQl0gc3RpY2t5IHRvcC0wIHotNDBcIj5cbiAgICAgICAgey8qIFpvbmUgMTogQnJhbmQgV29yZG1hcmsgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgd2hpdGVzcGFjZS1ub3dyYXAgc2hyaW5rLTBcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtbGcgc206dGV4dC14bCB0ZXh0LXN0b25lLTEwMCB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgQWRhcHRpdmUgQ2hlc3NcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMjAgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBoaWRkZW4gc206aW5saW5lLWJsb2NrXCI+XG4gICAgICAgICAgICArMTAwIER5bmFtaWMgU3BhcnJpbmdcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBab25lIDI6IE5hdmlnYXRpb24gTGlua3MgLyBNb2RlIEluZGljYXRvcnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmZsZXggaXRlbXMtY2VudGVyIGdhcC02IHRleHQteHMgdGV4dC1zdG9uZS00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXN0b25lLTMwMFwiPlBsYXllciBSYXRpbmc6IHtzdGF0cy51c2VyRWxvfTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7Ctzwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwXCI+Qm90IFRhcmdldDoge2JvdEVsb308L3NwYW4+XG4gICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+wrc8L3NwYW4+XG4gICAgICAgICAgPHNwYW4+V2luczoge3N0YXRzLndpbnN9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogWm9uZSAzOiBBY3Rpb25zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNtOmdhcC0zIHNocmluay0wXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICBzZXRJc0V4cG9ydGluZyh0cnVlKTtcbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCBkb3dubG9hZFByb2plY3RaaXAoKTtcbiAgICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBzZXRJc0V4cG9ydGluZyhmYWxzZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNFeHBvcnRpbmd9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXN0b25lLTEwMCBiZy1zdG9uZS04MDAgaG92ZXI6Ymctc3RvbmUtNzAwIGFjdGl2ZTpzY2FsZS05NSBib3JkZXIgYm9yZGVyLXdoaXRlLzE1IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgc2hhZG93LXNtIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgdGl0bGU9XCJEb3dubG9hZCBmdWxsIHByb2plY3Qgc291cmNlIGNvZGUgYXMgLnppcFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPntpc0V4cG9ydGluZyA/ICdQYWNraW5nIFppcC4uLicgOiAnRG93bmxvYWQgQ29kZSAoLnppcCknfTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0YXJ0TmV3R2FtZShwbGF5ZXJDb2xvcil9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXN0b25lLTkwMCBiZy1bI0Y0RjJCQV0gaG92ZXI6YmcteWVsbG93LTIwMCBhY3RpdmU6c2NhbGUtOTUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCBzaGFkb3ctc21cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIE5ldyBHYW1lXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIHsvKiBNYWluIENvbnRhaW5lciAqL31cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy03eGwgdy1mdWxsIG14LWF1dG8gcC0zIHNtOnAtNiBsZzpwLTggZmxleCBmbGV4LWNvbCBnYXAtNlwiPlxuICAgICAgICBcbiAgICAgICAgey8qIFJhdGluZ3MgSGVhZGVyIC8gSFVEICovfVxuICAgICAgICA8RWxvSGVhZGVyXG4gICAgICAgICAgc3RhdHM9e3N0YXRzfVxuICAgICAgICAgIGJvdEVsbz17Ym90RWxvfVxuICAgICAgICAgIHBsYXllckNvbG9yPXtwbGF5ZXJDb2xvcn1cbiAgICAgICAgICB0dXJuPXtnYW1lLnR1cm4oKX1cbiAgICAgICAgICBpc0JvdFRoaW5raW5nPXtpc0JvdFRoaW5raW5nfVxuICAgICAgICAgIGNhcHR1cmVkQnlXaGl0ZT17Y2FwdHVyZWRCeVdoaXRlfVxuICAgICAgICAgIGNhcHR1cmVkQnlCbGFjaz17Y2FwdHVyZWRCeUJsYWNrfVxuICAgICAgICAvPlxuXG4gICAgICAgIHsvKiBDZW50cmFsIEFyZW5hOiBTaWRlLWJ5LXNpZGUgb24gZGVza3RvcCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBnYXAtNiBpdGVtcy1zdGFydFwiPlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBMZWZ0IC8gQ2VudGVyIENvbHVtbjogRXZhbHVhdGlvbiBCYXIgKyBDaGVzc2JvYXJkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyB4bDpjb2wtc3Bhbi04IGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHsvKiBBY3RpdmUgSGludCBCYW5uZXIgKi99XG4gICAgICAgICAgICB7aGludCAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LVs1NDBweF0gbWItMyBwLTMgYmctY3lhbi05NTAvNDAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8zMCByb3VuZGVkLXhsIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0xNTBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtY3lhbi0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wIHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPntoaW50LnNhbn06PC9zdHJvbmc+IHtoaW50LmV4cGxhbmF0aW9ufVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEhpbnQobnVsbCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXN0b25lLTQwMCBob3Zlcjp0ZXh0LXN0b25lLTIwMCB0ZXh0LVsxMXB4XSB1bmRlcmxpbmUgc2hyaW5rLTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIERpc21pc3NcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogQm9hcmQgYW5kIEV2YWwgQmFyIFdyYXBwZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHNtOmdhcC00IHctZnVsbFwiPlxuICAgICAgICAgICAgICB7LyogTGl2ZSBFdmFsdWF0aW9uIEJhciAqL31cbiAgICAgICAgICAgICAgPEV2YWxCYXIgZXZhbENwPXtjdXJyZW50RXZhbH0gcGxheWVyQ29sb3I9e3BsYXllckNvbG9yfSAvPlxuXG4gICAgICAgICAgICAgIHsvKiBUaGUgQ2hlc3MgQm9hcmQgd2l0aCByZXF1ZXN0ZWQgbGlnaHQgeWVsbG93IGFuZCBsaWdodCBncmVlbiB0aWxlcyAqL31cbiAgICAgICAgICAgICAgPENoZXNzQm9hcmRcbiAgICAgICAgICAgICAgICBnYW1lPXtnYW1lfVxuICAgICAgICAgICAgICAgIG9uTW92ZT17aGFuZGxlUGxheWVyTW92ZX1cbiAgICAgICAgICAgICAgICBwbGF5ZXJDb2xvcj17cGxheWVyQ29sb3J9XG4gICAgICAgICAgICAgICAgaXNCb3RUaGlua2luZz17aXNCb3RUaGlua2luZ31cbiAgICAgICAgICAgICAgICBsYXN0TW92ZT17bGFzdE1vdmV9XG4gICAgICAgICAgICAgICAgaGludD17aGludH1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17Z2FtZS5pc0dhbWVPdmVyKCl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJvYXJkIExlZ2VuZCAvIFF1aWNrIEluZm8gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1bNTQwcHhdIG10LTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzExcHhdIHRleHQtc3RvbmUtNDAwIHB4LTEgZm9udC1tb25vLW51bXNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQtc20gYmctWyNGNEYyQkFdXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkxpZ2h0IFRpbGU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQtc20gYmctWyM3Nzk1NTZdXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkdyZWVuIFRpbGU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4+Q2xpY2sgb3IgZHJhZyBwaWVjZXMgdG8gbW92ZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFJpZ2h0IENvbHVtbjogTW92ZSBIaXN0b3J5LCBBbmFseXNpcyAmIEdhbWUgQ29udHJvbHMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IHhsOmNvbC1zcGFuLTQgZmxleCBmbGV4LWNvbCBnYXAtNFwiPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogQWN0aW9uIENvbnRyb2xzIFRvb2xiYXIgKi99XG4gICAgICAgICAgICA8R2FtZUNvbnRyb2xzXG4gICAgICAgICAgICAgIG9uSGludD17aGFuZGxlSGludH1cbiAgICAgICAgICAgICAgb25VbmRvPXtoYW5kbGVVbmRvfVxuICAgICAgICAgICAgICBvblJlc2lnbj17aGFuZGxlUmVzaWdufVxuICAgICAgICAgICAgICBvbk5ld0dhbWU9eygpID0+IHN0YXJ0TmV3R2FtZShwbGF5ZXJDb2xvcil9XG4gICAgICAgICAgICAgIG9uRmxpcEJvYXJkPXtoYW5kbGVGbGlwQm9hcmR9XG4gICAgICAgICAgICAgIG9uVG9nZ2xlU291bmQ9eygpID0+IHNldElzU291bmRNdXRlZCgocHJldikgPT4gIXByZXYpfVxuICAgICAgICAgICAgICBvbk9wZW5TZXR0aW5ncz17KCkgPT4gc2V0SXNTZXR0aW5nc09wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgIGlzU291bmRNdXRlZD17aXNTb3VuZE11dGVkfVxuICAgICAgICAgICAgICBjYW5VbmRvPXttb3Zlcy5sZW5ndGggPiAwfVxuICAgICAgICAgICAgICBpc0dhbWVPdmVyPXtnYW1lLmlzR2FtZU92ZXIoKX1cbiAgICAgICAgICAgICAgaXNCb3RUaGlua2luZz17aXNCb3RUaGlua2luZ31cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBNb3ZlIEhpc3RvcnkgJiBUYWN0aWNhbCBFdmFsdWF0aW9uIEZlZWQgKi99XG4gICAgICAgICAgICA8TW92ZUhpc3RvcnkgbW92ZXM9e21vdmVzfSBsYXN0RXhwbGFuYXRpb249e2xhc3RDb2FjaENvbW1lbnR9IC8+XG5cbiAgICAgICAgICAgIHsvKiBSYXRpbmcgUHJvZ3Jlc3Npb24gQ2FyZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyMxQTFEMjBdIGJvcmRlciBib3JkZXItd2hpdGUvMTAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zdG9uZS00MDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgRHluYW1pYyBFbG8gR3Jvd3RoXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1hbWJlci00MDAgZm9udC1tb25vLW51bXMgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICBUYXJnZXQ6IHtib3RFbG99IEJvdFxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zdG9uZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgQXMgeW91ciBza2lsbCBkZXZlbG9wcywgbWF0Y2ggd2lucyB3aWxsIGJvb3N0IHlvdXIgcmF0aW5nIGFuZCB0aGUgYm90IHdpbGwgaW1tZWRpYXRlbHkgc2NhbGUgaXRzIHNlYXJjaCBkZXB0aCBhbmQgdGFjdGljYWwgdmlnaWxhbmNlIHRvIHN0YXkgMTAwIEVsbyBhYm92ZSB5b3UuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L21haW4+XG5cbiAgICAgIHsvKiBHYW1lIE92ZXIgTW9kYWwgKi99XG4gICAgICA8R2FtZU92ZXJNb2RhbFxuICAgICAgICBpc09wZW49e2dhbWVPdmVyU3RhdGUuaXNPcGVufVxuICAgICAgICByZXN1bHQ9e2dhbWVPdmVyU3RhdGUucmVzdWx0fVxuICAgICAgICByZWFzb249e2dhbWVPdmVyU3RhdGUucmVhc29ufVxuICAgICAgICBlbG9DaGFuZ2U9e2dhbWVPdmVyU3RhdGUuZWxvQ2hhbmdlfVxuICAgICAgICBuZXdQbGF5ZXJFbG89e2dhbWVPdmVyU3RhdGUubmV3UGxheWVyRWxvfVxuICAgICAgICBuZXdCb3RFbG89e2dhbWVPdmVyU3RhdGUubmV3Qm90RWxvfVxuICAgICAgICBtb3Zlcz17bW92ZXN9XG4gICAgICAgIG9uUGxheUFnYWluPXsoKSA9PiBzdGFydE5ld0dhbWUocGxheWVyQ29sb3IpfVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRHYW1lT3ZlclN0YXRlKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBpc09wZW46IGZhbHNlIH0pKX1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBTZXR0aW5ncyBNb2RhbCAqL31cbiAgICAgIDxTZXR0aW5nc01vZGFsXG4gICAgICAgIGlzT3Blbj17aXNTZXR0aW5nc09wZW59XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzU2V0dGluZ3NPcGVuKGZhbHNlKX1cbiAgICAgICAgc3RhdHM9e3N0YXRzfVxuICAgICAgICBvblVwZGF0ZVBsYXllckVsbz17KG5ld0VsbykgPT4ge1xuICAgICAgICAgIHNldFN0YXRzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB1c2VyRWxvOiBuZXdFbG8gfSkpO1xuICAgICAgICAgIHNldExhc3RDb2FjaENvbW1lbnQoYFJhdGluZyBhZGp1c3RlZCB0byAke25ld0Vsb30gRWxvLiBCb3QgdXBkYXRlZCB0byAke25ld0VsbyArIDEwMH0gRWxvLmApO1xuICAgICAgICB9fVxuICAgICAgICBvblJlc2V0U3RhdHM9eygpID0+IHtcbiAgICAgICAgICBzZXRTdGF0cyhERUZBVUxUX1NUQVRTKTtcbiAgICAgICAgICBzdGFydE5ld0dhbWUoJ3cnKTtcbiAgICAgICAgfX1cbiAgICAgICAgaXNTb3VuZE11dGVkPXtpc1NvdW5kTXV0ZWR9XG4gICAgICAgIG9uVG9nZ2xlU291bmQ9eygpID0+IHNldElzU291bmRNdXRlZCgocHJldikgPT4gIXByZXYpfVxuICAgICAgICBzaG93Qmx1bmRlckFsZXJ0cz17c2hvd0JsdW5kZXJBbGVydHN9XG4gICAgICAgIG9uVG9nZ2xlQmx1bmRlckFsZXJ0cz17KCkgPT4gc2V0U2hvd0JsdW5kZXJBbGVydHMoKHByZXYpID0+ICFwcmV2KX1cbiAgICAgICAgb25Eb3dubG9hZFNvdXJjZT17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnL1NPVVJDRV9DT0RFLm1kJyk7XG4gICAgICAgICAgICBsZXQgY29udGVudCA9ICcnO1xuICAgICAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgICBjb250ZW50ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghY29udGVudCkge1xuICAgICAgICAgICAgICBjb250ZW50ID0gJyMgQWRhcHRpdmUgQ2hlc3MgU291cmNlIENvZGVcXG5DaGVjayByZXBvc2l0b3J5IGZpbGVzLic7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2NvbnRlbnRdLCB7IHR5cGU6ICd0ZXh0L21hcmtkb3duO2NoYXJzZXQ9dXRmLTgnIH0pO1xuICAgICAgICAgICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICAgICAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICAgICAgICBsaW5rLmhyZWYgPSB1cmw7XG4gICAgICAgICAgICBsaW5rLmRvd25sb2FkID0gJ2FkYXB0aXZlX2NoZXNzX3NvdXJjZV9jb2RlLm1kJztcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgICAgICAgICBsaW5rLmNsaWNrKCk7XG4gICAgICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGxpbmspO1xuICAgICAgICAgICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Rvd25sb2FkIGVycm9yJywgZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9fVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==