const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
import { ChessPiece } from "/src/components/ChessPieces.tsx";
import { getCalibrationForElo } from "/src/engine/botEngine.ts";
import { Trophy, Flame, Swords, Bot, User } from "/node_modules/.vite/deps/lucide-react.js?v=c3d5a9dc";
var _jsxFileName = "/app/applet/src/components/EloHeader.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
export const EloHeader = ({ stats, botElo, playerColor, turn, isBotThinking, capturedByWhite, capturedByBlack }) => {
	const botTier = getCalibrationForElo(botElo).tierName;
	const isPlayerTurn = turn === playerColor;
	// Calculate material points
	const pieceValues = {
		p: 1,
		n: 3,
		b: 3,
		r: 5,
		q: 9,
		k: 0
	};
	const whiteMaterial = capturedByWhite.reduce((sum, p) => sum + pieceValues[p], 0);
	const blackMaterial = capturedByBlack.reduce((sum, p) => sum + pieceValues[p], 0);
	const whiteAdvantage = whiteMaterial - blackMaterial;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "w-full bg-[#1A1D20] border border-white/10 rounded-2xl p-3 sm:p-4 shadow-xl",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-6",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 w-full sm:w-auto",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-600/30 to-teal-800/40 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-md",
							children: /* @__PURE__ */ _jsxDEV(Bot, { className: "w-6 h-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 43,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 13
						}, this), isBotThinking && /* @__PURE__ */ _jsxDEV("span", {
							className: "absolute -top-1 -right-1 flex h-3.5 w-3.5",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { className: "relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-display font-semibold text-stone-200 text-sm sm:text-base",
								children: "Adaptive Bot"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-mono-nums font-semibold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/20",
								children: [botElo, " ELO"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 mt-0.5 text-xs text-stone-400",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: botTier }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": "true",
									children: "·"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-emerald-400 font-mono-nums",
									children: "+100 handicap"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1 mt-1.5 h-5",
							children: playerColor === "w" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [capturedByBlack.slice(0, 8).map((p, i) => /* @__PURE__ */ _jsxDEV("div", {
								className: "w-3.5 h-3.5 opacity-80",
								children: /* @__PURE__ */ _jsxDEV(ChessPiece, {
									type: p,
									color: "w"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 23
								}, this)
							}, i, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 21
							}, this)), whiteAdvantage < 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-mono-nums font-bold text-stone-300 ml-1",
								children: ["+", Math.abs(whiteAdvantage)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [capturedByWhite.slice(0, 8).map((p, i) => /* @__PURE__ */ _jsxDEV("div", {
								className: "w-3.5 h-3.5 opacity-80",
								children: /* @__PURE__ */ _jsxDEV(ChessPiece, {
									type: p,
									color: "b"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 23
								}, this)
							}, i, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 21
							}, this)), whiteAdvantage > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-mono-nums font-bold text-stone-300 ml-1",
								children: ["+", whiteAdvantage]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-row sm:flex-col items-center justify-center gap-2 text-center py-1 px-3 bg-stone-900/60 rounded-xl border border-white/5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5 text-xs font-medium",
						children: [/* @__PURE__ */ _jsxDEV(Swords, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: isPlayerTurn ? "text-amber-300 font-semibold" : "text-stone-400",
							children: isBotThinking ? "Bot thinking..." : isPlayerTurn ? "Your Turn" : "Bot Turn"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3 text-[11px] font-mono-nums text-stone-400",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ _jsxDEV(Trophy, { className: "w-3 h-3 text-stone-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 15
								}, this),
								stats.wins,
								"W - ",
								stats.losses,
								"L - ",
								stats.draws,
								"D"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 13
						}, this), stats.streak > 1 && /* @__PURE__ */ _jsxDEV("span", {
							className: "flex items-center gap-0.5 text-amber-400 font-semibold",
							children: [
								/* @__PURE__ */ _jsxDEV(Flame, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 17
								}, this),
								stats.streak,
								" streak"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 w-full sm:w-auto sm:text-right flex-row sm:flex-row-reverse",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-yellow-600/30 border border-yellow-500/30 flex items-center justify-center text-amber-300 shadow-md",
						children: /* @__PURE__ */ _jsxDEV(User, { className: "w-6 h-6" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center sm:justify-end gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-display font-semibold text-stone-200 text-sm sm:text-base",
								children: "Player (You)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-mono-nums font-semibold px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-300 border border-amber-500/20",
								children: [stats.userElo, " ELO"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center sm:justify-end gap-2 mt-0.5 text-xs text-stone-400",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: playerColor === "w" ? "Playing White" : "Playing Black" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": "true",
									children: "·"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: ["Match #", stats.matchesPlayed + 1] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 139,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center sm:justify-end gap-1 mt-1.5 h-5",
							children: playerColor === "w" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [capturedByWhite.slice(0, 8).map((p, i) => /* @__PURE__ */ _jsxDEV("div", {
								className: "w-3.5 h-3.5 opacity-80",
								children: /* @__PURE__ */ _jsxDEV(ChessPiece, {
									type: p,
									color: "b"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 23
								}, this)
							}, i, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 21
							}, this)), whiteAdvantage > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-mono-nums font-bold text-stone-300 ml-1",
								children: ["+", whiteAdvantage]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [capturedByBlack.slice(0, 8).map((p, i) => /* @__PURE__ */ _jsxDEV("div", {
								className: "w-3.5 h-3.5 opacity-80",
								children: /* @__PURE__ */ _jsxDEV(ChessPiece, {
									type: p,
									color: "w"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 23
								}, this)
							}, i, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 21
							}, this)), whiteAdvantage < 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-mono-nums font-bold text-stone-300 ml-1",
								children: ["+", Math.abs(whiteAdvantage)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsUUFBUSxPQUFPLFFBQVEsS0FBSyxZQUFZOzs7QUFZakQsT0FBTyxNQUFNLGFBQXVDLEVBQ2xELE9BQ0EsUUFDQSxhQUNBLE1BQ0EsZUFDQSxpQkFDQSxzQkFDSTtDQUNKLE1BQU0sVUFBVSxxQkFBcUIsTUFBTSxDQUFDLENBQUM7Q0FDN0MsTUFBTSxlQUFlLFNBQVM7O0NBRzlCLE1BQU0sY0FBeUM7RUFBRSxHQUFHO0VBQUcsR0FBRztFQUFHLEdBQUc7RUFBRyxHQUFHO0VBQUcsR0FBRztFQUFHLEdBQUc7Q0FBRTtDQUNwRixNQUFNLGdCQUFnQixnQkFBZ0IsUUFBUSxLQUFLLE1BQU0sTUFBTSxZQUFZLElBQUksQ0FBQztDQUNoRixNQUFNLGdCQUFnQixnQkFBZ0IsUUFBUSxLQUFLLE1BQU0sTUFBTSxZQUFZLElBQUksQ0FBQztDQUNoRixNQUFNLGlCQUFpQixnQkFBZ0I7Q0FFdkMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFHRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxLQUFELEVBQUssV0FBVSxVQUFXOzs7OztNQUN2Qjs7OztnQkFDSixpQkFDQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx5RkFBK0Y7Ozs7aUJBQy9HLHdCQUFDLFFBQUQsRUFBTSxXQUFVLCtEQUFxRTs7OztlQUNqRjs7Ozs7Y0FFTDs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUU7T0FFM0U7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0csUUFBTyxNQUNKOzs7OztlQUNIOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQsWUFBTyxRQUFjOzs7OztRQUNyQix3QkFBQyxRQUFEO1NBQU0sZUFBWTttQkFBTztRQUFPOzs7OztRQUNoQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBa0M7UUFBbUI7Ozs7O09BQ2xFOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixnQkFBZ0IsTUFDZixnREFDRyxnQkFBZ0IsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUNuQyx3QkFBQyxPQUFEO1FBQWEsV0FBVTtrQkFDckIsd0JBQUMsWUFBRDtTQUFZLE1BQU07U0FBRyxPQUFNO1FBQUs7Ozs7O09BQzdCLEdBRks7Ozs7Y0FFTCxDQUNOLEdBQ0EsaUJBQWlCLEtBQ2hCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUEyRSxLQUN2RSxLQUFLLElBQUksY0FBYyxDQUNyQjs7Ozs7ZUFFUjs7OztrQkFFRixnREFDRyxnQkFBZ0IsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUNuQyx3QkFBQyxPQUFEO1FBQWEsV0FBVTtrQkFDckIsd0JBQUMsWUFBRDtTQUFZLE1BQU07U0FBRyxPQUFNO1FBQUs7Ozs7O09BQzdCLEdBRks7Ozs7Y0FFTCxDQUNOLEdBQ0EsaUJBQWlCLEtBQ2hCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUEyRSxLQUN2RSxjQUNFOzs7OztlQUVSOzs7OztNQUVEOzs7OztLQUNGOzs7O2FBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDZCQUE4Qjs7OztnQkFDaEQsd0JBQUMsUUFBRDtPQUFNLFdBQVcsZUFBZSxpQ0FBaUM7aUJBQzlELGdCQUFnQixvQkFBb0IsZUFBZSxjQUFjO01BQzlEOzs7O2NBQ0g7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEI7UUFDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx5QkFBMEI7Ozs7O1FBQzNDLE1BQU07UUFBSztRQUFLLE1BQU07UUFBTztRQUFLLE1BQU07UUFBTTtPQUMzQzs7Ozs7Z0JBQ0wsTUFBTSxTQUFTLEtBQ2Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCO1FBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7Ozs7UUFDM0IsTUFBTTtRQUFPO09BQ1Y7Ozs7O2NBRUw7Ozs7O2FBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztLQUN4Qjs7OztlQUNMLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpRTtPQUUzRTs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRyxNQUFNLFNBQVEsTUFDWDs7Ozs7ZUFDSDs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFELFlBQU8sZ0JBQWdCLE1BQU0sa0JBQWtCLGdCQUFzQjs7Ozs7UUFDckUsd0JBQUMsUUFBRDtTQUFNLGVBQVk7bUJBQU87UUFBTzs7Ozs7UUFDaEMsd0JBQUMsUUFBRCxhQUFNLFdBQVEsTUFBTSxnQkFBZ0IsQ0FBUTs7Ozs7T0FDekM7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLGdCQUFnQixNQUNmLGdEQUNHLGdCQUFnQixNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQ25DLHdCQUFDLE9BQUQ7UUFBYSxXQUFVO2tCQUNyQix3QkFBQyxZQUFEO1NBQVksTUFBTTtTQUFHLE9BQU07UUFBSzs7Ozs7T0FDN0IsR0FGSzs7OztjQUVMLENBQ04sR0FDQSxpQkFBaUIsS0FDaEIsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQTJFLEtBQ3ZFLGNBQ0U7Ozs7O2VBRVI7Ozs7a0JBRUYsZ0RBQ0csZ0JBQWdCLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsTUFDbkMsd0JBQUMsT0FBRDtRQUFhLFdBQVU7a0JBQ3JCLHdCQUFDLFlBQUQ7U0FBWSxNQUFNO1NBQUcsT0FBTTtRQUFLOzs7OztPQUM3QixHQUZLOzs7O2NBRUwsQ0FDTixHQUNBLGlCQUFpQixLQUNoQix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FBMkUsS0FDdkUsS0FBSyxJQUFJLGNBQWMsQ0FDckI7Ozs7O2VBRVI7Ozs7O01BRUQ7Ozs7O0tBQ0Y7Ozs7YUFDRjs7Ozs7O0dBRUY7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkVsb0hlYWRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IENoZXNzUGllY2UgfSBmcm9tICcuL0NoZXNzUGllY2VzJztcbmltcG9ydCB7IFBpZWNlVHlwZSwgUGllY2VDb2xvciwgUGxheWVyU3RhdHMgfSBmcm9tICcuLi90eXBlcy9jaGVzcyc7XG5pbXBvcnQgeyBnZXRDYWxpYnJhdGlvbkZvckVsbyB9IGZyb20gJy4uL2VuZ2luZS9ib3RFbmdpbmUnO1xuaW1wb3J0IHsgVHJvcGh5LCBGbGFtZSwgU3dvcmRzLCBCb3QsIFVzZXIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbnRlcmZhY2UgRWxvSGVhZGVyUHJvcHMge1xuICBzdGF0czogUGxheWVyU3RhdHM7XG4gIGJvdEVsbzogbnVtYmVyO1xuICBwbGF5ZXJDb2xvcjogUGllY2VDb2xvcjtcbiAgdHVybjogUGllY2VDb2xvcjtcbiAgaXNCb3RUaGlua2luZzogYm9vbGVhbjtcbiAgY2FwdHVyZWRCeVdoaXRlOiBQaWVjZVR5cGVbXTtcbiAgY2FwdHVyZWRCeUJsYWNrOiBQaWVjZVR5cGVbXTtcbn1cblxuZXhwb3J0IGNvbnN0IEVsb0hlYWRlcjogUmVhY3QuRkM8RWxvSGVhZGVyUHJvcHM+ID0gKHtcbiAgc3RhdHMsXG4gIGJvdEVsbyxcbiAgcGxheWVyQ29sb3IsXG4gIHR1cm4sXG4gIGlzQm90VGhpbmtpbmcsXG4gIGNhcHR1cmVkQnlXaGl0ZSxcbiAgY2FwdHVyZWRCeUJsYWNrLFxufSkgPT4ge1xuICBjb25zdCBib3RUaWVyID0gZ2V0Q2FsaWJyYXRpb25Gb3JFbG8oYm90RWxvKS50aWVyTmFtZTtcbiAgY29uc3QgaXNQbGF5ZXJUdXJuID0gdHVybiA9PT0gcGxheWVyQ29sb3I7XG5cbiAgLy8gQ2FsY3VsYXRlIG1hdGVyaWFsIHBvaW50c1xuICBjb25zdCBwaWVjZVZhbHVlczogUmVjb3JkPFBpZWNlVHlwZSwgbnVtYmVyPiA9IHsgcDogMSwgbjogMywgYjogMywgcjogNSwgcTogOSwgazogMCB9O1xuICBjb25zdCB3aGl0ZU1hdGVyaWFsID0gY2FwdHVyZWRCeVdoaXRlLnJlZHVjZSgoc3VtLCBwKSA9PiBzdW0gKyBwaWVjZVZhbHVlc1twXSwgMCk7XG4gIGNvbnN0IGJsYWNrTWF0ZXJpYWwgPSBjYXB0dXJlZEJ5QmxhY2sucmVkdWNlKChzdW0sIHApID0+IHN1bSArIHBpZWNlVmFsdWVzW3BdLCAwKTtcbiAgY29uc3Qgd2hpdGVBZHZhbnRhZ2UgPSB3aGl0ZU1hdGVyaWFsIC0gYmxhY2tNYXRlcmlhbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLVsjMUExRDIwXSBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHJvdW5kZWQtMnhsIHAtMyBzbTpwLTQgc2hhZG93LXhsXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBzbTpnYXAtNlwiPlxuICAgICAgICBcbiAgICAgICAgey8qIEJvdCBQcm9maWxlIENhcmQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIHNtOnctYXV0b1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1lbWVyYWxkLTYwMC8zMCB0by10ZWFsLTgwMC80MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZW1lcmFsZC00MDAgc2hhZG93LW1kXCI+XG4gICAgICAgICAgICAgIDxCb3QgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHtpc0JvdFRoaW5raW5nICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xIC1yaWdodC0xIGZsZXggaC0zLjUgdy0zLjVcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhbmltYXRlLXBpbmcgYWJzb2x1dGUgaW5saW5lLWZsZXggaC1mdWxsIHctZnVsbCByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDAgb3BhY2l0eS03NVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgaC0zLjUgdy0zLjUgYmctZW1lcmFsZC01MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtc2VtaWJvbGQgdGV4dC1zdG9uZS0yMDAgdGV4dC1zbSBzbTp0ZXh0LWJhc2VcIj5cbiAgICAgICAgICAgICAgICBBZGFwdGl2ZSBCb3RcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8tbnVtcyBmb250LXNlbWlib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgYmctZW1lcmFsZC01MDAvMTUgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzIwXCI+XG4gICAgICAgICAgICAgICAge2JvdEVsb30gRUxPXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0wLjUgdGV4dC14cyB0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgICAgICA8c3Bhbj57Ym90VGllcn08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPsK3PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtbW9uby1udW1zXCI+KzEwMCBoYW5kaWNhcDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUGllY2VzIGNhcHR1cmVkIGJ5IEJvdCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgbXQtMS41IGgtNVwiPlxuICAgICAgICAgICAgICB7cGxheWVyQ29sb3IgPT09ICd3JyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAge2NhcHR1cmVkQnlCbGFjay5zbGljZSgwLCA4KS5tYXAoKHAsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInctMy41IGgtMy41IG9wYWNpdHktODBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlc3NQaWVjZSB0eXBlPXtwfSBjb2xvcj1cIndcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAge3doaXRlQWR2YW50YWdlIDwgMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9uby1udW1zIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTMwMCBtbC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgK3tNYXRoLmFicyh3aGl0ZUFkdmFudGFnZSl9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIHtjYXB0dXJlZEJ5V2hpdGUuc2xpY2UoMCwgOCkubWFwKChwLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBvcGFjaXR5LTgwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZXNzUGllY2UgdHlwZT17cH0gY29sb3I9XCJiXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIHt3aGl0ZUFkdmFudGFnZSA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8tbnVtcyBmb250LWJvbGQgdGV4dC1zdG9uZS0zMDAgbWwtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICt7d2hpdGVBZHZhbnRhZ2V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE1hdGNoIENlbnRlciAvIFN0YXR1cyBCYWRnZSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IHNtOmZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0ZXh0LWNlbnRlciBweS0xIHB4LTMgYmctc3RvbmUtOTAwLzYwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci13aGl0ZS81XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgIDxTd29yZHMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtpc1BsYXllclR1cm4gPyAndGV4dC1hbWJlci0zMDAgZm9udC1zZW1pYm9sZCcgOiAndGV4dC1zdG9uZS00MDAnfT5cbiAgICAgICAgICAgICAge2lzQm90VGhpbmtpbmcgPyAnQm90IHRoaW5raW5nLi4uJyA6IGlzUGxheWVyVHVybiA/ICdZb3VyIFR1cm4nIDogJ0JvdCBUdXJuJ31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtWzExcHhdIGZvbnQtbW9uby1udW1zIHRleHQtc3RvbmUtNDAwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICA8VHJvcGh5IGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1zdG9uZS01MDBcIiAvPlxuICAgICAgICAgICAgICB7c3RhdHMud2luc31XIC0ge3N0YXRzLmxvc3Nlc31MIC0ge3N0YXRzLmRyYXdzfURcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIHtzdGF0cy5zdHJlYWsgPiAxICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSB0ZXh0LWFtYmVyLTQwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgPEZsYW1lIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgIHtzdGF0cy5zdHJlYWt9IHN0cmVha1xuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVXNlciBQcm9maWxlIENhcmQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIHNtOnctYXV0byBzbTp0ZXh0LXJpZ2h0IGZsZXgtcm93IHNtOmZsZXgtcm93LXJldmVyc2VcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYW1iZXItNTAwLzIwIHRvLXllbGxvdy02MDAvMzAgYm9yZGVyIGJvcmRlci15ZWxsb3ctNTAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYW1iZXItMzAwIHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc206anVzdGlmeS1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtc2VtaWJvbGQgdGV4dC1zdG9uZS0yMDAgdGV4dC1zbSBzbTp0ZXh0LWJhc2VcIj5cbiAgICAgICAgICAgICAgICBQbGF5ZXIgKFlvdSlcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8tbnVtcyBmb250LXNlbWlib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgYmctYW1iZXItNTAwLzE1IHRleHQtYW1iZXItMzAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwXCI+XG4gICAgICAgICAgICAgICAge3N0YXRzLnVzZXJFbG99IEVMT1xuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc206anVzdGlmeS1lbmQgZ2FwLTIgbXQtMC41IHRleHQteHMgdGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICAgICAgPHNwYW4+e3BsYXllckNvbG9yID09PSAndycgPyAnUGxheWluZyBXaGl0ZScgOiAnUGxheWluZyBCbGFjayd9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+TWF0Y2ggI3tzdGF0cy5tYXRjaGVzUGxheWVkICsgMX08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFBpZWNlcyBjYXB0dXJlZCBieSBQbGF5ZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNtOmp1c3RpZnktZW5kIGdhcC0xIG10LTEuNSBoLTVcIj5cbiAgICAgICAgICAgICAge3BsYXllckNvbG9yID09PSAndycgPyAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIHtjYXB0dXJlZEJ5V2hpdGUuc2xpY2UoMCwgOCkubWFwKChwLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBvcGFjaXR5LTgwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZXNzUGllY2UgdHlwZT17cH0gY29sb3I9XCJiXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIHt3aGl0ZUFkdmFudGFnZSA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8tbnVtcyBmb250LWJvbGQgdGV4dC1zdG9uZS0zMDAgbWwtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICt7d2hpdGVBZHZhbnRhZ2V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIHtjYXB0dXJlZEJ5QmxhY2suc2xpY2UoMCwgOCkubWFwKChwLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBvcGFjaXR5LTgwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZXNzUGllY2UgdHlwZT17cH0gY29sb3I9XCJ3XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIHt3aGl0ZUFkdmFudGFnZSA8IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8tbnVtcyBmb250LWJvbGQgdGV4dC1zdG9uZS0zMDAgbWwtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICt7TWF0aC5hYnMod2hpdGVBZHZhbnRhZ2UpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=