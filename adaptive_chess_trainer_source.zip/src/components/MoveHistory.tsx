const React = __vite__cjsImport0_react; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
import { CheckCircle2, AlertTriangle, AlertOctagon, HelpCircle, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=c3d5a9dc";
var _jsxFileName = "/app/applet/src/components/MoveHistory.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
export const MoveHistory = ({ moves, lastExplanation }) => {
	const scrollRef = useRef(null);
	useEffect(() => {
		if (scrollRef.current) {
			scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
		}
	}, [moves]);
	// Group moves into pairs (White & Black)
	const movePairs = [];
	for (let i = 0; i < moves.length; i += 2) {
		movePairs.push({
			num: Math.floor(i / 2) + 1,
			white: moves[i],
			black: moves[i + 1]
		});
	}
	const renderBadge = (move) => {
		if (!move || !move.classification) return null;
		switch (move.classification) {
			case "best": return /* @__PURE__ */ _jsxDEV("span", {
				title: "Best Move",
				className: "text-emerald-400 inline-flex items-center ml-1",
				children: /* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3 h-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 11
			}, this);
			case "good": return /* @__PURE__ */ _jsxDEV("span", {
				title: "Good Move",
				className: "text-teal-400 inline-flex items-center ml-1",
				children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3 h-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 11
			}, this);
			case "inaccuracy": return /* @__PURE__ */ _jsxDEV("span", {
				title: "Inaccuracy",
				className: "text-yellow-400 inline-flex items-center ml-1",
				children: /* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-3 h-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 11
			}, this);
			case "mistake": return /* @__PURE__ */ _jsxDEV("span", {
				title: "Mistake",
				className: "text-orange-400 inline-flex items-center ml-1",
				children: /* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-3 h-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 11
			}, this);
			case "blunder": return /* @__PURE__ */ _jsxDEV("span", {
				title: "Blunder",
				className: "text-red-400 inline-flex items-center ml-1",
				children: /* @__PURE__ */ _jsxDEV(AlertOctagon, { className: "w-3 h-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 11
			}, this);
			default: return null;
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col h-full bg-[#1A1D20] border border-white/10 rounded-2xl p-4 shadow-xl",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between pb-3 border-b border-white/10",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "font-display font-semibold text-stone-200 text-sm tracking-wide",
					children: "Move History & Analysis"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] font-mono-nums text-stone-400",
					children: [moves.length, " ply"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				ref: scrollRef,
				className: "flex-1 overflow-y-auto py-2 pr-1 space-y-1 min-h-[140px] max-h-[220px] sm:max-h-[300px]",
				children: movePairs.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "h-full flex items-center justify-center text-xs text-stone-500 italic py-8",
					children: "Game started. Make your first move!"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 11
				}, this) : movePairs.map((pair) => /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center text-xs font-mono-nums py-1 px-2 rounded hover:bg-white/5 transition-colors",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "w-8 text-stone-500 font-medium",
							children: [pair.num, "."]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 flex items-center font-medium text-stone-200",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: pair.white?.san }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 17
							}, this), renderBadge(pair.white)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 flex items-center font-medium text-stone-300",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: pair.black?.san }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 17
							}, this), renderBadge(pair.black)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 15
						}, this)
					]
				}, pair.num, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 7
			}, this),
			lastExplanation && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-3 pt-3 border-t border-white/10 text-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "text-[11px] uppercase tracking-wider text-stone-400 font-semibold mb-1",
					children: "Coach Insight"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-stone-300 leading-relaxed bg-black/25 p-2.5 rounded-lg border border-white/5",
					children: lastExplanation
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 69,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFFBQVEsaUJBQWlCO0FBRXpDLFNBQVMsY0FBYyxlQUFlLGNBQWMsWUFBWSxnQkFBZ0I7OztBQU9oRixPQUFPLE1BQU0sZUFBMkMsRUFBRSxPQUFPLHNCQUFzQjtDQUNyRixNQUFNLFlBQVksT0FBdUIsSUFBSTtDQUU3QyxnQkFBZ0I7RUFDZCxJQUFJLFVBQVUsU0FBUztHQUNyQixVQUFVLFFBQVEsWUFBWSxVQUFVLFFBQVE7RUFDbEQ7Q0FDRixHQUFHLENBQUMsS0FBSyxDQUFDOztDQUdWLE1BQU0sWUFBNkUsQ0FBQztDQUNwRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztFQUN4QyxVQUFVLEtBQUs7R0FDYixLQUFLLEtBQUssTUFBTSxJQUFJLENBQUMsSUFBSTtHQUN6QixPQUFPLE1BQU07R0FDYixPQUFPLE1BQU0sSUFBSTtFQUNuQixDQUFDO0NBQ0g7Q0FFQSxNQUFNLGVBQWUsU0FBeUI7RUFDNUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLGdCQUFnQixPQUFPO0VBRTFDLFFBQVEsS0FBSyxnQkFBYjtHQUNFLEtBQUssUUFDSCxPQUNFLHdCQUFDLFFBQUQ7SUFBTSxPQUFNO0lBQVksV0FBVTtjQUNoQyx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztHQUMzQjs7Ozs7R0FFVixLQUFLLFFBQ0gsT0FDRSx3QkFBQyxRQUFEO0lBQU0sT0FBTTtJQUFZLFdBQVU7Y0FDaEMsd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7Ozs7R0FDL0I7Ozs7O0dBRVYsS0FBSyxjQUNILE9BQ0Usd0JBQUMsUUFBRDtJQUFNLE9BQU07SUFBYSxXQUFVO2NBQ2pDLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7O0dBQzdCOzs7OztHQUVWLEtBQUssV0FDSCxPQUNFLHdCQUFDLFFBQUQ7SUFBTSxPQUFNO0lBQVUsV0FBVTtjQUM5Qix3QkFBQyxlQUFELEVBQWUsV0FBVSxVQUFXOzs7OztHQUNoQzs7Ozs7R0FFVixLQUFLLFdBQ0gsT0FDRSx3QkFBQyxRQUFEO0lBQU0sT0FBTTtJQUFVLFdBQVU7Y0FDOUIsd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7Ozs7R0FDL0I7Ozs7O0dBRVYsU0FDRSxPQUFPO0VBQ1g7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFrRTtJQUU1RTs7OztjQUNKLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQ0csTUFBTSxRQUFPLE1BQ1Y7Ozs7O1lBQ0g7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxLQUFLO0lBQVcsV0FBVTtjQUM1QixVQUFVLFdBQVcsSUFDcEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBNkU7SUFFdkY7Ozs7ZUFFTCxVQUFVLEtBQUssU0FDYix3QkFBQyxPQUFEO0tBRUUsV0FBVTtlQUZaO01BSUUsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0csS0FBSyxLQUFJLEdBQ047Ozs7OztNQUNOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFPLEtBQUssT0FBTyxJQUFVOzs7O2lCQUM1QixZQUFZLEtBQUssS0FBSyxDQUNwQjs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU8sS0FBSyxPQUFPLElBQVU7Ozs7aUJBQzVCLFlBQVksS0FBSyxLQUFLLENBQ3BCOzs7Ozs7S0FDRjtPQWRFLEtBQUs7Ozs7V0FjUCxDQUNOO0dBRUE7Ozs7O0dBR0osbUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQXlFO0lBRW5GOzs7O2NBQ0wsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVjtJQUNBOzs7O1lBQ0E7Ozs7OztFQUVKOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJNb3ZlSGlzdG9yeS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVJlZiwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRXZhbHVhdGVkTW92ZSB9IGZyb20gJy4uL3R5cGVzL2NoZXNzJztcbmltcG9ydCB7IENoZWNrQ2lyY2xlMiwgQWxlcnRUcmlhbmdsZSwgQWxlcnRPY3RhZ29uLCBIZWxwQ2lyY2xlLCBTcGFya2xlcyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBNb3ZlSGlzdG9yeVByb3BzIHtcbiAgbW92ZXM6IEV2YWx1YXRlZE1vdmVbXTtcbiAgbGFzdEV4cGxhbmF0aW9uPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuZXhwb3J0IGNvbnN0IE1vdmVIaXN0b3J5OiBSZWFjdC5GQzxNb3ZlSGlzdG9yeVByb3BzPiA9ICh7IG1vdmVzLCBsYXN0RXhwbGFuYXRpb24gfSkgPT4ge1xuICBjb25zdCBzY3JvbGxSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHNjcm9sbFJlZi5jdXJyZW50KSB7XG4gICAgICBzY3JvbGxSZWYuY3VycmVudC5zY3JvbGxUb3AgPSBzY3JvbGxSZWYuY3VycmVudC5zY3JvbGxIZWlnaHQ7XG4gICAgfVxuICB9LCBbbW92ZXNdKTtcblxuICAvLyBHcm91cCBtb3ZlcyBpbnRvIHBhaXJzIChXaGl0ZSAmIEJsYWNrKVxuICBjb25zdCBtb3ZlUGFpcnM6IHsgbnVtOiBudW1iZXI7IHdoaXRlPzogRXZhbHVhdGVkTW92ZTsgYmxhY2s/OiBFdmFsdWF0ZWRNb3ZlIH1bXSA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG1vdmVzLmxlbmd0aDsgaSArPSAyKSB7XG4gICAgbW92ZVBhaXJzLnB1c2goe1xuICAgICAgbnVtOiBNYXRoLmZsb29yKGkgLyAyKSArIDEsXG4gICAgICB3aGl0ZTogbW92ZXNbaV0sXG4gICAgICBibGFjazogbW92ZXNbaSArIDFdLFxuICAgIH0pO1xuICB9XG5cbiAgY29uc3QgcmVuZGVyQmFkZ2UgPSAobW92ZT86IEV2YWx1YXRlZE1vdmUpID0+IHtcbiAgICBpZiAoIW1vdmUgfHwgIW1vdmUuY2xhc3NpZmljYXRpb24pIHJldHVybiBudWxsO1xuXG4gICAgc3dpdGNoIChtb3ZlLmNsYXNzaWZpY2F0aW9uKSB7XG4gICAgICBjYXNlICdiZXN0JzpcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8c3BhbiB0aXRsZT1cIkJlc3QgTW92ZVwiIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIG1sLTFcIj5cbiAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICk7XG4gICAgICBjYXNlICdnb29kJzpcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8c3BhbiB0aXRsZT1cIkdvb2QgTW92ZVwiIGNsYXNzTmFtZT1cInRleHQtdGVhbC00MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIG1sLTFcIj5cbiAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICApO1xuICAgICAgY2FzZSAnaW5hY2N1cmFjeSc6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPHNwYW4gdGl0bGU9XCJJbmFjY3VyYWN5XCIgY2xhc3NOYW1lPVwidGV4dC15ZWxsb3ctNDAwIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBtbC0xXCI+XG4gICAgICAgICAgICA8SGVscENpcmNsZSBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICk7XG4gICAgICBjYXNlICdtaXN0YWtlJzpcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8c3BhbiB0aXRsZT1cIk1pc3Rha2VcIiBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS00MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIG1sLTFcIj5cbiAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKTtcbiAgICAgIGNhc2UgJ2JsdW5kZXInOlxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxzcGFuIHRpdGxlPVwiQmx1bmRlclwiIGNsYXNzTmFtZT1cInRleHQtcmVkLTQwMCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgbWwtMVwiPlxuICAgICAgICAgICAgPEFsZXJ0T2N0YWdvbiBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICk7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaC1mdWxsIGJnLVsjMUExRDIwXSBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3cteGxcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXdoaXRlLzEwXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgZm9udC1zZW1pYm9sZCB0ZXh0LXN0b25lLTIwMCB0ZXh0LXNtIHRyYWNraW5nLXdpZGVcIj5cbiAgICAgICAgICBNb3ZlIEhpc3RvcnkgJiBBbmFseXNpc1xuICAgICAgICA8L2gzPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8tbnVtcyB0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgIHttb3Zlcy5sZW5ndGh9IHBseVxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1vdmUgTG9nIFRhYmxlICovfVxuICAgICAgPGRpdiByZWY9e3Njcm9sbFJlZn0gY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBweS0yIHByLTEgc3BhY2UteS0xIG1pbi1oLVsxNDBweF0gbWF4LWgtWzIyMHB4XSBzbTptYXgtaC1bMzAwcHhdXCI+XG4gICAgICAgIHttb3ZlUGFpcnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHMgdGV4dC1zdG9uZS01MDAgaXRhbGljIHB5LThcIj5cbiAgICAgICAgICAgIEdhbWUgc3RhcnRlZC4gTWFrZSB5b3VyIGZpcnN0IG1vdmUhXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgbW92ZVBhaXJzLm1hcCgocGFpcikgPT4gKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBrZXk9e3BhaXIubnVtfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LXhzIGZvbnQtbW9uby1udW1zIHB5LTEgcHgtMiByb3VuZGVkIGhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTggdGV4dC1zdG9uZS01MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICB7cGFpci5udW19LlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGZvbnQtbWVkaXVtIHRleHQtc3RvbmUtMjAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3BhaXIud2hpdGU/LnNhbn08L3NwYW4+XG4gICAgICAgICAgICAgICAge3JlbmRlckJhZGdlKHBhaXIud2hpdGUpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIgZm9udC1tZWRpdW0gdGV4dC1zdG9uZS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj57cGFpci5ibGFjaz8uc2FufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7cmVuZGVyQmFkZ2UocGFpci5ibGFjayl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSlcbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTGF0ZXN0IENvYWNoIC8gTW92ZSBBbmFseXNpcyBJbnNpZ2h0ICovfVxuICAgICAge2xhc3RFeHBsYW5hdGlvbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwdC0zIGJvcmRlci10IGJvcmRlci13aGl0ZS8xMCB0ZXh0LXhzXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zdG9uZS00MDAgZm9udC1zZW1pYm9sZCBtYi0xXCI+XG4gICAgICAgICAgICBDb2FjaCBJbnNpZ2h0XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zdG9uZS0zMDAgbGVhZGluZy1yZWxheGVkIGJnLWJsYWNrLzI1IHAtMi41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci13aGl0ZS81XCI+XG4gICAgICAgICAgICB7bGFzdEV4cGxhbmF0aW9ufVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==