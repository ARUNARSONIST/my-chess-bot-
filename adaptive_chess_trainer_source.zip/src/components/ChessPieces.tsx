const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
var _jsxFileName = "/app/applet/src/components/ChessPieces.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
/**
* ChessPiece component rendering the exact custom PNG set uploaded by the user,
* with crisp transparency, natural contrast, and subtle depth.
*/
export const ChessPiece = ({ type, color, className = "w-full h-full" }) => {
	const src = `/assets/pieces/${color}_${type}.png`;
	const alt = `${color === "w" ? "White" : "Black"} ${type === "k" ? "King" : type === "q" ? "Queen" : type === "r" ? "Rook" : type === "b" ? "Bishop" : type === "n" ? "Knight" : "Pawn"}`;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `relative flex items-center justify-center ${className}`,
		children: /* @__PURE__ */ _jsxDEV("img", {
			src,
			alt,
			className: "w-full h-full object-contain filter drop-shadow-[0_2px_3px_rgba(0,0,0,0.3)] transition-transform duration-100 select-none pointer-events-none",
			loading: "eager",
			draggable: false
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7Ozs7O0FBYWxCLE9BQU8sTUFBTSxjQUFvQyxFQUFFLE1BQU0sT0FBTyxZQUFZLHNCQUFzQjtDQUNoRyxNQUFNLE1BQU0sa0JBQWtCLE1BQU0sR0FBRyxLQUFLO0NBQzVDLE1BQU0sTUFBTSxHQUFHLFVBQVUsTUFBTSxVQUFVLFFBQVEsR0FDL0MsU0FBUyxNQUFNLFNBQVMsU0FBUyxNQUFNLFVBQVUsU0FBUyxNQUFNLFNBQVMsU0FBUyxNQUFNLFdBQVcsU0FBUyxNQUFNLFdBQVc7Q0FHL0gsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyw2Q0FBNkM7WUFDM0Qsd0JBQUMsT0FBRDtHQUNPO0dBQ0E7R0FDTCxXQUFVO0dBQ1YsU0FBUTtHQUNSLFdBQVc7RUFDWjs7Ozs7Q0FDRTs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDaGVzc1BpZWNlcy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFBpZWNlVHlwZSwgUGllY2VDb2xvciB9IGZyb20gJy4uL3R5cGVzL2NoZXNzJztcblxuaW50ZXJmYWNlIFBpZWNlUHJvcHMge1xuICB0eXBlOiBQaWVjZVR5cGU7XG4gIGNvbG9yOiBQaWVjZUNvbG9yO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ2hlc3NQaWVjZSBjb21wb25lbnQgcmVuZGVyaW5nIHRoZSBleGFjdCBjdXN0b20gUE5HIHNldCB1cGxvYWRlZCBieSB0aGUgdXNlcixcbiAqIHdpdGggY3Jpc3AgdHJhbnNwYXJlbmN5LCBuYXR1cmFsIGNvbnRyYXN0LCBhbmQgc3VidGxlIGRlcHRoLlxuICovXG5leHBvcnQgY29uc3QgQ2hlc3NQaWVjZTogUmVhY3QuRkM8UGllY2VQcm9wcz4gPSAoeyB0eXBlLCBjb2xvciwgY2xhc3NOYW1lID0gJ3ctZnVsbCBoLWZ1bGwnIH0pID0+IHtcbiAgY29uc3Qgc3JjID0gYC9hc3NldHMvcGllY2VzLyR7Y29sb3J9XyR7dHlwZX0ucG5nYDtcbiAgY29uc3QgYWx0ID0gYCR7Y29sb3IgPT09ICd3JyA/ICdXaGl0ZScgOiAnQmxhY2snfSAke1xuICAgIHR5cGUgPT09ICdrJyA/ICdLaW5nJyA6IHR5cGUgPT09ICdxJyA/ICdRdWVlbicgOiB0eXBlID09PSAncicgPyAnUm9vaycgOiB0eXBlID09PSAnYicgPyAnQmlzaG9wJyA6IHR5cGUgPT09ICduJyA/ICdLbmlnaHQnIDogJ1Bhd24nXG4gIH1gO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2ByZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciAke2NsYXNzTmFtZX1gfT5cbiAgICAgIDxpbWdcbiAgICAgICAgc3JjPXtzcmN9XG4gICAgICAgIGFsdD17YWx0fVxuICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb250YWluIGZpbHRlciBkcm9wLXNoYWRvdy1bMF8ycHhfM3B4X3JnYmEoMCwwLDAsMC4zKV0gdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMTAwIHNlbGVjdC1ub25lIHBvaW50ZXItZXZlbnRzLW5vbmVcIlxuICAgICAgICBsb2FkaW5nPVwiZWFnZXJcIlxuICAgICAgICBkcmFnZ2FibGU9e2ZhbHNlfVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=