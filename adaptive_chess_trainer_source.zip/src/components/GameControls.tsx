const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
import { Lightbulb, RotateCcw, Flag, Plus, Volume2, VolumeX, SlidersHorizontal, ArrowUpDown } from "/node_modules/.vite/deps/lucide-react.js?v=c3d5a9dc";
var _jsxFileName = "/app/applet/src/components/GameControls.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
export const GameControls = ({ onHint, onUndo, onResign, onNewGame, onFlipBoard, onToggleSound, onOpenSettings, isSoundMuted, canUndo, isGameOver, isBotThinking }) => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "w-full bg-[#1A1D20] border border-white/10 rounded-2xl p-3 sm:p-4 shadow-xl",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onHint,
					disabled: isGameOver || isBotThinking,
					className: "flex items-center justify-center gap-2 py-2.5 px-3 bg-amber-500/15 hover:bg-amber-500/25 active:scale-95 text-amber-300 border border-amber-500/30 rounded-xl text-xs sm:text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none",
					children: [/* @__PURE__ */ _jsxDEV(Lightbulb, { className: "w-4 h-4 text-amber-400 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "whitespace-nowrap",
						children: "Hint"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onUndo,
					disabled: !canUndo || isBotThinking,
					className: "flex items-center justify-center gap-2 py-2.5 px-3 bg-stone-800/80 hover:bg-stone-700/80 active:scale-95 text-stone-200 border border-white/10 rounded-xl text-xs sm:text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none",
					children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-4 h-4 text-stone-400 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "whitespace-nowrap",
						children: "Takeback"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onNewGame,
					disabled: isBotThinking,
					className: "flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600/20 hover:bg-emerald-600/30 active:scale-95 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs sm:text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none",
					children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-4 h-4 text-emerald-400 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "whitespace-nowrap",
						children: "New Match"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onResign,
					disabled: isGameOver || isBotThinking,
					className: "flex items-center justify-center gap-2 py-2.5 px-3 bg-red-500/10 hover:bg-red-500/20 active:scale-95 text-red-300 border border-red-500/20 rounded-xl text-xs sm:text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none",
					children: [/* @__PURE__ */ _jsxDEV(Flag, { className: "w-4 h-4 text-red-400 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "whitespace-nowrap",
						children: "Resign"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between mt-3 pt-3 border-t border-white/10 text-xs text-stone-400",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: onFlipBoard,
					className: "flex items-center gap-1.5 py-1 px-2.5 rounded-lg hover:bg-white/5 text-stone-300 transition-colors",
					title: "Flip board orientation",
					children: [/* @__PURE__ */ _jsxDEV(ArrowUpDown, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Flip" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleSound,
					className: "flex items-center gap-1.5 py-1 px-2.5 rounded-lg hover:bg-white/5 text-stone-300 transition-colors",
					title: isSoundMuted ? "Unmute sounds" : "Mute sounds",
					children: isSoundMuted ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(VolumeX, { className: "w-3.5 h-3.5 text-stone-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Muted" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Volume2, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Sound" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: onOpenSettings,
				className: "flex items-center gap-1.5 py-1 px-2.5 rounded-lg hover:bg-white/5 text-stone-300 transition-colors",
				children: [/* @__PURE__ */ _jsxDEV(SlidersHorizontal, { className: "w-3.5 h-3.5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Settings" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsV0FBVyxXQUFXLE1BQU0sTUFBTSxTQUFTLFNBQVMsbUJBQW1CLG1CQUFtQjs7O0FBZ0JuRyxPQUFPLE1BQU0sZ0JBQTZDLEVBQ3hELFFBQ0EsUUFDQSxVQUNBLFdBQ0EsYUFDQSxlQUNBLGdCQUNBLGNBQ0EsU0FDQSxZQUNBLG9CQUNJO0NBQ0osT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsVUFBVSxjQUFjO0tBQ3hCLFdBQVU7ZUFIWixDQUtFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGtDQUFtQzs7OztlQUN4RCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBb0I7S0FBVTs7OzthQUN4Qzs7Ozs7O0lBR1Isd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxVQUFVLENBQUMsV0FBVztLQUN0QixXQUFVO2VBSFosQ0FLRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxrQ0FBbUM7Ozs7ZUFDeEQsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW9CO0tBQWM7Ozs7YUFDNUM7Ozs7OztJQUdSLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsVUFBVTtLQUNWLFdBQVU7ZUFIWixDQUtFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLG9DQUFxQzs7OztlQUNyRCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBb0I7S0FBZTs7OzthQUM3Qzs7Ozs7O0lBR1Isd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxVQUFVLGNBQWM7S0FDeEIsV0FBVTtlQUhaLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsZ0NBQWlDOzs7O2VBQ2pELHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFvQjtLQUFZOzs7O2FBQzFDOzs7Ozs7R0FDTDs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtLQUNWLE9BQU07ZUFIUixDQUtFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLGNBQWU7Ozs7ZUFDdEMsd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7YUFDVjs7Ozs7Y0FFUix3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7S0FDVixPQUFPLGVBQWUsa0JBQWtCO2VBRXZDLGVBQ0MsZ0RBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsNkJBQThCOzs7O2VBQ2pELHdCQUFDLFFBQUQsWUFBTSxRQUFXOzs7O2FBQ2pCOzs7O2dCQUVGLGdEQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLCtCQUFnQzs7OztlQUNuRCx3QkFBQyxRQUFELFlBQU0sUUFBVzs7OzthQUNqQjs7Ozs7SUFFRTs7OztZQUNMOzs7OzthQUVMLHdCQUFDLFVBQUQ7SUFDRSxTQUFTO0lBQ1QsV0FBVTtjQUZaLENBSUUsd0JBQUMsbUJBQUQsRUFBbUIsV0FBVSxjQUFlOzs7O2NBQzVDLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O1lBQ2Q7Ozs7O1dBQ0w7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkdhbWVDb250cm9scy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpZ2h0YnVsYiwgUm90YXRlQ2N3LCBGbGFnLCBQbHVzLCBWb2x1bWUyLCBWb2x1bWVYLCBTbGlkZXJzSG9yaXpvbnRhbCwgQXJyb3dVcERvd24gfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbnRlcmZhY2UgR2FtZUNvbnRyb2xzUHJvcHMge1xuICBvbkhpbnQ6ICgpID0+IHZvaWQ7XG4gIG9uVW5kbzogKCkgPT4gdm9pZDtcbiAgb25SZXNpZ246ICgpID0+IHZvaWQ7XG4gIG9uTmV3R2FtZTogKCkgPT4gdm9pZDtcbiAgb25GbGlwQm9hcmQ6ICgpID0+IHZvaWQ7XG4gIG9uVG9nZ2xlU291bmQ6ICgpID0+IHZvaWQ7XG4gIG9uT3BlblNldHRpbmdzOiAoKSA9PiB2b2lkO1xuICBpc1NvdW5kTXV0ZWQ6IGJvb2xlYW47XG4gIGNhblVuZG86IGJvb2xlYW47XG4gIGlzR2FtZU92ZXI6IGJvb2xlYW47XG4gIGlzQm90VGhpbmtpbmc6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBHYW1lQ29udHJvbHM6IFJlYWN0LkZDPEdhbWVDb250cm9sc1Byb3BzPiA9ICh7XG4gIG9uSGludCxcbiAgb25VbmRvLFxuICBvblJlc2lnbixcbiAgb25OZXdHYW1lLFxuICBvbkZsaXBCb2FyZCxcbiAgb25Ub2dnbGVTb3VuZCxcbiAgb25PcGVuU2V0dGluZ3MsXG4gIGlzU291bmRNdXRlZCxcbiAgY2FuVW5kbyxcbiAgaXNHYW1lT3ZlcixcbiAgaXNCb3RUaGlua2luZyxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1bIzFBMUQyMF0gYm9yZGVyIGJvcmRlci13aGl0ZS8xMCByb3VuZGVkLTJ4bCBwLTMgc206cC00IHNoYWRvdy14bFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0yXCI+XG4gICAgICAgIHsvKiBIaW50IEJ1dHRvbiAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uSGludH1cbiAgICAgICAgICBkaXNhYmxlZD17aXNHYW1lT3ZlciB8fCBpc0JvdFRoaW5raW5nfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB5LTIuNSBweC0zIGJnLWFtYmVyLTUwMC8xNSBob3ZlcjpiZy1hbWJlci01MDAvMjUgYWN0aXZlOnNjYWxlLTk1IHRleHQtYW1iZXItMzAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHJvdW5kZWQteGwgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6dHJhbnNmb3JtLW5vbmVcIlxuICAgICAgICA+XG4gICAgICAgICAgPExpZ2h0YnVsYiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLW5vd3JhcFwiPkhpbnQ8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIHsvKiBVbmRvIEJ1dHRvbiAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uVW5kb31cbiAgICAgICAgICBkaXNhYmxlZD17IWNhblVuZG8gfHwgaXNCb3RUaGlua2luZ31cbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweS0yLjUgcHgtMyBiZy1zdG9uZS04MDAvODAgaG92ZXI6Ymctc3RvbmUtNzAwLzgwIGFjdGl2ZTpzY2FsZS05NSB0ZXh0LXN0b25lLTIwMCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHJvdW5kZWQteGwgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6dHJhbnNmb3JtLW5vbmVcIlxuICAgICAgICA+XG4gICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc3RvbmUtNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLW5vd3JhcFwiPlRha2ViYWNrPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7LyogTmV3IEdhbWUgQnV0dG9uICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25OZXdHYW1lfVxuICAgICAgICAgIGRpc2FibGVkPXtpc0JvdFRoaW5raW5nfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB5LTIuNSBweC0zIGJnLWVtZXJhbGQtNjAwLzIwIGhvdmVyOmJnLWVtZXJhbGQtNjAwLzMwIGFjdGl2ZTpzY2FsZS05NSB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgcm91bmRlZC14bCB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBkaXNhYmxlZDp0cmFuc2Zvcm0tbm9uZVwiXG4gICAgICAgID5cbiAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIndoaXRlc3BhY2Utbm93cmFwXCI+TmV3IE1hdGNoPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7LyogUmVzaWduIEJ1dHRvbiAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uUmVzaWdufVxuICAgICAgICAgIGRpc2FibGVkPXtpc0dhbWVPdmVyIHx8IGlzQm90VGhpbmtpbmd9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHktMi41IHB4LTMgYmctcmVkLTUwMC8xMCBob3ZlcjpiZy1yZWQtNTAwLzIwIGFjdGl2ZTpzY2FsZS05NSB0ZXh0LXJlZC0zMDAgYm9yZGVyIGJvcmRlci1yZWQtNTAwLzIwIHJvdW5kZWQteGwgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6dHJhbnNmb3JtLW5vbmVcIlxuICAgICAgICA+XG4gICAgICAgICAgPEZsYWcgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJlZC00MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIndoaXRlc3BhY2Utbm93cmFwXCI+UmVzaWduPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogU2Vjb25kYXJ5IFF1aWNrIFRvZ2dsZXMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzEwIHRleHQteHMgdGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uRmxpcEJvYXJkfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweS0xIHB4LTIuNSByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlLzUgdGV4dC1zdG9uZS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgdGl0bGU9XCJGbGlwIGJvYXJkIG9yaWVudGF0aW9uXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJyb3dVcERvd24gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+RmxpcDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uVG9nZ2xlU291bmR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB5LTEgcHgtMi41IHJvdW5kZWQtbGcgaG92ZXI6Ymctd2hpdGUvNSB0ZXh0LXN0b25lLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICB0aXRsZT17aXNTb3VuZE11dGVkID8gJ1VubXV0ZSBzb3VuZHMnIDogJ011dGUgc291bmRzJ31cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7aXNTb3VuZE11dGVkID8gKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxWb2x1bWVYIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc3RvbmUtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5NdXRlZDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxWb2x1bWUyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlNvdW5kPC9zcGFuPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5TZXR0aW5nc31cbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB5LTEgcHgtMi41IHJvdW5kZWQtbGcgaG92ZXI6Ymctd2hpdGUvNSB0ZXh0LXN0b25lLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgID5cbiAgICAgICAgICA8U2xpZGVyc0hvcml6b250YWwgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgIDxzcGFuPlNldHRpbmdzPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==