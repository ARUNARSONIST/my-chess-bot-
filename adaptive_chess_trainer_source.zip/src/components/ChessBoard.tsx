const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
import { ChessPiece } from "/src/components/ChessPieces.tsx";
var _jsxFileName = "/app/applet/src/components/ChessBoard.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
export const ChessBoard = ({ game, onMove, playerColor, isBotThinking, lastMove, hint, disabled = false }) => {
	const [selectedSquare, setSelectedSquare] = useState(null);
	const [legalMoves, setLegalMoves] = useState([]);
	const [pendingPromotion, setPendingPromotion] = useState(null);
	const [draggedSquare, setDraggedSquare] = useState(null);
	const isFlipped = playerColor === "b";
	const board = game.board();
	// Find King square if currently in check
	let inCheckKingSquare = null;
	if (game.inCheck()) {
		const turnColor = game.turn();
		for (let r = 0; r < 8; r++) {
			for (let c = 0; c < 8; c++) {
				const p = board[r][c];
				if (p && p.type === "k" && p.color === turnColor) {
					inCheckKingSquare = String.fromCharCode("a".charCodeAt(0) + c) + (8 - r);
					break;
				}
			}
		}
	}
	// Handle square selection / click
	const handleSquareClick = (square) => {
		if (disabled || isBotThinking) return;
		// If already selected, check if this click is a valid destination
		if (selectedSquare) {
			if (selectedSquare === square) {
				// Deselect
				setSelectedSquare(null);
				setLegalMoves([]);
				return;
			}
			if (legalMoves.includes(square)) {
				// Check for pawn promotion
				const piece = game.get(selectedSquare);
				if (piece && piece.type === "p" && (piece.color === "w" && square[1] === "8" || piece.color === "b" && square[1] === "1")) {
					setPendingPromotion({
						from: selectedSquare,
						to: square
					});
					return;
				}
				// Execute standard move
				const success = onMove(selectedSquare, square);
				if (success) {
					setSelectedSquare(null);
					setLegalMoves([]);
					return;
				}
			}
		}
		// Select piece if it belongs to active turn and player
		const piece = game.get(square);
		if (piece && piece.color === game.turn() && piece.color === playerColor) {
			setSelectedSquare(square);
			const moves = game.moves({
				square,
				verbose: true
			});
			setLegalMoves(moves.map((m) => m.to));
		} else {
			setSelectedSquare(null);
			setLegalMoves([]);
		}
	};
	// Drag & drop support
	const handleDragStart = (e, square) => {
		if (disabled || isBotThinking) {
			e.preventDefault();
			return;
		}
		const piece = game.get(square);
		if (!piece || piece.color !== game.turn() || piece.color !== playerColor) {
			e.preventDefault();
			return;
		}
		setDraggedSquare(square);
		setSelectedSquare(square);
		const moves = game.moves({
			square,
			verbose: true
		});
		setLegalMoves(moves.map((m) => m.to));
		e.dataTransfer.setData("text/plain", square);
		e.dataTransfer.effectAllowed = "move";
	};
	const handleDragOver = (e) => {
		e.preventDefault();
		e.dataTransfer.dropEffect = "move";
	};
	const handleDrop = (e, targetSquare) => {
		e.preventDefault();
		const sourceSquare = draggedSquare || e.dataTransfer.getData("text/plain");
		setDraggedSquare(null);
		if (!sourceSquare || sourceSquare === targetSquare) return;
		if (legalMoves.includes(targetSquare)) {
			const piece = game.get(sourceSquare);
			if (piece && piece.type === "p" && (piece.color === "w" && targetSquare[1] === "8" || piece.color === "b" && targetSquare[1] === "1")) {
				setPendingPromotion({
					from: sourceSquare,
					to: targetSquare
				});
				return;
			}
			onMove(sourceSquare, targetSquare);
			setSelectedSquare(null);
			setLegalMoves([]);
		}
	};
	const handlePromotionSelect = (promotedPiece) => {
		if (pendingPromotion) {
			onMove(pendingPromotion.from, pendingPromotion.to, promotedPiece);
			setPendingPromotion(null);
			setSelectedSquare(null);
			setLegalMoves([]);
		}
	};
	// Ranks 1 to 8, Files a to h
	const ranks = isFlipped ? [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	] : [
		8,
		7,
		6,
		5,
		4,
		3,
		2,
		1
	];
	const files = isFlipped ? [
		"h",
		"g",
		"f",
		"e",
		"d",
		"c",
		"b",
		"a"
	] : [
		"a",
		"b",
		"c",
		"d",
		"e",
		"f",
		"g",
		"h"
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative flex flex-col items-center",
		children: [pendingPromotion && /* @__PURE__ */ _jsxDEV("div", {
			className: "absolute inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center rounded-xl p-4",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-[#23272A] border border-white/20 rounded-xl p-4 shadow-2xl text-center max-w-xs animate-in fade-in zoom-in-95 duration-150",
				children: [
					/* @__PURE__ */ _jsxDEV("h4", {
						className: "text-sm font-semibold text-stone-200 mb-3 tracking-wide",
						children: "Select Promotion Piece"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-4 gap-2",
						children: [
							"q",
							"r",
							"b",
							"n"
						].map((pType) => /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => handlePromotionSelect(pType),
							className: "p-2 bg-stone-800/80 hover:bg-emerald-600/40 border border-stone-600 rounded-lg transition-transform hover:scale-105 active:scale-95 flex items-center justify-center aspect-square",
							title: pType === "q" ? "Queen" : pType === "r" ? "Rook" : pType === "b" ? "Bishop" : "Knight",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "w-10 h-10",
								children: /* @__PURE__ */ _jsxDEV(ChessPiece, {
									type: pType,
									color: playerColor
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 174,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 19
							}, this)
						}, pType, false, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 165,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => {
							setPendingPromotion(null);
							setSelectedSquare(null);
							setLegalMoves([]);
						},
						className: "mt-3 text-xs text-stone-400 hover:text-stone-200",
						children: "Cancel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 161,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 160,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "p-2 sm:p-3 bg-[#1E2226] rounded-2xl shadow-2xl border border-white/10 ring-1 ring-black/40",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-8 grid-rows-8 w-[320px] h-[320px] sm:w-[420px] sm:h-[420px] md:w-[500px] md:h-[500px] lg:w-[540px] lg:h-[540px] rounded-lg overflow-hidden border border-black/40 shadow-inner",
				children: ranks.map((rank) => files.map((file) => {
					const square = `${file}${rank}`;
					const fileIdx = file.charCodeAt(0) - "a".charCodeAt(0);
					const rankIdx = rank - 1;
					const isLight = (fileIdx + rankIdx) % 2 !== 0;
					// Tile colors: user requested light yellow and light green
					// Light: warm soft light yellow #F4F2BA
					// Dark: pleasant soft olive green #779556
					const tileBg = isLight ? "bg-[#F4F2BA]" : "bg-[#779556]";
					const labelColor = isLight ? "text-[#779556]" : "text-[#F4F2BA]";
					const piece = game.get(square);
					const isSelected = selectedSquare === square;
					const isLegalTarget = legalMoves.includes(square);
					const isLastMove = lastMove && (lastMove.from === square || lastMove.to === square);
					const isInCheck = inCheckKingSquare === square;
					const isHintSource = hint && hint.from === square;
					const isHintTarget = hint && hint.to === square;
					// Label indicators on edges
					const showFileLabel = isFlipped ? rank === 8 : rank === 1;
					const showRankLabel = isFlipped ? file === "h" : file === "a";
					return /* @__PURE__ */ _jsxDEV("div", {
						onClick: () => handleSquareClick(square),
						onDragOver: handleDragOver,
						onDrop: (e) => handleDrop(e, square),
						className: `relative select-none flex items-center justify-center transition-colors cursor-pointer ${tileBg}`,
						children: [
							isLastMove && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-amber-300/35 pointer-events-none" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 21
							}, this),
							isSelected && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-yellow-400/50 ring-2 ring-inset ring-yellow-400 pointer-events-none" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 21
							}, this),
							isHintSource && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-cyan-400/35 ring-2 ring-inset ring-cyan-400 pointer-events-none animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 241,
								columnNumber: 21
							}, this),
							isHintTarget && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-emerald-400/40 ring-2 ring-inset ring-emerald-400 pointer-events-none animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 21
							}, this),
							isInCheck && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-red-600/50 ring-4 ring-inset ring-red-500 animate-pulse pointer-events-none rounded-sm" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 21
							}, this),
							isLegalTarget && /* @__PURE__ */ _jsxDEV("div", {
								className: "absolute inset-0 flex items-center justify-center pointer-events-none z-20",
								children: piece ? /* @__PURE__ */ _jsxDEV(
									"div",
									// Capture ring
									{ className: "w-[82%] h-[82%] rounded-full border-[5px] border-black/25 ring-2 ring-white/20" },
									void 0,
									false,
									{
										fileName: _jsxFileName,
										lineNumber: 257,
										columnNumber: 25
									},
									this
								) : 
								// Move dot
								/* @__PURE__ */ _jsxDEV("div", { className: "w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-black/25 shadow-sm" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 260,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 254,
								columnNumber: 21
							}, this),
							piece && /* @__PURE__ */ _jsxDEV("div", {
								draggable: !disabled && !isBotThinking && piece.color === playerColor && piece.color === game.turn(),
								onDragStart: (e) => handleDragStart(e, square),
								className: `relative z-10 w-[88%] h-[88%] flex items-center justify-center transition-transform duration-100 ease-out active:scale-95 ${piece.color === playerColor && piece.color === game.turn() && !disabled && !isBotThinking ? "hover:scale-105 cursor-grab active:cursor-grabbing" : "cursor-pointer"}`,
								children: /* @__PURE__ */ _jsxDEV(ChessPiece, {
									type: piece.type,
									color: piece.color
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 276,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 267,
								columnNumber: 21
							}, this),
							showRankLabel && /* @__PURE__ */ _jsxDEV("span", {
								className: `absolute top-0.5 left-1 text-[10px] sm:text-[11px] font-bold font-mono-nums pointer-events-none select-none opacity-85 ${labelColor}`,
								children: rank
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 282,
								columnNumber: 21
							}, this),
							showFileLabel && /* @__PURE__ */ _jsxDEV("span", {
								className: `absolute bottom-0.5 right-1 text-[10px] sm:text-[11px] font-bold font-mono-nums pointer-events-none select-none opacity-85 ${labelColor}`,
								children: file
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 21
							}, this)
						]
					}, square, true, {
						fileName: _jsxFileName,
						lineNumber: 222,
						columnNumber: 17
					}, this);
				}))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 195,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 194,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 157,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUVoQyxTQUFTLGtCQUFrQjs7O0FBYTNCLE9BQU8sTUFBTSxjQUF5QyxFQUNwRCxNQUNBLFFBQ0EsYUFDQSxlQUNBLFVBQ0EsTUFDQSxXQUFXLFlBQ1A7Q0FDSixNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUF3QixJQUFJO0NBQ3hFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFtQixDQUFDLENBQUM7Q0FDekQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBOEMsSUFBSTtDQUNsRyxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBd0IsSUFBSTtDQUV0RSxNQUFNLFlBQVksZ0JBQWdCO0NBQ2xDLE1BQU0sUUFBUSxLQUFLLE1BQU07O0NBR3pCLElBQUksb0JBQW1DO0NBQ3ZDLElBQUksS0FBSyxRQUFRLEdBQUc7RUFDbEIsTUFBTSxZQUFZLEtBQUssS0FBSztFQUM1QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0dBQzFCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7SUFDMUIsTUFBTSxJQUFJLE1BQU0sRUFBRSxDQUFDO0lBQ25CLElBQUksS0FBSyxFQUFFLFNBQVMsT0FBTyxFQUFFLFVBQVUsV0FBVztLQUNoRCxvQkFBb0IsT0FBTyxhQUFhLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUk7S0FDdEU7SUFDRjtHQUNGO0VBQ0Y7Q0FDRjs7Q0FHQSxNQUFNLHFCQUFxQixXQUFtQjtFQUM1QyxJQUFJLFlBQVksZUFBZTs7RUFHL0IsSUFBSSxnQkFBZ0I7R0FDbEIsSUFBSSxtQkFBbUIsUUFBUTs7SUFFN0Isa0JBQWtCLElBQUk7SUFDdEIsY0FBYyxDQUFDLENBQUM7SUFDaEI7R0FDRjtHQUVBLElBQUksV0FBVyxTQUFTLE1BQU0sR0FBRzs7SUFFL0IsTUFBTSxRQUFRLEtBQUssSUFBSSxjQUFjO0lBQ3JDLElBQ0UsU0FDQSxNQUFNLFNBQVMsUUFDYixNQUFNLFVBQVUsT0FBTyxPQUFPLE9BQU8sT0FBUyxNQUFNLFVBQVUsT0FBTyxPQUFPLE9BQU8sTUFDckY7S0FDQSxvQkFBb0I7TUFBRSxNQUFNO01BQWdCLElBQUk7S0FBTyxDQUFDO0tBQ3hEO0lBQ0Y7O0lBR0EsTUFBTSxVQUFVLE9BQU8sZ0JBQWdCLE1BQU07SUFDN0MsSUFBSSxTQUFTO0tBQ1gsa0JBQWtCLElBQUk7S0FDdEIsY0FBYyxDQUFDLENBQUM7S0FDaEI7SUFDRjtHQUNGO0VBQ0Y7O0VBR0EsTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNO0VBQzdCLElBQUksU0FBUyxNQUFNLFVBQVUsS0FBSyxLQUFLLEtBQUssTUFBTSxVQUFVLGFBQWE7R0FDdkUsa0JBQWtCLE1BQU07R0FDeEIsTUFBTSxRQUFRLEtBQUssTUFBTTtJQUFFO0lBQVEsU0FBUztHQUFLLENBQUM7R0FDbEQsY0FBYyxNQUFNLEtBQUssTUFBTSxFQUFFLEVBQUUsQ0FBQztFQUN0QyxPQUFPO0dBQ0wsa0JBQWtCLElBQUk7R0FDdEIsY0FBYyxDQUFDLENBQUM7RUFDbEI7Q0FDRjs7Q0FHQSxNQUFNLG1CQUFtQixHQUFvQixXQUFtQjtFQUM5RCxJQUFJLFlBQVksZUFBZTtHQUM3QixFQUFFLGVBQWU7R0FDakI7RUFDRjtFQUNBLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTTtFQUM3QixJQUFJLENBQUMsU0FBUyxNQUFNLFVBQVUsS0FBSyxLQUFLLEtBQUssTUFBTSxVQUFVLGFBQWE7R0FDeEUsRUFBRSxlQUFlO0dBQ2pCO0VBQ0Y7RUFDQSxpQkFBaUIsTUFBTTtFQUN2QixrQkFBa0IsTUFBTTtFQUN4QixNQUFNLFFBQVEsS0FBSyxNQUFNO0dBQUU7R0FBUSxTQUFTO0VBQUssQ0FBQztFQUNsRCxjQUFjLE1BQU0sS0FBSyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ3BDLEVBQUUsYUFBYSxRQUFRLGNBQWMsTUFBTTtFQUMzQyxFQUFFLGFBQWEsZ0JBQWdCO0NBQ2pDO0NBRUEsTUFBTSxrQkFBa0IsTUFBdUI7RUFDN0MsRUFBRSxlQUFlO0VBQ2pCLEVBQUUsYUFBYSxhQUFhO0NBQzlCO0NBRUEsTUFBTSxjQUFjLEdBQW9CLGlCQUF5QjtFQUMvRCxFQUFFLGVBQWU7RUFDakIsTUFBTSxlQUFlLGlCQUFrQixFQUFFLGFBQWEsUUFBUSxZQUFZO0VBQzFFLGlCQUFpQixJQUFJO0VBRXJCLElBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLGNBQWM7RUFFcEQsSUFBSSxXQUFXLFNBQVMsWUFBWSxHQUFHO0dBQ3JDLE1BQU0sUUFBUSxLQUFLLElBQUksWUFBWTtHQUNuQyxJQUNFLFNBQ0EsTUFBTSxTQUFTLFFBQ2IsTUFBTSxVQUFVLE9BQU8sYUFBYSxPQUFPLE9BQzFDLE1BQU0sVUFBVSxPQUFPLGFBQWEsT0FBTyxNQUM5QztJQUNBLG9CQUFvQjtLQUFFLE1BQU07S0FBYyxJQUFJO0lBQWEsQ0FBQztJQUM1RDtHQUNGO0dBQ0EsT0FBTyxjQUFjLFlBQVk7R0FDakMsa0JBQWtCLElBQUk7R0FDdEIsY0FBYyxDQUFDLENBQUM7RUFDbEI7Q0FDRjtDQUVBLE1BQU0seUJBQXlCLGtCQUF5QztFQUN0RSxJQUFJLGtCQUFrQjtHQUNwQixPQUFPLGlCQUFpQixNQUFNLGlCQUFpQixJQUFJLGFBQWE7R0FDaEUsb0JBQW9CLElBQUk7R0FDeEIsa0JBQWtCLElBQUk7R0FDdEIsY0FBYyxDQUFDLENBQUM7RUFDbEI7Q0FDRjs7Q0FHQSxNQUFNLFFBQVEsWUFBWTtFQUFDO0VBQUc7RUFBRztFQUFHO0VBQUc7RUFBRztFQUFHO0VBQUc7Q0FBQyxJQUFJO0VBQUM7RUFBRztFQUFHO0VBQUc7RUFBRztFQUFHO0VBQUc7RUFBRztDQUFDO0NBQzVFLE1BQU0sUUFBUSxZQUFZO0VBQUM7RUFBSztFQUFLO0VBQUs7RUFBSztFQUFLO0VBQUs7RUFBSztDQUFHLElBQUk7RUFBQztFQUFLO0VBQUs7RUFBSztFQUFLO0VBQUs7RUFBSztFQUFLO0NBQUc7Q0FFNUcsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBRUcsb0JBQ0Msd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTBEO0tBRXBFOzs7OztLQUNKLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNYO09BQUM7T0FBSztPQUFLO09BQUs7TUFBRyxDQUFDLENBQVcsS0FBSyxVQUNwQyx3QkFBQyxVQUFEO09BRUUsZUFBZSxzQkFBc0IsS0FBSztPQUMxQyxXQUFVO09BQ1YsT0FBTyxVQUFVLE1BQU0sVUFBVSxVQUFVLE1BQU0sU0FBUyxVQUFVLE1BQU0sV0FBVztpQkFFckYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsWUFBRDtTQUFZLE1BQU07U0FBTyxPQUFPO1FBQWM7Ozs7O09BQzNDOzs7OztNQUNDLEdBUkQ7Ozs7YUFRQyxDQUNUO0tBQ0U7Ozs7O0tBQ0wsd0JBQUMsVUFBRDtNQUNFLGVBQWU7T0FDYixvQkFBb0IsSUFBSTtPQUN4QixrQkFBa0IsSUFBSTtPQUN0QixjQUFjLENBQUMsQ0FBQztNQUNsQjtNQUNBLFdBQVU7Z0JBQ1g7S0FFTzs7Ozs7SUFDTDs7Ozs7O0VBQ0Y7Ozs7WUFJUCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osTUFBTSxLQUFLLFNBQ1YsTUFBTSxLQUFLLFNBQVM7S0FDbEIsTUFBTSxTQUFTLEdBQUcsT0FBTztLQUN6QixNQUFNLFVBQVUsS0FBSyxXQUFXLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQztLQUNyRCxNQUFNLFVBQVUsT0FBTztLQUN2QixNQUFNLFdBQVcsVUFBVSxXQUFXLE1BQU07Ozs7S0FLNUMsTUFBTSxTQUFTLFVBQVUsaUJBQWlCO0tBQzFDLE1BQU0sYUFBYSxVQUFVLG1CQUFtQjtLQUVoRCxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU07S0FDN0IsTUFBTSxhQUFhLG1CQUFtQjtLQUN0QyxNQUFNLGdCQUFnQixXQUFXLFNBQVMsTUFBTTtLQUNoRCxNQUFNLGFBQWEsYUFBYSxTQUFTLFNBQVMsVUFBVSxTQUFTLE9BQU87S0FDNUUsTUFBTSxZQUFZLHNCQUFzQjtLQUN4QyxNQUFNLGVBQWUsUUFBUSxLQUFLLFNBQVM7S0FDM0MsTUFBTSxlQUFlLFFBQVEsS0FBSyxPQUFPOztLQUd6QyxNQUFNLGdCQUFnQixZQUFZLFNBQVMsSUFBSSxTQUFTO0tBQ3hELE1BQU0sZ0JBQWdCLFlBQVksU0FBUyxNQUFNLFNBQVM7S0FFMUQsT0FDRSx3QkFBQyxPQUFEO01BRUUsZUFBZSxrQkFBa0IsTUFBTTtNQUN2QyxZQUFZO01BQ1osU0FBUyxNQUFNLFdBQVcsR0FBRyxNQUFNO01BQ25DLFdBQVcsMEZBQTBGO2dCQUx2RztPQVFHLGNBQ0Msd0JBQUMsT0FBRCxFQUFLLFdBQVUsdURBQXdEOzs7OztPQUl4RSxjQUNDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDBGQUEyRjs7Ozs7T0FJM0csZ0JBQ0Msd0JBQUMsT0FBRCxFQUFLLFdBQVUsb0dBQXFHOzs7OztPQUVySCxnQkFDQyx3QkFBQyxPQUFELEVBQUssV0FBVSwwR0FBMkc7Ozs7O09BSTNILGFBQ0Msd0JBQUMsT0FBRCxFQUFLLFdBQVUsNkdBQThHOzs7OztPQUk5SCxpQkFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixRQUVDO1NBQUM7O1NBQUQsRUFBSyxXQUFVLGlGQUFrRjs7Ozs7Ozs7Ozs7UUFHakcsd0JBQUMsT0FBRCxFQUFLLFdBQVUsK0RBQWdFOzs7OztPQUU5RTs7Ozs7T0FJTixTQUNDLHdCQUFDLE9BQUQ7UUFDRSxXQUFXLENBQUMsWUFBWSxDQUFDLGlCQUFpQixNQUFNLFVBQVUsZUFBZSxNQUFNLFVBQVUsS0FBSyxLQUFLO1FBQ25HLGNBQWMsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNO1FBQzdDLFdBQVcsNkhBQ1QsTUFBTSxVQUFVLGVBQWUsTUFBTSxVQUFVLEtBQUssS0FBSyxLQUFLLENBQUMsWUFBWSxDQUFDLGdCQUN4RSx1REFDQTtrQkFHTix3QkFBQyxZQUFEO1NBQVksTUFBTSxNQUFNO1NBQU0sT0FBTyxNQUFNO1FBQVE7Ozs7O09BQ2hEOzs7OztPQUlOLGlCQUNDLHdCQUFDLFFBQUQ7UUFDRSxXQUFXLDBIQUEwSDtrQkFFcEk7T0FDRzs7Ozs7T0FFUCxpQkFDQyx3QkFBQyxRQUFEO1FBQ0UsV0FBVyw4SEFBOEg7a0JBRXhJO09BQ0c7Ozs7O01BRUw7UUF4RUU7Ozs7WUF3RUY7SUFFVCxDQUFDLENBQ0g7R0FDRzs7Ozs7RUFDRjs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDaGVzc0JvYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBDaGVzcywgU3F1YXJlIH0gZnJvbSAnY2hlc3MuanMnO1xuaW1wb3J0IHsgQ2hlc3NQaWVjZSB9IGZyb20gJy4vQ2hlc3NQaWVjZXMnO1xuaW1wb3J0IHsgUGllY2VUeXBlLCBQaWVjZUNvbG9yLCBIaW50U3VnZ2VzdGlvbiB9IGZyb20gJy4uL3R5cGVzL2NoZXNzJztcblxuaW50ZXJmYWNlIENoZXNzQm9hcmRQcm9wcyB7XG4gIGdhbWU6IENoZXNzO1xuICBvbk1vdmU6IChmcm9tOiBzdHJpbmcsIHRvOiBzdHJpbmcsIHByb21vdGlvbj86IHN0cmluZykgPT4gYm9vbGVhbjtcbiAgcGxheWVyQ29sb3I6IFBpZWNlQ29sb3I7XG4gIGlzQm90VGhpbmtpbmc6IGJvb2xlYW47XG4gIGxhc3RNb3ZlOiB7IGZyb206IHN0cmluZzsgdG86IHN0cmluZyB9IHwgbnVsbDtcbiAgaGludDogSGludFN1Z2dlc3Rpb24gfCBudWxsO1xuICBkaXNhYmxlZD86IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBDaGVzc0JvYXJkOiBSZWFjdC5GQzxDaGVzc0JvYXJkUHJvcHM+ID0gKHtcbiAgZ2FtZSxcbiAgb25Nb3ZlLFxuICBwbGF5ZXJDb2xvcixcbiAgaXNCb3RUaGlua2luZyxcbiAgbGFzdE1vdmUsXG4gIGhpbnQsXG4gIGRpc2FibGVkID0gZmFsc2UsXG59KSA9PiB7XG4gIGNvbnN0IFtzZWxlY3RlZFNxdWFyZSwgc2V0U2VsZWN0ZWRTcXVhcmVdID0gdXNlU3RhdGU8U3F1YXJlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtsZWdhbE1vdmVzLCBzZXRMZWdhbE1vdmVzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XG4gIGNvbnN0IFtwZW5kaW5nUHJvbW90aW9uLCBzZXRQZW5kaW5nUHJvbW90aW9uXSA9IHVzZVN0YXRlPHsgZnJvbTogc3RyaW5nOyB0bzogc3RyaW5nIH0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2RyYWdnZWRTcXVhcmUsIHNldERyYWdnZWRTcXVhcmVdID0gdXNlU3RhdGU8U3F1YXJlIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgaXNGbGlwcGVkID0gcGxheWVyQ29sb3IgPT09ICdiJztcbiAgY29uc3QgYm9hcmQgPSBnYW1lLmJvYXJkKCk7XG5cbiAgLy8gRmluZCBLaW5nIHNxdWFyZSBpZiBjdXJyZW50bHkgaW4gY2hlY2tcbiAgbGV0IGluQ2hlY2tLaW5nU3F1YXJlOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgaWYgKGdhbWUuaW5DaGVjaygpKSB7XG4gICAgY29uc3QgdHVybkNvbG9yID0gZ2FtZS50dXJuKCk7XG4gICAgZm9yIChsZXQgciA9IDA7IHIgPCA4OyByKyspIHtcbiAgICAgIGZvciAobGV0IGMgPSAwOyBjIDwgODsgYysrKSB7XG4gICAgICAgIGNvbnN0IHAgPSBib2FyZFtyXVtjXTtcbiAgICAgICAgaWYgKHAgJiYgcC50eXBlID09PSAnaycgJiYgcC5jb2xvciA9PT0gdHVybkNvbG9yKSB7XG4gICAgICAgICAgaW5DaGVja0tpbmdTcXVhcmUgPSBTdHJpbmcuZnJvbUNoYXJDb2RlKCdhJy5jaGFyQ29kZUF0KDApICsgYykgKyAoOCAtIHIpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8gSGFuZGxlIHNxdWFyZSBzZWxlY3Rpb24gLyBjbGlja1xuICBjb25zdCBoYW5kbGVTcXVhcmVDbGljayA9IChzcXVhcmU6IFNxdWFyZSkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCBpc0JvdFRoaW5raW5nKSByZXR1cm47XG5cbiAgICAvLyBJZiBhbHJlYWR5IHNlbGVjdGVkLCBjaGVjayBpZiB0aGlzIGNsaWNrIGlzIGEgdmFsaWQgZGVzdGluYXRpb25cbiAgICBpZiAoc2VsZWN0ZWRTcXVhcmUpIHtcbiAgICAgIGlmIChzZWxlY3RlZFNxdWFyZSA9PT0gc3F1YXJlKSB7XG4gICAgICAgIC8vIERlc2VsZWN0XG4gICAgICAgIHNldFNlbGVjdGVkU3F1YXJlKG51bGwpO1xuICAgICAgICBzZXRMZWdhbE1vdmVzKFtdKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBpZiAobGVnYWxNb3Zlcy5pbmNsdWRlcyhzcXVhcmUpKSB7XG4gICAgICAgIC8vIENoZWNrIGZvciBwYXduIHByb21vdGlvblxuICAgICAgICBjb25zdCBwaWVjZSA9IGdhbWUuZ2V0KHNlbGVjdGVkU3F1YXJlKTtcbiAgICAgICAgaWYgKFxuICAgICAgICAgIHBpZWNlICYmXG4gICAgICAgICAgcGllY2UudHlwZSA9PT0gJ3AnICYmXG4gICAgICAgICAgKChwaWVjZS5jb2xvciA9PT0gJ3cnICYmIHNxdWFyZVsxXSA9PT0gJzgnKSB8fCAocGllY2UuY29sb3IgPT09ICdiJyAmJiBzcXVhcmVbMV0gPT09ICcxJykpXG4gICAgICAgICkge1xuICAgICAgICAgIHNldFBlbmRpbmdQcm9tb3Rpb24oeyBmcm9tOiBzZWxlY3RlZFNxdWFyZSwgdG86IHNxdWFyZSB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBFeGVjdXRlIHN0YW5kYXJkIG1vdmVcbiAgICAgICAgY29uc3Qgc3VjY2VzcyA9IG9uTW92ZShzZWxlY3RlZFNxdWFyZSwgc3F1YXJlKTtcbiAgICAgICAgaWYgKHN1Y2Nlc3MpIHtcbiAgICAgICAgICBzZXRTZWxlY3RlZFNxdWFyZShudWxsKTtcbiAgICAgICAgICBzZXRMZWdhbE1vdmVzKFtdKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBTZWxlY3QgcGllY2UgaWYgaXQgYmVsb25ncyB0byBhY3RpdmUgdHVybiBhbmQgcGxheWVyXG4gICAgY29uc3QgcGllY2UgPSBnYW1lLmdldChzcXVhcmUpO1xuICAgIGlmIChwaWVjZSAmJiBwaWVjZS5jb2xvciA9PT0gZ2FtZS50dXJuKCkgJiYgcGllY2UuY29sb3IgPT09IHBsYXllckNvbG9yKSB7XG4gICAgICBzZXRTZWxlY3RlZFNxdWFyZShzcXVhcmUpO1xuICAgICAgY29uc3QgbW92ZXMgPSBnYW1lLm1vdmVzKHsgc3F1YXJlLCB2ZXJib3NlOiB0cnVlIH0pO1xuICAgICAgc2V0TGVnYWxNb3Zlcyhtb3Zlcy5tYXAoKG0pID0+IG0udG8pKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0U2VsZWN0ZWRTcXVhcmUobnVsbCk7XG4gICAgICBzZXRMZWdhbE1vdmVzKFtdKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gRHJhZyAmIGRyb3Agc3VwcG9ydFxuICBjb25zdCBoYW5kbGVEcmFnU3RhcnQgPSAoZTogUmVhY3QuRHJhZ0V2ZW50LCBzcXVhcmU6IFNxdWFyZSkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCBpc0JvdFRoaW5raW5nKSB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHBpZWNlID0gZ2FtZS5nZXQoc3F1YXJlKTtcbiAgICBpZiAoIXBpZWNlIHx8IHBpZWNlLmNvbG9yICE9PSBnYW1lLnR1cm4oKSB8fCBwaWVjZS5jb2xvciAhPT0gcGxheWVyQ29sb3IpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0RHJhZ2dlZFNxdWFyZShzcXVhcmUpO1xuICAgIHNldFNlbGVjdGVkU3F1YXJlKHNxdWFyZSk7XG4gICAgY29uc3QgbW92ZXMgPSBnYW1lLm1vdmVzKHsgc3F1YXJlLCB2ZXJib3NlOiB0cnVlIH0pO1xuICAgIHNldExlZ2FsTW92ZXMobW92ZXMubWFwKChtKSA9PiBtLnRvKSk7XG4gICAgZS5kYXRhVHJhbnNmZXIuc2V0RGF0YSgndGV4dC9wbGFpbicsIHNxdWFyZSk7XG4gICAgZS5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9ICdtb3ZlJztcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEcmFnT3ZlciA9IChlOiBSZWFjdC5EcmFnRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZS5kYXRhVHJhbnNmZXIuZHJvcEVmZmVjdCA9ICdtb3ZlJztcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEcm9wID0gKGU6IFJlYWN0LkRyYWdFdmVudCwgdGFyZ2V0U3F1YXJlOiBTcXVhcmUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgY29uc3Qgc291cmNlU3F1YXJlID0gZHJhZ2dlZFNxdWFyZSB8fCAoZS5kYXRhVHJhbnNmZXIuZ2V0RGF0YSgndGV4dC9wbGFpbicpIGFzIFNxdWFyZSk7XG4gICAgc2V0RHJhZ2dlZFNxdWFyZShudWxsKTtcblxuICAgIGlmICghc291cmNlU3F1YXJlIHx8IHNvdXJjZVNxdWFyZSA9PT0gdGFyZ2V0U3F1YXJlKSByZXR1cm47XG5cbiAgICBpZiAobGVnYWxNb3Zlcy5pbmNsdWRlcyh0YXJnZXRTcXVhcmUpKSB7XG4gICAgICBjb25zdCBwaWVjZSA9IGdhbWUuZ2V0KHNvdXJjZVNxdWFyZSk7XG4gICAgICBpZiAoXG4gICAgICAgIHBpZWNlICYmXG4gICAgICAgIHBpZWNlLnR5cGUgPT09ICdwJyAmJlxuICAgICAgICAoKHBpZWNlLmNvbG9yID09PSAndycgJiYgdGFyZ2V0U3F1YXJlWzFdID09PSAnOCcpIHx8XG4gICAgICAgICAgKHBpZWNlLmNvbG9yID09PSAnYicgJiYgdGFyZ2V0U3F1YXJlWzFdID09PSAnMScpKVxuICAgICAgKSB7XG4gICAgICAgIHNldFBlbmRpbmdQcm9tb3Rpb24oeyBmcm9tOiBzb3VyY2VTcXVhcmUsIHRvOiB0YXJnZXRTcXVhcmUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIG9uTW92ZShzb3VyY2VTcXVhcmUsIHRhcmdldFNxdWFyZSk7XG4gICAgICBzZXRTZWxlY3RlZFNxdWFyZShudWxsKTtcbiAgICAgIHNldExlZ2FsTW92ZXMoW10pO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVQcm9tb3Rpb25TZWxlY3QgPSAocHJvbW90ZWRQaWVjZTogJ3EnIHwgJ3InIHwgJ2InIHwgJ24nKSA9PiB7XG4gICAgaWYgKHBlbmRpbmdQcm9tb3Rpb24pIHtcbiAgICAgIG9uTW92ZShwZW5kaW5nUHJvbW90aW9uLmZyb20sIHBlbmRpbmdQcm9tb3Rpb24udG8sIHByb21vdGVkUGllY2UpO1xuICAgICAgc2V0UGVuZGluZ1Byb21vdGlvbihudWxsKTtcbiAgICAgIHNldFNlbGVjdGVkU3F1YXJlKG51bGwpO1xuICAgICAgc2V0TGVnYWxNb3ZlcyhbXSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIFJhbmtzIDEgdG8gOCwgRmlsZXMgYSB0byBoXG4gIGNvbnN0IHJhbmtzID0gaXNGbGlwcGVkID8gWzEsIDIsIDMsIDQsIDUsIDYsIDcsIDhdIDogWzgsIDcsIDYsIDUsIDQsIDMsIDIsIDFdO1xuICBjb25zdCBmaWxlcyA9IGlzRmxpcHBlZCA/IFsnaCcsICdnJywgJ2YnLCAnZScsICdkJywgJ2MnLCAnYicsICdhJ10gOiBbJ2EnLCAnYicsICdjJywgJ2QnLCAnZScsICdmJywgJ2cnLCAnaCddO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgey8qIFByb21vdGlvbiBEaWFsb2cgTW9kYWwgKi99XG4gICAgICB7cGVuZGluZ1Byb21vdGlvbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCB6LTUwIGJnLWJsYWNrLzYwIGJhY2tkcm9wLWJsdXIteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjMjMyNzJBXSBib3JkZXIgYm9yZGVyLXdoaXRlLzIwIHJvdW5kZWQteGwgcC00IHNoYWRvdy0yeGwgdGV4dC1jZW50ZXIgbWF4LXcteHMgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMTUwXCI+XG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc3RvbmUtMjAwIG1iLTMgdHJhY2tpbmctd2lkZVwiPlxuICAgICAgICAgICAgICBTZWxlY3QgUHJvbW90aW9uIFBpZWNlXG4gICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC0yXCI+XG4gICAgICAgICAgICAgIHsoWydxJywgJ3InLCAnYicsICduJ10gYXMgY29uc3QpLm1hcCgocFR5cGUpID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3BUeXBlfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJvbW90aW9uU2VsZWN0KHBUeXBlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBiZy1zdG9uZS04MDAvODAgaG92ZXI6YmctZW1lcmFsZC02MDAvNDAgYm9yZGVyIGJvcmRlci1zdG9uZS02MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLXRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgYWN0aXZlOnNjYWxlLTk1IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGFzcGVjdC1zcXVhcmVcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9e3BUeXBlID09PSAncScgPyAnUXVlZW4nIDogcFR5cGUgPT09ICdyJyA/ICdSb29rJyA6IHBUeXBlID09PSAnYicgPyAnQmlzaG9wJyA6ICdLbmlnaHQnfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDaGVzc1BpZWNlIHR5cGU9e3BUeXBlfSBjb2xvcj17cGxheWVyQ29sb3J9IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldFBlbmRpbmdQcm9tb3Rpb24obnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRTcXVhcmUobnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0TGVnYWxNb3ZlcyhbXSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTMgdGV4dC14cyB0ZXh0LXN0b25lLTQwMCBob3Zlcjp0ZXh0LXN0b25lLTIwMFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE1haW4gQm9hcmQgRnJhbWUgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBzbTpwLTMgYmctWyMxRTIyMjZdIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCByaW5nLTEgcmluZy1ibGFjay80MFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTggZ3JpZC1yb3dzLTggdy1bMzIwcHhdIGgtWzMyMHB4XSBzbTp3LVs0MjBweF0gc206aC1bNDIwcHhdIG1kOnctWzUwMHB4XSBtZDpoLVs1MDBweF0gbGc6dy1bNTQwcHhdIGxnOmgtWzU0MHB4XSByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLWJsYWNrLzQwIHNoYWRvdy1pbm5lclwiPlxuICAgICAgICAgIHtyYW5rcy5tYXAoKHJhbmspID0+XG4gICAgICAgICAgICBmaWxlcy5tYXAoKGZpbGUpID0+IHtcbiAgICAgICAgICAgICAgY29uc3Qgc3F1YXJlID0gYCR7ZmlsZX0ke3Jhbmt9YCBhcyBTcXVhcmU7XG4gICAgICAgICAgICAgIGNvbnN0IGZpbGVJZHggPSBmaWxlLmNoYXJDb2RlQXQoMCkgLSAnYScuY2hhckNvZGVBdCgwKTtcbiAgICAgICAgICAgICAgY29uc3QgcmFua0lkeCA9IHJhbmsgLSAxO1xuICAgICAgICAgICAgICBjb25zdCBpc0xpZ2h0ID0gKGZpbGVJZHggKyByYW5rSWR4KSAlIDIgIT09IDA7XG5cbiAgICAgICAgICAgICAgLy8gVGlsZSBjb2xvcnM6IHVzZXIgcmVxdWVzdGVkIGxpZ2h0IHllbGxvdyBhbmQgbGlnaHQgZ3JlZW5cbiAgICAgICAgICAgICAgLy8gTGlnaHQ6IHdhcm0gc29mdCBsaWdodCB5ZWxsb3cgI0Y0RjJCQVxuICAgICAgICAgICAgICAvLyBEYXJrOiBwbGVhc2FudCBzb2Z0IG9saXZlIGdyZWVuICM3Nzk1NTZcbiAgICAgICAgICAgICAgY29uc3QgdGlsZUJnID0gaXNMaWdodCA/ICdiZy1bI0Y0RjJCQV0nIDogJ2JnLVsjNzc5NTU2XSc7XG4gICAgICAgICAgICAgIGNvbnN0IGxhYmVsQ29sb3IgPSBpc0xpZ2h0ID8gJ3RleHQtWyM3Nzk1NTZdJyA6ICd0ZXh0LVsjRjRGMkJBXSc7XG5cbiAgICAgICAgICAgICAgY29uc3QgcGllY2UgPSBnYW1lLmdldChzcXVhcmUpO1xuICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRTcXVhcmUgPT09IHNxdWFyZTtcbiAgICAgICAgICAgICAgY29uc3QgaXNMZWdhbFRhcmdldCA9IGxlZ2FsTW92ZXMuaW5jbHVkZXMoc3F1YXJlKTtcbiAgICAgICAgICAgICAgY29uc3QgaXNMYXN0TW92ZSA9IGxhc3RNb3ZlICYmIChsYXN0TW92ZS5mcm9tID09PSBzcXVhcmUgfHwgbGFzdE1vdmUudG8gPT09IHNxdWFyZSk7XG4gICAgICAgICAgICAgIGNvbnN0IGlzSW5DaGVjayA9IGluQ2hlY2tLaW5nU3F1YXJlID09PSBzcXVhcmU7XG4gICAgICAgICAgICAgIGNvbnN0IGlzSGludFNvdXJjZSA9IGhpbnQgJiYgaGludC5mcm9tID09PSBzcXVhcmU7XG4gICAgICAgICAgICAgIGNvbnN0IGlzSGludFRhcmdldCA9IGhpbnQgJiYgaGludC50byA9PT0gc3F1YXJlO1xuXG4gICAgICAgICAgICAgIC8vIExhYmVsIGluZGljYXRvcnMgb24gZWRnZXNcbiAgICAgICAgICAgICAgY29uc3Qgc2hvd0ZpbGVMYWJlbCA9IGlzRmxpcHBlZCA/IHJhbmsgPT09IDggOiByYW5rID09PSAxO1xuICAgICAgICAgICAgICBjb25zdCBzaG93UmFua0xhYmVsID0gaXNGbGlwcGVkID8gZmlsZSA9PT0gJ2gnIDogZmlsZSA9PT0gJ2EnO1xuXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAga2V5PXtzcXVhcmV9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTcXVhcmVDbGljayhzcXVhcmUpfVxuICAgICAgICAgICAgICAgICAgb25EcmFnT3Zlcj17aGFuZGxlRHJhZ092ZXJ9XG4gICAgICAgICAgICAgICAgICBvbkRyb3A9eyhlKSA9PiBoYW5kbGVEcm9wKGUsIHNxdWFyZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBzZWxlY3Qtbm9uZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke3RpbGVCZ31gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHsvKiBMYXN0IE1vdmUgT3ZlcmxheSAqL31cbiAgICAgICAgICAgICAgICAgIHtpc0xhc3RNb3ZlICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWFtYmVyLTMwMC8zNSBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBTZWxlY3RlZCBTcXVhcmUgT3ZlcmxheSAqL31cbiAgICAgICAgICAgICAgICAgIHtpc1NlbGVjdGVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXllbGxvdy00MDAvNTAgcmluZy0yIHJpbmctaW5zZXQgcmluZy15ZWxsb3ctNDAwIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgey8qIEhpbnQgSGlnaGxpZ2h0ICovfVxuICAgICAgICAgICAgICAgICAge2lzSGludFNvdXJjZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1jeWFuLTQwMC8zNSByaW5nLTIgcmluZy1pbnNldCByaW5nLWN5YW4tNDAwIHBvaW50ZXItZXZlbnRzLW5vbmUgYW5pbWF0ZS1wdWxzZVwiIC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2lzSGludFRhcmdldCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1lbWVyYWxkLTQwMC80MCByaW5nLTIgcmluZy1pbnNldCByaW5nLWVtZXJhbGQtNDAwIHBvaW50ZXItZXZlbnRzLW5vbmUgYW5pbWF0ZS1wdWxzZVwiIC8+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICB7LyogS2luZyBDaGVjayBSZWQgUHVsc2UgKi99XG4gICAgICAgICAgICAgICAgICB7aXNJbkNoZWNrICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXJlZC02MDAvNTAgcmluZy00IHJpbmctaW5zZXQgcmluZy1yZWQtNTAwIGFuaW1hdGUtcHVsc2UgcG9pbnRlci1ldmVudHMtbm9uZSByb3VuZGVkLXNtXCIgLz5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBMZWdhbCBNb3ZlIEluZGljYXRvcnMgKi99XG4gICAgICAgICAgICAgICAgICB7aXNMZWdhbFRhcmdldCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwb2ludGVyLWV2ZW50cy1ub25lIHotMjBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cGllY2UgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBDYXB0dXJlIHJpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1bODIlXSBoLVs4MiVdIHJvdW5kZWQtZnVsbCBib3JkZXItWzVweF0gYm9yZGVyLWJsYWNrLzI1IHJpbmctMiByaW5nLXdoaXRlLzIwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gTW92ZSBkb3RcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgc206dy00IHNtOmgtNCByb3VuZGVkLWZ1bGwgYmctYmxhY2svMjUgc2hhZG93LXNtXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBQaWVjZSBHcmFwaGljICovfVxuICAgICAgICAgICAgICAgICAge3BpZWNlICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGRyYWdnYWJsZT17IWRpc2FibGVkICYmICFpc0JvdFRoaW5raW5nICYmIHBpZWNlLmNvbG9yID09PSBwbGF5ZXJDb2xvciAmJiBwaWVjZS5jb2xvciA9PT0gZ2FtZS50dXJuKCl9XG4gICAgICAgICAgICAgICAgICAgICAgb25EcmFnU3RhcnQ9eyhlKSA9PiBoYW5kbGVEcmFnU3RhcnQoZSwgc3F1YXJlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSB6LTEwIHctWzg4JV0gaC1bODglXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0xMDAgZWFzZS1vdXQgYWN0aXZlOnNjYWxlLTk1ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBwaWVjZS5jb2xvciA9PT0gcGxheWVyQ29sb3IgJiYgcGllY2UuY29sb3IgPT09IGdhbWUudHVybigpICYmICFkaXNhYmxlZCAmJiAhaXNCb3RUaGlua2luZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdob3ZlcjpzY2FsZS0xMDUgY3Vyc29yLWdyYWIgYWN0aXZlOmN1cnNvci1ncmFiYmluZydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnY3Vyc29yLXBvaW50ZXInXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlc3NQaWVjZSB0eXBlPXtwaWVjZS50eXBlfSBjb2xvcj17cGllY2UuY29sb3J9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgey8qIEJvYXJkIENvb3JkaW5hdGUgTGFiZWxzICovfVxuICAgICAgICAgICAgICAgICAge3Nob3dSYW5rTGFiZWwgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIHRvcC0wLjUgbGVmdC0xIHRleHQtWzEwcHhdIHNtOnRleHQtWzExcHhdIGZvbnQtYm9sZCBmb250LW1vbm8tbnVtcyBwb2ludGVyLWV2ZW50cy1ub25lIHNlbGVjdC1ub25lIG9wYWNpdHktODUgJHtsYWJlbENvbG9yfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7cmFua31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHtzaG93RmlsZUxhYmVsICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSBib3R0b20tMC41IHJpZ2h0LTEgdGV4dC1bMTBweF0gc206dGV4dC1bMTFweF0gZm9udC1ib2xkIGZvbnQtbW9uby1udW1zIHBvaW50ZXItZXZlbnRzLW5vbmUgc2VsZWN0LW5vbmUgb3BhY2l0eS04NSAke2xhYmVsQ29sb3J9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtmaWxlfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==