const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
import { X, RotateCcw, Volume2, Zap, Download, FileText } from "/node_modules/.vite/deps/lucide-react.js?v=c3d5a9dc";
import { downloadProjectZip } from "/src/utils/exportSourceZip.ts";
var _jsxFileName = "/app/applet/src/components/SettingsModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
export const SettingsModal = ({ isOpen, onClose, stats, onUpdatePlayerElo, onResetStats, isSoundMuted, onToggleSound, showBlunderAlerts, onToggleBlunderAlerts, onDownloadSource }) => {
	const [customElo, setCustomElo] = useState(stats.userElo);
	if (!isOpen) return null;
	const handleApplyElo = () => {
		const val = Math.max(100, Math.min(2600, Number(customElo) || 250));
		onUpdatePlayerElo(val);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-[#1E2226] border border-white/15 rounded-2xl p-6 shadow-2xl max-w-md w-full animate-in fade-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-3 border-b border-white/10",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-display font-bold text-lg text-stone-100",
						children: "Trainer Settings"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-1 text-stone-400 hover:text-stone-200 rounded-lg hover:bg-white/5 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "py-4 space-y-5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-stone-300 uppercase tracking-wider mb-1.5",
								children: "Current Rating (Elo)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-stone-400 mb-2",
								children: "The bot will continuously tune its difficulty to stay exactly +100 Elo above this rating."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									min: "100",
									max: "2600",
									step: "25",
									value: customElo,
									onChange: (e) => setCustomElo(Number(e.target.value)),
									className: "flex-1 bg-black/40 border border-white/15 rounded-xl px-3 py-2 text-stone-100 font-mono-nums text-sm focus:outline-none focus:border-amber-400"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleApplyElo,
									className: "py-2 px-4 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-semibold transition-colors",
									children: "Set Rating"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 13
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "block text-xs font-medium text-stone-400 mb-1.5",
							children: "Quick Starting Levels"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-4 gap-1.5",
							children: [
								{
									label: "Beginner",
									elo: 250
								},
								{
									label: "Novice",
									elo: 500
								},
								{
									label: "Casual",
									elo: 800
								},
								{
									label: "Club",
									elo: 1100
								}
							].map((lvl) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setCustomElo(lvl.elo);
									onUpdatePlayerElo(lvl.elo);
								},
								className: `py-1.5 px-2 text-xs rounded-lg border transition-all ${stats.userElo === lvl.elo ? "bg-amber-500/20 border-amber-500/40 text-amber-300 font-semibold" : "bg-stone-800/60 border-white/5 text-stone-300 hover:bg-stone-800"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "font-semibold",
									children: lvl.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-stone-400 font-mono-nums",
									children: lvl.elo
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 19
								}, this)]
							}, lvl.elo, true, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 pt-2 border-t border-white/10",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-xs text-stone-200",
									children: [/* @__PURE__ */ _jsxDEV(Volume2, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 117,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Audio Sound Effects" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 118,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: onToggleSound,
									className: `w-11 h-6 rounded-full transition-colors relative ${!isSoundMuted ? "bg-emerald-600" : "bg-stone-700"}`,
									children: /* @__PURE__ */ _jsxDEV("div", { className: `w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${!isSoundMuted ? "right-1" : "left-1"}` }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 120,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-xs text-stone-200",
									children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 136,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Coach Blunder Alerts" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 137,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: onToggleBlunderAlerts,
									className: `w-11 h-6 rounded-full transition-colors relative ${showBlunderAlerts ? "bg-amber-600" : "bg-stone-700"}`,
									children: /* @__PURE__ */ _jsxDEV("div", { className: `w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${showBlunderAlerts ? "right-1" : "left-1"}` }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 145,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 139,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-3 border-t border-white/10 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-semibold text-stone-300 uppercase tracking-wider mb-1",
									children: "Export Source Code"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 156,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => downloadProjectZip(),
									className: "flex items-center justify-center gap-2 w-full py-2.5 px-3 text-xs text-stone-100 bg-stone-800 hover:bg-stone-700 active:scale-95 rounded-xl transition-all border border-white/15 font-semibold shadow-sm",
									children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 163,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Download Project Archive (.zip)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 13
								}, this),
								onDownloadSource && /* @__PURE__ */ _jsxDEV("button", {
									onClick: onDownloadSource,
									className: "flex items-center justify-center gap-2 w-full py-2 px-3 text-xs text-stone-300 hover:text-white bg-transparent hover:bg-white/5 rounded-xl transition-colors font-medium border border-white/5",
									children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-3.5 h-3.5 text-stone-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 171,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Download Single Document (.md)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 172,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 167,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-2",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									if (window.confirm("Reset all match history and restore starting 250 Elo?")) {
										onResetStats();
										setCustomElo(250);
									}
								},
								className: "flex items-center justify-center gap-1.5 w-full py-2 px-3 text-xs text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors border border-red-500/20",
								children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 188,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset History & Return to 250 Elo" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 189,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 178,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 pt-3 border-t border-white/10 flex justify-end",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "py-2 px-4 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl transition-colors",
						children: "Done"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLEdBQUcsV0FBVyxTQUFzQixLQUFLLFVBQVUsZ0JBQWdCO0FBRTVFLFNBQVMsMEJBQTBCOzs7QUFlbkMsT0FBTyxNQUFNLGlCQUErQyxFQUMxRCxRQUNBLFNBQ0EsT0FDQSxtQkFDQSxjQUNBLGNBQ0EsZUFDQSxtQkFDQSx1QkFDQSx1QkFDSTtDQUNKLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLE1BQU0sT0FBTztDQUV4RCxJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE1BQU0sdUJBQXVCO0VBQzNCLE1BQU0sTUFBTSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksTUFBTSxPQUFPLFNBQVMsS0FBSyxHQUFHLENBQUM7RUFDbEUsa0JBQWtCLEdBQUc7Q0FDdkI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZ0Q7S0FFMUQ7Ozs7ZUFDSix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7S0FDbEI7Ozs7YUFDTDs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNkU7T0FFdkY7Ozs7O09BQ1Asd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQThCO09BRXhDOzs7OztPQUNILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxLQUFJO1NBQ0osS0FBSTtTQUNKLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLGFBQWEsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1NBQ3BELFdBQVU7UUFDWDs7OztrQkFDRCx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7O01BQ0Y7Ozs7O01BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFrRDtNQUEyQjs7OztnQkFDN0Ysd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1o7UUFDQztTQUFFLE9BQU87U0FBWSxLQUFLO1FBQUk7UUFDOUI7U0FBRSxPQUFPO1NBQVUsS0FBSztRQUFJO1FBQzVCO1NBQUUsT0FBTztTQUFVLEtBQUs7UUFBSTtRQUM1QjtTQUFFLE9BQU87U0FBUSxLQUFLO1FBQUs7T0FDN0IsQ0FBQyxDQUFDLEtBQUssUUFDTCx3QkFBQyxVQUFEO1FBRUUsZUFBZTtTQUNiLGFBQWEsSUFBSSxHQUFHO1NBQ3BCLGtCQUFrQixJQUFJLEdBQUc7UUFDM0I7UUFDQSxXQUFXLHdEQUNULE1BQU0sWUFBWSxJQUFJLE1BQ2xCLHFFQUNBO2tCQVRSLENBWUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWlCLElBQUk7UUFBVzs7OztrQkFDL0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQTZDLElBQUk7UUFBUzs7OztnQkFDbkU7VUFiRCxJQUFJOzs7O2NBYUgsQ0FDVDtNQUNFOzs7O2NBQ0Y7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsMkJBQTRCOzs7O21CQUMvQyx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2lCQUM1Qjs7Ozs7a0JBQ0wsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFXLG9EQUNULENBQUMsZUFBZSxtQkFBbUI7bUJBR3JDLHdCQUFDLE9BQUQsRUFDRSxXQUFXLHFFQUNULENBQUMsZUFBZSxZQUFZLFdBRS9COzs7OztRQUNLOzs7O2dCQUNMOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUseUJBQTBCOzs7O21CQUN6Qyx3QkFBQyxRQUFELFlBQU0sdUJBQTBCOzs7O2lCQUM3Qjs7Ozs7a0JBQ0wsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFXLG9EQUNULG9CQUFvQixpQkFBaUI7bUJBR3ZDLHdCQUFDLE9BQUQsRUFDRSxXQUFXLHFFQUNULG9CQUFvQixZQUFZLFdBRW5DOzs7OztRQUNLOzs7O2dCQUNMOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFxRTtRQUUvRTs7Ozs7UUFDTCx3QkFBQyxVQUFEO1NBQ0UsZUFBZSxtQkFBbUI7U0FDbEMsV0FBVTttQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OzttQkFDOUMsd0JBQUMsUUFBRCxZQUFNLGtDQUFxQzs7OztpQkFDckM7Ozs7OztRQUNQLG9CQUNDLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDZCQUE4Qjs7OzttQkFDbEQsd0JBQUMsUUFBRCxZQUFNLGlDQUFvQzs7OztpQkFDcEM7Ozs7OztPQUVQOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLElBQUksT0FBTyxRQUFRLHVEQUF1RCxHQUFHO1VBQzNFLGFBQWE7VUFDYixhQUFhLEdBQUc7U0FDbEI7UUFDRjtRQUNBLFdBQVU7a0JBUFosQ0FTRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O2tCQUNwQyx3QkFBQyxRQUFELFlBQU0sb0NBQXVDOzs7O2dCQUN2Qzs7Ozs7O01BQ0w7Ozs7O0tBQ0Y7Ozs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7O0lBQ0w7Ozs7O0dBRUY7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNldHRpbmdzTW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFgsIFJvdGF0ZUNjdywgVm9sdW1lMiwgU2hpZWxkQ2hlY2ssIFphcCwgRG93bmxvYWQsIEZpbGVUZXh0IH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFBsYXllclN0YXRzIH0gZnJvbSAnLi4vdHlwZXMvY2hlc3MnO1xuaW1wb3J0IHsgZG93bmxvYWRQcm9qZWN0WmlwIH0gZnJvbSAnLi4vdXRpbHMvZXhwb3J0U291cmNlWmlwJztcblxuaW50ZXJmYWNlIFNldHRpbmdzTW9kYWxQcm9wcyB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgc3RhdHM6IFBsYXllclN0YXRzO1xuICBvblVwZGF0ZVBsYXllckVsbzogKG5ld0VsbzogbnVtYmVyKSA9PiB2b2lkO1xuICBvblJlc2V0U3RhdHM6ICgpID0+IHZvaWQ7XG4gIGlzU291bmRNdXRlZDogYm9vbGVhbjtcbiAgb25Ub2dnbGVTb3VuZDogKCkgPT4gdm9pZDtcbiAgc2hvd0JsdW5kZXJBbGVydHM6IGJvb2xlYW47XG4gIG9uVG9nZ2xlQmx1bmRlckFsZXJ0czogKCkgPT4gdm9pZDtcbiAgb25Eb3dubG9hZFNvdXJjZT86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBTZXR0aW5nc01vZGFsOiBSZWFjdC5GQzxTZXR0aW5nc01vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICBzdGF0cyxcbiAgb25VcGRhdGVQbGF5ZXJFbG8sXG4gIG9uUmVzZXRTdGF0cyxcbiAgaXNTb3VuZE11dGVkLFxuICBvblRvZ2dsZVNvdW5kLFxuICBzaG93Qmx1bmRlckFsZXJ0cyxcbiAgb25Ub2dnbGVCbHVuZGVyQWxlcnRzLFxuICBvbkRvd25sb2FkU291cmNlLFxufSkgPT4ge1xuICBjb25zdCBbY3VzdG9tRWxvLCBzZXRDdXN0b21FbG9dID0gdXNlU3RhdGUoc3RhdHMudXNlckVsbyk7XG5cbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGhhbmRsZUFwcGx5RWxvID0gKCkgPT4ge1xuICAgIGNvbnN0IHZhbCA9IE1hdGgubWF4KDEwMCwgTWF0aC5taW4oMjYwMCwgTnVtYmVyKGN1c3RvbUVsbykgfHwgMjUwKSk7XG4gICAgb25VcGRhdGVQbGF5ZXJFbG8odmFsKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGJnLWJsYWNrLzc1IGJhY2tkcm9wLWJsdXItc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjMUUyMjI2XSBib3JkZXIgYm9yZGVyLXdoaXRlLzE1IHJvdW5kZWQtMnhsIHAtNiBzaGFkb3ctMnhsIG1heC13LW1kIHctZnVsbCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXdoaXRlLzEwXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSBmb250LWJvbGQgdGV4dC1sZyB0ZXh0LXN0b25lLTEwMFwiPlxuICAgICAgICAgICAgVHJhaW5lciBTZXR0aW5nc1xuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXN0b25lLTQwMCBob3Zlcjp0ZXh0LXN0b25lLTIwMCByb3VuZGVkLWxnIGhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTQgc3BhY2UteS01XCI+XG4gICAgICAgICAgey8qIEVsbyBBZGp1c3RtZW50ICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc3RvbmUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgQ3VycmVudCBSYXRpbmcgKEVsbylcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc3RvbmUtNDAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgVGhlIGJvdCB3aWxsIGNvbnRpbnVvdXNseSB0dW5lIGl0cyBkaWZmaWN1bHR5IHRvIHN0YXkgZXhhY3RseSArMTAwIEVsbyBhYm92ZSB0aGlzIHJhdGluZy5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgbWluPVwiMTAwXCJcbiAgICAgICAgICAgICAgICBtYXg9XCIyNjAwXCJcbiAgICAgICAgICAgICAgICBzdGVwPVwiMjVcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21FbG99XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21FbG8oTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLWJsYWNrLzQwIGJvcmRlciBib3JkZXItd2hpdGUvMTUgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC1zdG9uZS0xMDAgZm9udC1tb25vLW51bXMgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTQwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBcHBseUVsb31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0yIHB4LTQgYmctYW1iZXItNTAwLzIwIGhvdmVyOmJnLWFtYmVyLTUwMC8zMCB0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBTZXQgUmF0aW5nXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUXVpY2sgUHJlc2V0IEJ1dHRvbnMgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zdG9uZS00MDAgbWItMS41XCI+UXVpY2sgU3RhcnRpbmcgTGV2ZWxzPC9zcGFuPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICB7IGxhYmVsOiAnQmVnaW5uZXInLCBlbG86IDI1MCB9LFxuICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdOb3ZpY2UnLCBlbG86IDUwMCB9LFxuICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdDYXN1YWwnLCBlbG86IDgwMCB9LFxuICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdDbHViJywgZWxvOiAxMTAwIH0sXG4gICAgICAgICAgICAgIF0ubWFwKChsdmwpID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2x2bC5lbG99XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEN1c3RvbUVsbyhsdmwuZWxvKTtcbiAgICAgICAgICAgICAgICAgICAgb25VcGRhdGVQbGF5ZXJFbG8obHZsLmVsbyk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMS41IHB4LTIgdGV4dC14cyByb3VuZGVkLWxnIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICBzdGF0cy51c2VyRWxvID09PSBsdmwuZWxvXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzIwIGJvcmRlci1hbWJlci01MDAvNDAgdGV4dC1hbWJlci0zMDAgZm9udC1zZW1pYm9sZCdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zdG9uZS04MDAvNjAgYm9yZGVyLXdoaXRlLzUgdGV4dC1zdG9uZS0zMDAgaG92ZXI6Ymctc3RvbmUtODAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2x2bC5sYWJlbH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zdG9uZS00MDAgZm9udC1tb25vLW51bXNcIj57bHZsLmVsb308L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBUb2dnbGVzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzEwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zdG9uZS0yMDBcIj5cbiAgICAgICAgICAgICAgICA8Vm9sdW1lMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkF1ZGlvIFNvdW5kIEVmZmVjdHM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25Ub2dnbGVTb3VuZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTExIGgtNiByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1jb2xvcnMgcmVsYXRpdmUgJHtcbiAgICAgICAgICAgICAgICAgICFpc1NvdW5kTXV0ZWQgPyAnYmctZW1lcmFsZC02MDAnIDogJ2JnLXN0b25lLTcwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNCBoLTQgcm91bmRlZC1mdWxsIGJnLXdoaXRlIHRyYW5zaXRpb24tdHJhbnNmb3JtIGFic29sdXRlIHRvcC0xICR7XG4gICAgICAgICAgICAgICAgICAgICFpc1NvdW5kTXV0ZWQgPyAncmlnaHQtMScgOiAnbGVmdC0xJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtc3RvbmUtMjAwXCI+XG4gICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Db2FjaCBCbHVuZGVyIEFsZXJ0czwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvblRvZ2dsZUJsdW5kZXJBbGVydHN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0xMSBoLTYgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tY29sb3JzIHJlbGF0aXZlICR7XG4gICAgICAgICAgICAgICAgICBzaG93Qmx1bmRlckFsZXJ0cyA/ICdiZy1hbWJlci02MDAnIDogJ2JnLXN0b25lLTcwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNCBoLTQgcm91bmRlZC1mdWxsIGJnLXdoaXRlIHRyYW5zaXRpb24tdHJhbnNmb3JtIGFic29sdXRlIHRvcC0xICR7XG4gICAgICAgICAgICAgICAgICAgIHNob3dCbHVuZGVyQWxlcnRzID8gJ3JpZ2h0LTEnIDogJ2xlZnQtMSdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRG93bmxvYWQgU291cmNlIENvZGUgU2VjdGlvbiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzEwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zdG9uZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTFcIj5cbiAgICAgICAgICAgICAgRXhwb3J0IFNvdXJjZSBDb2RlXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZG93bmxvYWRQcm9qZWN0WmlwKCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHctZnVsbCBweS0yLjUgcHgtMyB0ZXh0LXhzIHRleHQtc3RvbmUtMTAwIGJnLXN0b25lLTgwMCBob3ZlcjpiZy1zdG9uZS03MDAgYWN0aXZlOnNjYWxlLTk1IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgYm9yZGVyIGJvcmRlci13aGl0ZS8xNSBmb250LXNlbWlib2xkIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+RG93bmxvYWQgUHJvamVjdCBBcmNoaXZlICguemlwKTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAge29uRG93bmxvYWRTb3VyY2UgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25Eb3dubG9hZFNvdXJjZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB3LWZ1bGwgcHktMiBweC0zIHRleHQteHMgdGV4dC1zdG9uZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBiZy10cmFuc3BhcmVudCBob3ZlcjpiZy13aGl0ZS81IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgZm9udC1tZWRpdW0gYm9yZGVyIGJvcmRlci13aGl0ZS81XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXN0b25lLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+RG93bmxvYWQgU2luZ2xlIERvY3VtZW50ICgubWQpPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmVzZXQgQWxsIFN0YXRzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMlwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHdpbmRvdy5jb25maXJtKCdSZXNldCBhbGwgbWF0Y2ggaGlzdG9yeSBhbmQgcmVzdG9yZSBzdGFydGluZyAyNTAgRWxvPycpKSB7XG4gICAgICAgICAgICAgICAgICBvblJlc2V0U3RhdHMoKTtcbiAgICAgICAgICAgICAgICAgIHNldEN1c3RvbUVsbygyNTApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSB3LWZ1bGwgcHktMiBweC0zIHRleHQteHMgdGV4dC1yZWQtNDAwIGhvdmVyOnRleHQtcmVkLTMwMCBob3ZlcjpiZy1yZWQtNTAwLzEwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgYm9yZGVyIGJvcmRlci1yZWQtNTAwLzIwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPlJlc2V0IEhpc3RvcnkgJiBSZXR1cm4gdG8gMjUwIEVsbzwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItd2hpdGUvMTAgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweS0yIHB4LTQgYmctc3RvbmUtODAwIGhvdmVyOmJnLXN0b25lLTcwMCB0ZXh0LXN0b25lLTIwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgRG9uZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19