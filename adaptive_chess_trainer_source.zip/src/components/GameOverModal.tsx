const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=fd608e84";
import { Trophy, Frown, Equal, ArrowRight, RotateCcw, Eye } from "/node_modules/.vite/deps/lucide-react.js?v=c3d5a9dc";
var _jsxFileName = "/app/applet/src/components/GameOverModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
export const GameOverModal = ({ isOpen, result, reason, eloChange, newPlayerElo, newBotElo, moves, onPlayAgain, onClose }) => {
	useEffect(() => {
		if (isOpen && result === "win") {
			try {
				confetti({
					particleCount: 80,
					spread: 70,
					origin: { y: .6 },
					colors: [
						"#F4F2BA",
						"#779556",
						"#10B981",
						"#F59E0B"
					]
				});
			} catch {}
		}
	}, [isOpen, result]);
	if (!isOpen) return null;
	// Calculate move accuracy breakdown
	const playerMoves = moves.filter((_, idx) => idx % 2 === 0);
	const bestCount = playerMoves.filter((m) => m.classification === "best").length;
	const goodCount = playerMoves.filter((m) => m.classification === "good").length;
	const inaccuracyCount = playerMoves.filter((m) => m.classification === "inaccuracy").length;
	const mistakeCount = playerMoves.filter((m) => m.classification === "mistake").length;
	const blunderCount = playerMoves.filter((m) => m.classification === "blunder").length;
	const total = Math.max(1, playerMoves.length);
	const accuracy = Math.round((bestCount * 1 + goodCount * .85 + inaccuracyCount * .5 + mistakeCount * .2) / total * 100);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-[#1E2226] border border-white/15 rounded-2xl p-6 shadow-2xl max-w-md w-full text-center animate-in fade-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mx-auto w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-lg",
					children: result === "win" ? /* @__PURE__ */ _jsxDEV("div", {
						className: "w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400",
						children: /* @__PURE__ */ _jsxDEV(Trophy, { className: "w-8 h-8" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 13
					}, this) : result === "loss" ? /* @__PURE__ */ _jsxDEV("div", {
						className: "w-16 h-16 rounded-2xl bg-red-500/20 border border-red-500/30 flex items-center justify-center text-red-400",
						children: /* @__PURE__ */ _jsxDEV(Frown, { className: "w-8 h-8" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400",
						children: /* @__PURE__ */ _jsxDEV(Equal, { className: "w-8 h-8" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "font-display font-bold text-2xl text-stone-100",
					children: result === "win" ? "Victory!" : result === "loss" ? "Match Complete" : "Draw Agreed"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-stone-400 mt-1 capitalize",
					children: reason
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "my-5 p-4 bg-black/30 border border-white/10 rounded-xl",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "text-xs uppercase tracking-wider text-stone-400 font-semibold mb-2",
							children: "Rating Adjustment"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-center gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono-nums text-lg text-stone-300",
									children: newPlayerElo - eloChange
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 88,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4 text-stone-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 91,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono-nums text-2xl font-bold text-amber-300",
									children: newPlayerElo
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: `font-mono-nums text-sm font-semibold px-2 py-0.5 rounded ${eloChange >= 0 ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`,
									children: eloChange >= 0 ? `+${eloChange}` : eloChange
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 text-xs text-stone-400",
							children: [
								"Next Bot Elo will scale dynamically to",
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold text-emerald-300 font-mono-nums",
									children: newBotElo
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 13
								}, this),
								" (+100)"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-3 gap-2 mb-6 text-xs bg-stone-900/50 p-3 rounded-xl border border-white/5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col items-center",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-stone-400 text-[11px]",
								children: "Est. Accuracy"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono-nums font-bold text-stone-200 text-sm mt-0.5",
								children: [accuracy, "%"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col items-center",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-stone-400 text-[11px]",
								children: "Best Moves"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono-nums font-bold text-emerald-400 text-sm mt-0.5",
								children: bestCount
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col items-center",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-stone-400 text-[11px]",
								children: "Blunders"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono-nums font-bold text-red-400 text-sm mt-0.5",
								children: blunderCount
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: onPlayAgain,
						className: "w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-semibold rounded-xl text-sm transition-all shadow-lg flex items-center justify-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Next Sparring Match (vs ",
							newBotElo,
							" Elo)"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-full py-2.5 px-4 bg-transparent hover:bg-white/5 text-stone-400 hover:text-stone-200 text-xs font-medium rounded-xl transition-colors flex items-center justify-center gap-1.5",
						children: [/* @__PURE__ */ _jsxDEV(Eye, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Review Final Board" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGlCQUFpQjtBQUNqQyxPQUFPLGNBQWM7QUFDckIsU0FBUyxRQUFRLE9BQU8sT0FBTyxZQUFZLFdBQVcsV0FBVzs7O0FBZWpFLE9BQU8sTUFBTSxpQkFBK0MsRUFDMUQsUUFDQSxRQUNBLFFBQ0EsV0FDQSxjQUNBLFdBQ0EsT0FDQSxhQUNBLGNBQ0k7Q0FDSixnQkFBZ0I7RUFDZCxJQUFJLFVBQVUsV0FBVyxPQUFPO0dBQzlCLElBQUk7SUFDRixTQUFTO0tBQ1AsZUFBZTtLQUNmLFFBQVE7S0FDUixRQUFRLEVBQUUsR0FBRyxHQUFJO0tBQ2pCLFFBQVE7TUFBQztNQUFXO01BQVc7TUFBVztLQUFTO0lBQ3JELENBQUM7R0FDSCxRQUFRLENBQUM7RUFDWDtDQUNGLEdBQUcsQ0FBQyxRQUFRLE1BQU0sQ0FBQztDQUVuQixJQUFJLENBQUMsUUFBUSxPQUFPOztDQUdwQixNQUFNLGNBQWMsTUFBTSxRQUFRLEdBQUcsUUFBUSxNQUFNLE1BQU0sQ0FBQztDQUMxRCxNQUFNLFlBQVksWUFBWSxRQUFRLE1BQU0sRUFBRSxtQkFBbUIsTUFBTSxDQUFDLENBQUM7Q0FDekUsTUFBTSxZQUFZLFlBQVksUUFBUSxNQUFNLEVBQUUsbUJBQW1CLE1BQU0sQ0FBQyxDQUFDO0NBQ3pFLE1BQU0sa0JBQWtCLFlBQVksUUFBUSxNQUFNLEVBQUUsbUJBQW1CLFlBQVksQ0FBQyxDQUFDO0NBQ3JGLE1BQU0sZUFBZSxZQUFZLFFBQVEsTUFBTSxFQUFFLG1CQUFtQixTQUFTLENBQUMsQ0FBQztDQUMvRSxNQUFNLGVBQWUsWUFBWSxRQUFRLE1BQU0sRUFBRSxtQkFBbUIsU0FBUyxDQUFDLENBQUM7Q0FFL0UsTUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHLFlBQVksTUFBTTtDQUM1QyxNQUFNLFdBQVcsS0FBSyxPQUFRLFlBQVksSUFBTSxZQUFZLE1BQU8sa0JBQWtCLEtBQU0sZUFBZSxNQUFPLFFBQVMsR0FBRztDQUU3SCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUdFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osV0FBVyxRQUNWLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O0tBQzFCOzs7O2dCQUNILFdBQVcsU0FDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztLQUN6Qjs7OztnQkFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztLQUN6Qjs7Ozs7SUFFSjs7Ozs7SUFHTCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLFdBQVcsUUFBUSxhQUFhLFdBQVcsU0FBUyxtQkFBbUI7SUFDdEU7Ozs7O0lBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBMEM7SUFBVTs7Ozs7SUFHakUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFxRTtNQUUvRTs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLGVBQWU7UUFDWjs7Ozs7UUFDTix3QkFBQyxZQUFELEVBQVksV0FBVSx5QkFBMEI7Ozs7O1FBQ2hELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiO1FBQ0c7Ozs7O1FBQ04sd0JBQUMsUUFBRDtTQUNFLFdBQVcsNERBQ1QsYUFBYSxJQUNULHVDQUNBO21CQUdMLGFBQWEsSUFBSSxJQUFJLGNBQWM7UUFDaEM7Ozs7O09BQ0g7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQTZDO1FBQ0o7UUFDdkMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTZDO1FBQWdCOzs7OztRQUFDO09BQzNFOzs7Ozs7S0FDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTZCO09BQW1COzs7O2lCQUNoRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FBMEUsVUFBUyxHQUFPOzs7OztlQUN2Rjs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkI7T0FBZ0I7Ozs7aUJBQzdELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE0RDtPQUFnQjs7OztlQUN6Rjs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkI7T0FBYzs7OztpQkFDM0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXdEO09BQW1COzs7O2VBQ3hGOzs7Ozs7S0FDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7Z0JBQ2hDLHdCQUFDLFFBQUQ7T0FBTTtPQUF5QjtPQUFVO01BQVc7Ozs7Y0FDOUM7Ozs7O2VBQ1Isd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUZaLENBSUUsd0JBQUMsS0FBRCxFQUFLLFdBQVUsY0FBZTs7OztnQkFDOUIsd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztjQUN4Qjs7Ozs7YUFDTDs7Ozs7O0dBRUY7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkdhbWVPdmVyTW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgY29uZmV0dGkgZnJvbSAnY2FudmFzLWNvbmZldHRpJztcbmltcG9ydCB7IFRyb3BoeSwgRnJvd24sIEVxdWFsLCBBcnJvd1JpZ2h0LCBSb3RhdGVDY3csIEV5ZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBFdmFsdWF0ZWRNb3ZlIH0gZnJvbSAnLi4vdHlwZXMvY2hlc3MnO1xuXG5pbnRlcmZhY2UgR2FtZU92ZXJNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICByZXN1bHQ6ICd3aW4nIHwgJ2xvc3MnIHwgJ2RyYXcnO1xuICByZWFzb246IHN0cmluZztcbiAgZWxvQ2hhbmdlOiBudW1iZXI7XG4gIG5ld1BsYXllckVsbzogbnVtYmVyO1xuICBuZXdCb3RFbG86IG51bWJlcjtcbiAgbW92ZXM6IEV2YWx1YXRlZE1vdmVbXTtcbiAgb25QbGF5QWdhaW46ICgpID0+IHZvaWQ7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBHYW1lT3Zlck1vZGFsOiBSZWFjdC5GQzxHYW1lT3Zlck1vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICByZXN1bHQsXG4gIHJlYXNvbixcbiAgZWxvQ2hhbmdlLFxuICBuZXdQbGF5ZXJFbG8sXG4gIG5ld0JvdEVsbyxcbiAgbW92ZXMsXG4gIG9uUGxheUFnYWluLFxuICBvbkNsb3NlLFxufSkgPT4ge1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc09wZW4gJiYgcmVzdWx0ID09PSAnd2luJykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uZmV0dGkoe1xuICAgICAgICAgIHBhcnRpY2xlQ291bnQ6IDgwLFxuICAgICAgICAgIHNwcmVhZDogNzAsXG4gICAgICAgICAgb3JpZ2luOiB7IHk6IDAuNiB9LFxuICAgICAgICAgIGNvbG9yczogWycjRjRGMkJBJywgJyM3Nzk1NTYnLCAnIzEwQjk4MScsICcjRjU5RTBCJ10sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCB7fVxuICAgIH1cbiAgfSwgW2lzT3BlbiwgcmVzdWx0XSk7XG5cbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIC8vIENhbGN1bGF0ZSBtb3ZlIGFjY3VyYWN5IGJyZWFrZG93blxuICBjb25zdCBwbGF5ZXJNb3ZlcyA9IG1vdmVzLmZpbHRlcigoXywgaWR4KSA9PiBpZHggJSAyID09PSAwKTtcbiAgY29uc3QgYmVzdENvdW50ID0gcGxheWVyTW92ZXMuZmlsdGVyKChtKSA9PiBtLmNsYXNzaWZpY2F0aW9uID09PSAnYmVzdCcpLmxlbmd0aDtcbiAgY29uc3QgZ29vZENvdW50ID0gcGxheWVyTW92ZXMuZmlsdGVyKChtKSA9PiBtLmNsYXNzaWZpY2F0aW9uID09PSAnZ29vZCcpLmxlbmd0aDtcbiAgY29uc3QgaW5hY2N1cmFjeUNvdW50ID0gcGxheWVyTW92ZXMuZmlsdGVyKChtKSA9PiBtLmNsYXNzaWZpY2F0aW9uID09PSAnaW5hY2N1cmFjeScpLmxlbmd0aDtcbiAgY29uc3QgbWlzdGFrZUNvdW50ID0gcGxheWVyTW92ZXMuZmlsdGVyKChtKSA9PiBtLmNsYXNzaWZpY2F0aW9uID09PSAnbWlzdGFrZScpLmxlbmd0aDtcbiAgY29uc3QgYmx1bmRlckNvdW50ID0gcGxheWVyTW92ZXMuZmlsdGVyKChtKSA9PiBtLmNsYXNzaWZpY2F0aW9uID09PSAnYmx1bmRlcicpLmxlbmd0aDtcblxuICBjb25zdCB0b3RhbCA9IE1hdGgubWF4KDEsIHBsYXllck1vdmVzLmxlbmd0aCk7XG4gIGNvbnN0IGFjY3VyYWN5ID0gTWF0aC5yb3VuZCgoKGJlc3RDb3VudCAqIDEuMCArIGdvb2RDb3VudCAqIDAuODUgKyBpbmFjY3VyYWN5Q291bnQgKiAwLjUgKyBtaXN0YWtlQ291bnQgKiAwLjIpIC8gdG90YWwpICogMTAwKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGJnLWJsYWNrLzc1IGJhY2tkcm9wLWJsdXItc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjMUUyMjI2XSBib3JkZXIgYm9yZGVyLXdoaXRlLzE1IHJvdW5kZWQtMnhsIHAtNiBzaGFkb3ctMnhsIG1heC13LW1kIHctZnVsbCB0ZXh0LWNlbnRlciBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBSZXN1bHQgSWNvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIHctMTYgaC0xNiByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00IHNoYWRvdy1sZ1wiPlxuICAgICAgICAgIHtyZXN1bHQgPT09ICd3aW4nID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgcm91bmRlZC0yeGwgYmctZW1lcmFsZC01MDAvMjAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgIDxUcm9waHkgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogcmVzdWx0ID09PSAnbG9zcycgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLTJ4bCBiZy1yZWQtNTAwLzIwIGJvcmRlciBib3JkZXItcmVkLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXJlZC00MDBcIj5cbiAgICAgICAgICAgICAgPEZyb3duIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtMnhsIGJnLWFtYmVyLTUwMC8yMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICA8RXF1YWwgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGl0bGUgKi99XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtMnhsIHRleHQtc3RvbmUtMTAwXCI+XG4gICAgICAgICAge3Jlc3VsdCA9PT0gJ3dpbicgPyAnVmljdG9yeSEnIDogcmVzdWx0ID09PSAnbG9zcycgPyAnTWF0Y2ggQ29tcGxldGUnIDogJ0RyYXcgQWdyZWVkJ31cbiAgICAgICAgPC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXN0b25lLTQwMCBtdC0xIGNhcGl0YWxpemVcIj57cmVhc29ufTwvcD5cblxuICAgICAgICB7LyogRWxvIFJhdGluZyBVcGRhdGUgQmFkZ2UgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNSBwLTQgYmctYmxhY2svMzAgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXN0b25lLTQwMCBmb250LXNlbWlib2xkIG1iLTJcIj5cbiAgICAgICAgICAgIFJhdGluZyBBZGp1c3RtZW50XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vLW51bXMgdGV4dC1sZyB0ZXh0LXN0b25lLTMwMFwiPlxuICAgICAgICAgICAgICB7bmV3UGxheWVyRWxvIC0gZWxvQ2hhbmdlfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXN0b25lLTUwMFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8tbnVtcyB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1hbWJlci0zMDBcIj5cbiAgICAgICAgICAgICAge25ld1BsYXllckVsb31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvbnQtbW9uby1udW1zIHRleHQtc20gZm9udC1zZW1pYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkICR7XG4gICAgICAgICAgICAgICAgZWxvQ2hhbmdlID49IDBcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICA6ICdiZy1yZWQtNTAwLzIwIHRleHQtcmVkLTQwMCdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtlbG9DaGFuZ2UgPj0gMCA/IGArJHtlbG9DaGFuZ2V9YCA6IGVsb0NoYW5nZX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgICAgTmV4dCBCb3QgRWxvIHdpbGwgc2NhbGUgZHluYW1pY2FsbHkgdG97JyAnfVxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZW1lcmFsZC0zMDAgZm9udC1tb25vLW51bXNcIj57bmV3Qm90RWxvfTwvc3Bhbj4gKCsxMDApXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBQZXJmb3JtYW5jZSBBY2N1cmFjeSBCcmVha2Rvd24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMiBtYi02IHRleHQteHMgYmctc3RvbmUtOTAwLzUwIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItd2hpdGUvNVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc3RvbmUtNDAwIHRleHQtWzExcHhdXCI+RXN0LiBBY2N1cmFjeTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9uby1udW1zIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTIwMCB0ZXh0LXNtIG10LTAuNVwiPnthY2N1cmFjeX0lPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc3RvbmUtNDAwIHRleHQtWzExcHhdXCI+QmVzdCBNb3Zlczwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9uby1udW1zIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwIHRleHQtc20gbXQtMC41XCI+e2Jlc3RDb3VudH08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zdG9uZS00MDAgdGV4dC1bMTFweF1cIj5CbHVuZGVyczwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9uby1udW1zIGZvbnQtYm9sZCB0ZXh0LXJlZC00MDAgdGV4dC1zbSBtdC0wLjVcIj57Ymx1bmRlckNvdW50fTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvblBsYXlBZ2Fpbn1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIHB4LTQgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC01MDAgYWN0aXZlOnNjYWxlLVswLjk4XSB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgcm91bmRlZC14bCB0ZXh0LXNtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPk5leHQgU3BhcnJpbmcgTWF0Y2ggKHZzIHtuZXdCb3RFbG99IEVsbyk8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgcHgtNCBiZy10cmFuc3BhcmVudCBob3ZlcjpiZy13aGl0ZS81IHRleHQtc3RvbmUtNDAwIGhvdmVyOnRleHQtc3RvbmUtMjAwIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RXllIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPlJldmlldyBGaW5hbCBCb2FyZDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==