const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8c504af6";
import { formatEvaluation, getWhiteWinPercentage } from "/src/engine/evaluator.ts";
var _jsxFileName = "/app/applet/src/components/EvalBar.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8c504af6";
export const EvalBar = ({ evalCp, playerColor = "w" }) => {
	const whitePercent = getWhiteWinPercentage(evalCp);
	// If player is white, white is at bottom. If player is black, black is at bottom.
	const isPlayerWhite = playerColor === "w";
	const bottomPercent = isPlayerWhite ? whitePercent : 100 - whitePercent;
	const formattedScore = formatEvaluation(evalCp);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col items-center select-none shrink-0",
		title: `Position Evaluation: ${formattedScore}`,
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-7 h-72 sm:h-96 md:h-[480px] bg-[#1E2024] rounded-lg overflow-hidden border border-white/10 shadow-inner flex flex-col justify-end",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-[#2C2E33]" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute bottom-0 left-0 right-0 bg-[#F4F2BA] transition-all duration-300 ease-out shadow-sm",
					style: { height: `${bottomPercent}%` }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-1/2 left-0 right-0 h-[1.5px] bg-emerald-500/60 z-10 pointer-events-none" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: `absolute left-0 right-0 z-20 text-center font-mono-nums font-bold text-[11px] leading-tight py-1 px-0.5 ${evalCp >= 0 ? "bottom-2 text-stone-900 bg-white/40 backdrop-blur-[2px] rounded mx-1" : "top-2 text-white bg-black/40 backdrop-blur-[2px] rounded mx-1"}`,
					children: formattedScore
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "text-[10px] uppercase font-mono-nums text-stone-400 mt-1.5 tracking-wider",
			children: "Eval"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsa0JBQWtCLDZCQUE2Qjs7O0FBT3hELE9BQU8sTUFBTSxXQUFtQyxFQUFFLFFBQVEsY0FBYyxVQUFVO0NBQ2hGLE1BQU0sZUFBZSxzQkFBc0IsTUFBTTs7Q0FFakQsTUFBTSxnQkFBZ0IsZ0JBQWdCO0NBQ3RDLE1BQU0sZ0JBQWdCLGdCQUFnQixlQUFlLE1BQU07Q0FFM0QsTUFBTSxpQkFBaUIsaUJBQWlCLE1BQU07Q0FFOUMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFrRCxPQUFPLHdCQUF3QjtZQUFoRyxDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFFRSx3QkFBQyxPQUFELEVBQUssV0FBVSxnQ0FBaUM7Ozs7O0lBR2hELHdCQUFDLE9BQUQ7S0FDRSxXQUFVO0tBQ1YsT0FBTyxFQUFFLFFBQVEsR0FBRyxjQUFjLEdBQUc7SUFDdEM7Ozs7O0lBR0Qsd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQXdGOzs7OztJQUd2Ryx3QkFBQyxPQUFEO0tBQ0UsV0FBVywyR0FDVCxVQUFVLElBQ04seUVBQ0E7ZUFHTDtJQUNFOzs7OztHQUNGOzs7OztZQUNMLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQTRFO0VBRXRGOzs7O1VBQ0g7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkV2YWxCYXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBmb3JtYXRFdmFsdWF0aW9uLCBnZXRXaGl0ZVdpblBlcmNlbnRhZ2UgfSBmcm9tICcuLi9lbmdpbmUvZXZhbHVhdG9yJztcblxuaW50ZXJmYWNlIEV2YWxCYXJQcm9wcyB7XG4gIGV2YWxDcDogbnVtYmVyOyAvLyBjZW50aXBhd25zIGZyb20gV2hpdGUgcGVyc3BlY3RpdmVcbiAgcGxheWVyQ29sb3I/OiAndycgfCAnYic7XG59XG5cbmV4cG9ydCBjb25zdCBFdmFsQmFyOiBSZWFjdC5GQzxFdmFsQmFyUHJvcHM+ID0gKHsgZXZhbENwLCBwbGF5ZXJDb2xvciA9ICd3JyB9KSA9PiB7XG4gIGNvbnN0IHdoaXRlUGVyY2VudCA9IGdldFdoaXRlV2luUGVyY2VudGFnZShldmFsQ3ApO1xuICAvLyBJZiBwbGF5ZXIgaXMgd2hpdGUsIHdoaXRlIGlzIGF0IGJvdHRvbS4gSWYgcGxheWVyIGlzIGJsYWNrLCBibGFjayBpcyBhdCBib3R0b20uXG4gIGNvbnN0IGlzUGxheWVyV2hpdGUgPSBwbGF5ZXJDb2xvciA9PT0gJ3cnO1xuICBjb25zdCBib3R0b21QZXJjZW50ID0gaXNQbGF5ZXJXaGl0ZSA/IHdoaXRlUGVyY2VudCA6IDEwMCAtIHdoaXRlUGVyY2VudDtcblxuICBjb25zdCBmb3JtYXR0ZWRTY29yZSA9IGZvcm1hdEV2YWx1YXRpb24oZXZhbENwKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgc2VsZWN0LW5vbmUgc2hyaW5rLTBcIiB0aXRsZT17YFBvc2l0aW9uIEV2YWx1YXRpb246ICR7Zm9ybWF0dGVkU2NvcmV9YH0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctNyBoLTcyIHNtOmgtOTYgbWQ6aC1bNDgwcHhdIGJnLVsjMUUyMDI0XSByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHNoYWRvdy1pbm5lciBmbGV4IGZsZXgtY29sIGp1c3RpZnktZW5kXCI+XG4gICAgICAgIHsvKiBCbGFjayBzaWRlIGZpbGwgKHRvcCkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1bIzJDMkUzM11cIiAvPlxuXG4gICAgICAgIHsvKiBXaGl0ZSBzaWRlIGZpbGwgKGJvdHRvbSkgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCBsZWZ0LTAgcmlnaHQtMCBiZy1bI0Y0RjJCQV0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2Utb3V0IHNoYWRvdy1zbVwiXG4gICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBgJHtib3R0b21QZXJjZW50fSVgIH19XG4gICAgICAgIC8+XG5cbiAgICAgICAgey8qIENlbnRlciB6ZXJvIGxpbmUgbWFya2VyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0xLzIgbGVmdC0wIHJpZ2h0LTAgaC1bMS41cHhdIGJnLWVtZXJhbGQtNTAwLzYwIHotMTAgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG5cbiAgICAgICAgey8qIFNjb3JlIGJhZGdlIHBsYWNlZCBjb250ZXh0dWFsbHkgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSBsZWZ0LTAgcmlnaHQtMCB6LTIwIHRleHQtY2VudGVyIGZvbnQtbW9uby1udW1zIGZvbnQtYm9sZCB0ZXh0LVsxMXB4XSBsZWFkaW5nLXRpZ2h0IHB5LTEgcHgtMC41ICR7XG4gICAgICAgICAgICBldmFsQ3AgPj0gMFxuICAgICAgICAgICAgICA/ICdib3R0b20tMiB0ZXh0LXN0b25lLTkwMCBiZy13aGl0ZS80MCBiYWNrZHJvcC1ibHVyLVsycHhdIHJvdW5kZWQgbXgtMSdcbiAgICAgICAgICAgICAgOiAndG9wLTIgdGV4dC13aGl0ZSBiZy1ibGFjay80MCBiYWNrZHJvcC1ibHVyLVsycHhdIHJvdW5kZWQgbXgtMSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIHtmb3JtYXR0ZWRTY29yZX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LW1vbm8tbnVtcyB0ZXh0LXN0b25lLTQwMCBtdC0xLjUgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgRXZhbFxuICAgICAgPC9zcGFuPlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==