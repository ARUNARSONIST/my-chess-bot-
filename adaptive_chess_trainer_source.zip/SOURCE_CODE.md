# Adaptive Chess Trainer - Full Source Code Bundle

This file contains the complete source code for the Adaptive Chess Trainer application.

---

### File: `package.json`
```json
{
  "name": "adaptive-chess-bot",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build",
    "preview": "vite preview",
    "clean": "rm -rf dist server.js",
    "lint": "tsc --noEmit"
  },
  "dependencies": {
    "@google/genai": "^2.4.0",
    "@tailwindcss/vite": "^4.3.3",
    "@vitejs/plugin-react": "^6.1.1",
    "canvas-confetti": "^1.9.4",
    "chess.js": "^1.4.0",
    "dotenv": "^17.2.3",
    "express": "^4.21.2",
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "react": "^19.0.1",
    "react-dom": "^19.0.1",
    "vite": "^8.3.0"
  },
  "devDependencies": {
    "@types/canvas-confetti": "^1.9.0",
    "@types/express": "^4.17.21",
    "@types/node": "^22.14.0",
    "@types/react": "^19.3.0",
    "@types/react-dom": "^19.3.0",
    "autoprefixer": "^10.4.21",
    "esbuild": "^0.25.0",
    "tailwindcss": "^4.3.3",
    "tsx": "^4.21.0",
    "typescript": "^7.0.2"
  }
}
```

---

### File: `index.html`
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Adaptive Chess Bot - Progressive Elo Sparring</title>
    <meta name="description" content="An evolving chess trainer with a bot that dynamically plays 100 Elo above your rating, featuring light yellow and green board aesthetics, live evaluation, and move analysis." />
    <meta property="og:title" content="Adaptive Chess Bot - Progressive Elo Sparring" />
    <meta property="og:description" content="An evolving chess trainer with a bot that dynamically plays 100 Elo above your rating, featuring light yellow and green board aesthetics, live evaluation, and move analysis." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

---

### File: `src/types/chess.ts`
```typescript
export type PieceColor = 'w' | 'b';
export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';

export type MoveClassification = 'best' | 'good' | 'inaccuracy' | 'mistake' | 'blunder' | 'book';

export interface EvaluatedMove {
  san: string;
  from: string;
  to: string;
  piece: PieceType;
  color: PieceColor;
  captured?: PieceType;
  evalBefore: number;
  evalAfter: number;
  classification?: MoveClassification;
  comment?: string;
  bestMoveSan?: string;
}

export interface PlayerStats {
  userElo: number;
  matchesPlayed: number;
  wins: number;
  losses: number;
  draws: number;
  streak: number;
  ratingHistory: { match: number; elo: number; date: string; opponentElo: number; result: 'win' | 'loss' | 'draw' }[];
}

export interface HintSuggestion {
  from: string;
  to: string;
  san: string;
  explanation: string;
  evalScore: number;
}
```

---

### File: `src/utils/audio.ts`
```typescript
class ChessAudio {
  private ctx: AudioContext | null = null;
  public muted: boolean = false;

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  playMove() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(120, this.ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.25, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.08);
    } catch {}
  }

  playCapture() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(180, this.ctx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.35, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.12);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.12);
    } catch {}
  }

  playCheck() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(600, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(750, this.ctx.currentTime + 0.18);

      gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.2);
    } catch {}
  }

  playVictory() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const notes = [440, 554, 659, 880];
      notes.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, this.ctx!.currentTime + i * 0.1);
        gain.gain.setValueAtTime(0.2, this.ctx!.currentTime + i * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx!.currentTime + i * 0.1 + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(this.ctx!.currentTime + i * 0.1);
        osc.stop(this.ctx!.currentTime + i * 0.1 + 0.25);
      });
    } catch {}
  }

  playDefeat() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const notes = [380, 320, 260];
      notes.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, this.ctx!.currentTime + i * 0.14);
        gain.gain.setValueAtTime(0.25, this.ctx!.currentTime + i * 0.14);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx!.currentTime + i * 0.14 + 0.3);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(this.ctx!.currentTime + i * 0.14);
        osc.stop(this.ctx!.currentTime + i * 0.14 + 0.3);
      });
    } catch {}
  }

  playBlunder() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, this.ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(140, this.ctx.currentTime + 0.18);

      gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.18);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.18);
    } catch {}
  }
}

export const soundEffects = new ChessAudio();
```

---

### File: `src/engine/evaluator.ts`
```typescript
import { Chess } from 'chess.js';

export const PIECE_VALUES: Record<string, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000,
};

const PAWN_TABLE = [
  0,  0,  0,  0,  0,  0,  0,  0,
  50, 50, 50, 50, 50, 50, 50, 50,
  10, 10, 20, 30, 30, 20, 10, 10,
   5,  5, 10, 25, 25, 10,  5,  5,
   0,  0,  0, 20, 20,  0,  0,  0,
   5, -5,-10,  0,  0,-10, -5,  5,
   5, 10, 10,-20,-20, 10, 10,  5,
   0,  0,  0,  0,  0,  0,  0,  0
];

const KNIGHT_TABLE = [
  -50,-40,-30,-30,-30,-30,-40,-50,
  -40,-20,  0,  0,  0,  0,-20,-40,
  -30,  0, 10, 15, 15, 10,  0,-30,
  -30,  5, 15, 20, 20, 15,  5,-30,
  -30,  0, 15, 20, 20, 15,  0,-30,
  -30,  5, 10, 15, 15, 10,  5,-30,
  -40,-20,  0,  5,  5,  0,-20,-40,
  -50,-40,-30,-30,-30,-30,-40,-50,
];

const BISHOP_TABLE = [
  -20,-10,-10,-10,-10,-10,-10,-20,
  -10,  0,  0,  0,  0,  0,  0,-10,
  -10,  0,  5, 10, 10,  5,  0,-10,
  -10,  5,  5, 10, 10,  5,  5,-10,
  -10,  0, 10, 10, 10, 10,  0,-10,
  -10, 10, 10, 10, 10, 10, 10,-10,
  -10,  5,  0,  0,  0,  0,  5,-10,
  -20,-10,-10,-10,-10,-10,-10,-20,
];

const ROOK_TABLE = [
  0,  0,  0,  0,  0,  0,  0,  0,
  5, 10, 10, 10, 10, 10, 10,  5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
  0,  0,  0,  5,  5,  0,  0,  0
];

const QUEEN_TABLE = [
  -20,-10,-10, -5, -5,-10,-10,-20,
  -10,  0,  0,  0,  0,  0,  0,-10,
  -10,  0,  5,  5,  5,  5,  0,-10,
   -5,  0,  5,  5,  5,  5,  0, -5,
    0,  0,  5,  5,  5,  5,  0, -5,
  -10,  5,  5,  5,  5,  5,  0,-10,
  -10,  0,  5,  0,  0,  0,  0,-10,
  -20,-10,-10, -5, -5,-10,-10,-20
];

const KING_TABLE = [
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -20,-30,-30,-40,-40,-30,-30,-20,
  -10,-20,-20,-20,-20,-20,-20,-10,
   20, 20,  0,  0,  0,  0, 20, 20,
   20, 30, 10,  0,  0, 10, 30, 20
];

function getSquareIndex(square: string): number {
  const file = square.charCodeAt(0) - 'a'.charCodeAt(0);
  const rank = 8 - parseInt(square[1], 10);
  return rank * 8 + file;
}

function getMirroredSquareIndex(square: string): number {
  const file = square.charCodeAt(0) - 'a'.charCodeAt(0);
  const rank = parseInt(square[1], 10) - 1;
  return rank * 8 + file;
}

export function evaluateBoard(game: Chess): number {
  if (game.isGameOver()) {
    if (game.isCheckmate()) {
      return game.turn() === 'w' ? -20000 : 20000;
    }
    return 0;
  }

  let whiteScore = 0;
  let blackScore = 0;
  const board = game.board();

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;

      const squareName = String.fromCharCode('a'.charCodeAt(0) + c) + (8 - r);
      const pieceValue = PIECE_VALUES[piece.type] || 0;

      if (piece.color === 'w') {
        const sqIdx = getSquareIndex(squareName);
        let pstBonus = 0;
        if (piece.type === 'p') pstBonus = PAWN_TABLE[sqIdx];
        else if (piece.type === 'n') pstBonus = KNIGHT_TABLE[sqIdx];
        else if (piece.type === 'b') pstBonus = BISHOP_TABLE[sqIdx];
        else if (piece.type === 'r') pstBonus = ROOK_TABLE[sqIdx];
        else if (piece.type === 'q') pstBonus = QUEEN_TABLE[sqIdx];
        else if (piece.type === 'k') pstBonus = KING_TABLE[sqIdx];

        whiteScore += pieceValue + pstBonus;
      } else {
        const sqIdx = getMirroredSquareIndex(squareName);
        let pstBonus = 0;
        if (piece.type === 'p') pstBonus = PAWN_TABLE[sqIdx];
        else if (piece.type === 'n') pstBonus = KNIGHT_TABLE[sqIdx];
        else if (piece.type === 'b') pstBonus = BISHOP_TABLE[sqIdx];
        else if (piece.type === 'r') pstBonus = ROOK_TABLE[sqIdx];
        else if (piece.type === 'q') pstBonus = QUEEN_TABLE[sqIdx];
        else if (piece.type === 'k') pstBonus = KING_TABLE[sqIdx];

        blackScore += pieceValue + pstBonus;
      }
    }
  }

  const currentTurn = game.turn();
  const movesCount = game.moves().length;
  if (currentTurn === 'w') {
    whiteScore += movesCount * 4;
  } else {
    blackScore += movesCount * 4;
  }

  return whiteScore - blackScore;
}

export function formatEvaluation(evalCp: number): string {
  if (Math.abs(evalCp) >= 19000) {
    const mateIn = Math.ceil((20000 - Math.abs(evalCp)) / 100);
    return evalCp > 0 ? `+M${Math.max(1, mateIn)}` : `-M${Math.max(1, mateIn)}`;
  }
  const pawns = evalCp / 100;
  if (pawns > 0) return `+${pawns.toFixed(1)}`;
  if (pawns < 0) return `${pawns.toFixed(1)}`;
  return '0.0';
}

export function getWhiteWinPercentage(evalCp: number): number {
  if (evalCp >= 19000) return 100;
  if (evalCp <= -19000) return 0;
  const val = 1 / (1 + Math.pow(10, -evalCp / 400));
  return Math.min(99, Math.max(1, Math.round(val * 100)));
}
```

---

### File: `src/engine/botEngine.ts`
```typescript
import { Chess } from 'chess.js';
import { evaluateBoard, PIECE_VALUES } from './evaluator';
import { HintSuggestion, MoveClassification } from '../types/chess';

export interface BotCalibration {
  searchDepth: number;
  blunderRate: number;
  noiseMagnitude: number;
  tierName: string;
}

export function getCalibrationForElo(elo: number): BotCalibration {
  if (elo < 350) return { searchDepth: 1, blunderRate: 0.50, noiseMagnitude: 180, tierName: 'Beginner Novice' };
  if (elo < 500) return { searchDepth: 1, blunderRate: 0.35, noiseMagnitude: 120, tierName: 'Apprentice' };
  if (elo < 700) return { searchDepth: 2, blunderRate: 0.22, noiseMagnitude: 80, tierName: 'Casual Player' };
  if (elo < 950) return { searchDepth: 2, blunderRate: 0.14, noiseMagnitude: 45, tierName: 'Club Player' };
  if (elo < 1200) return { searchDepth: 3, blunderRate: 0.07, noiseMagnitude: 25, tierName: 'Intermediate' };
  if (elo < 1500) return { searchDepth: 3, blunderRate: 0.03, noiseMagnitude: 10, tierName: 'Advanced Club' };
  return { searchDepth: 4, blunderRate: 0.0, noiseMagnitude: 0, tierName: 'Expert Tactician' };
}

function minimax(game: Chess, depth: number, alpha: number, beta: number, isMaximizing: boolean): number {
  if (depth === 0 || game.isGameOver()) return evaluateBoard(game);

  const moves = game.moves({ verbose: true });
  moves.sort((a, b) => {
    const scoreA = a.captured ? PIECE_VALUES[a.captured] || 100 : 0;
    const scoreB = b.captured ? PIECE_VALUES[b.captured] || 100 : 0;
    return scoreB - scoreA;
  });

  if (isMaximizing) {
    let maxEval = -Infinity;
    for (const move of moves) {
      game.move(move);
      const evaluation = minimax(game, depth - 1, alpha, beta, false);
      game.undo();
      maxEval = Math.max(maxEval, evaluation);
      alpha = Math.max(alpha, evaluation);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (const move of moves) {
      game.move(move);
      const evaluation = minimax(game, depth - 1, alpha, beta, true);
      game.undo();
      minEval = Math.min(minEval, evaluation);
      beta = Math.min(beta, evaluation);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

export function getRankedMoves(game: Chess, depth: number = 2) {
  const isWhite = game.turn() === 'w';
  const moves = game.moves({ verbose: true });
  if (moves.length === 0) return [];

  const ratedMoves = moves.map((move) => {
    game.move(move);
    const score = minimax(game, depth - 1, -Infinity, Infinity, !isWhite);
    game.undo();
    return {
      move,
      score,
      relativeScore: isWhite ? score : -score,
    };
  });

  ratedMoves.sort((a, b) => b.relativeScore - a.relativeScore);
  return ratedMoves;
}

export function chooseBotMove(game: Chess, botElo: number) {
  const calibration = getCalibrationForElo(botElo);
  const ranked = getRankedMoves(game, calibration.searchDepth);
  if (ranked.length === 0) return null;

  const shouldBlunder = Math.random() < calibration.blunderRate;
  if (shouldBlunder && ranked.length > 1) {
    const blunderIndex = Math.min(ranked.length - 1, Math.floor(Math.random() * (ranked.length - 1)) + 1);
    return ranked[blunderIndex].move;
  }

  if (calibration.noiseMagnitude > 0) {
    const noisyMoves = ranked.map((item) => ({
      ...item,
      noisyScore: item.relativeScore + (Math.random() - 0.5) * calibration.noiseMagnitude * 2,
    }));
    noisyMoves.sort((a, b) => b.noisyScore - a.noisyScore);
    return noisyMoves[0].move;
  }

  return ranked[0].move;
}

export function classifyMove(gameBeforeMove: Chess, playedMoveSan: string, depth: number = 2) {
  const evalBefore = evaluateBoard(gameBeforeMove);
  const ranked = getRankedMoves(gameBeforeMove, depth);
  if (ranked.length === 0) {
    return { classification: 'good' as MoveClassification, evalBefore, evalAfter: evalBefore, bestMoveSan: playedMoveSan };
  }

  const bestOption = ranked[0];
  const playedOption = ranked.find((r) => r.move.san === playedMoveSan);
  const bestScore = bestOption.relativeScore;
  const playedScore = playedOption ? playedOption.relativeScore : bestScore - 300;
  const delta = Math.max(0, bestScore - playedScore);

  let classification: MoveClassification = 'best';
  let explanation = 'Accurate positional move.';

  if (delta <= 15) {
    classification = 'best';
    explanation = 'Optimal engine choice.';
  } else if (delta <= 60) {
    classification = 'good';
    explanation = 'Solid positional move.';
  } else if (delta <= 150) {
    classification = 'inaccuracy';
    explanation = `Inaccuracy. ${bestOption.move.san} was slightly stronger.`;
  } else if (delta <= 300) {
    classification = 'mistake';
    explanation = `Mistake. Gives opponent leverage. Best was ${bestOption.move.san}.`;
  } else {
    classification = 'blunder';
    explanation = `Blunder! Loses advantage. Best was ${bestOption.move.san}.`;
  }

  const clone = new Chess(gameBeforeMove.fen());
  try { clone.move(playedMoveSan); } catch {}
  const evalAfter = evaluateBoard(clone);

  return { classification, evalBefore, evalAfter, bestMoveSan: bestOption.move.san, explanation };
}

export function generateHint(game: Chess): HintSuggestion | null {
  const ranked = getRankedMoves(game, 2);
  if (ranked.length === 0) return null;
  const top = ranked[0];
  const move = top.move;

  let explanation = `Play ${move.san}. `;
  if (move.captured) {
    explanation += `Captures the ${move.captured.toUpperCase()} on ${move.to}.`;
  } else if (move.san === 'O-O' || move.san === 'O-O-O') {
    explanation += 'Castles to protect king and connect rooks.';
  } else if (['d4', 'd5', 'e4', 'e5'].includes(move.to)) {
    explanation += `Controls the center square ${move.to}.`;
  } else if (move.piece === 'n') {
    explanation += `Develops knight to active square ${move.to}.`;
  } else if (move.piece === 'b') {
    explanation += `Develops bishop to active diagonal.`;
  } else {
    explanation += `Solid positional move.`;
  }

  return { from: move.from, to: move.to, san: move.san, explanation, evalScore: top.score };
}
```

---

---

### File: `src/utils/exportSourceZip.ts`
Utility leveraging JSZip to pack all source files and chess piece assets into a clean `.zip` archive on demand.

---

### How to Run Locally:
1. Extract the downloaded zip file into a folder.
2. Run `npm install` to install dependencies.
3. Run `npm run dev` to launch the local Vite development server on `http://localhost:3000`.
